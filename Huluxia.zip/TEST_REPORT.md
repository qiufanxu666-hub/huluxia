# Huluxia 2.1.0 测试报告

测试层级必须区分，**本次没有任何真机（iOS 越狱设备）测试**。

| 层级 | 做了什么 | 结果 |
|---|---|---|
| 模拟环境测试 | Chromium 加载真实 ui.html（含 Fengari），挂 `tests/mock_host.js` 模拟宿主（带字节内存，返回格式仿 HLXMemory），点击真实脚本面板 DOM | **28/28 通过**（`tests/results_patched.json`） |
| 对照基线 | 同一套用例跑原版 ui.html | 13/28 通过，15 项失败（`tests/results_original.json`） |
| 静态检查 | ui.html 3 个内联脚本 `node --check`；HLXMemory.m/.h、HLXBridge.m 括号平衡；build.yml YAML 解析；verify_build.sh `bash -n`；图标尺寸检查片段正反向各跑一次 | 通过 |
| 单元测试 | 无（工程原本没有） | — |
| 编译 | 无法执行（无 Xcode/Theos/clang/网络） | **未编译** |
| 真机 | 无 | **未验证** |

## 模拟环境用例明细（28）
Lua 基础 3：语法/协程/元表/goto、pcall/error、语法错误不崩溃。
GG 注册 2：24 个接口均为函数；TYPE_* 数值。
GG 菜单/输入 4：choice（选中/退出）、multiChoice、prompt（文本/数字/复选框）、alert。
内存 9：搜索计数与 flags、分页(2 条)、refine、setValues(flags=FLOAT)、getValues、editAll（含非结果地址不被改）、列表增删。
数据类型 4：sign 翻译为表达式、NOT_EQUAL 报错、XOR/AUTO/组合/encrypted 报错且不到达原生层、六种类型往返（含负数/小数/QWORD）。
进程/兼容 3：processPause/Resume/Toggle 的宿主调用序列、getFile/getSelectedElements、freeze 告警。
稳定性 4：停止后旧协程不再被唤醒、死循环 1s 超时被中断且页面可响应、脚本间全局变量不泄漏、连续 40 次运行。

## 原版失败而修改后通过的项
GG 注册(2)、searchNumber flags/number、分页(2)、setValues FLOAT、getValues、sign 翻译、NOT_EQUAL、XOR/AUTO、类型往返、processPause、getFile、freeze 告警、状态隔离。

## 未经验证（需真机 / 编译后确认）
- DYLIB / DEB 能否编译、安装、注入；桌面图标与悬浮球显示（`verify_build.sh` 会在 CI 里校验内容，但未运行过）
- HLXMemory 的真实搜索/读写、task_for_pid 权限、新加的 task_suspend/resume 与 port 释放
- 悬浮球显示与触摸、HLXTouch 注入点击、HLXSpeed 变速
- gg.sleep、setVisible/isVisible 的行为（仅验证已注册）
- searchFuzzy / searchNearby / searchPointer 及 HTML 其他页签功能
- GitHub Actions 首次运行（Theos 克隆、arm64e、rootless 路径、新增 `mobilesubstrate` 依赖是否与 Theos 自动依赖重复）
