#!/usr/bin/env python3
from pathlib import Path
import re, plistlib
root=Path(__file__).resolve().parent
ui=(root/'Resources/ui.html').read_text()
mem=(root/'Sources/HLXMemory.m').read_text()
speed=(root/'Sources/HLXSpeed.m').read_text()
legacy=(root/'Sources/HLXSpeedLegacy.m').read_text()
checks={
 'DWORD button maps U32':'data-t="U32" onclick="setDType(this)">DWORD' in ui,
 'WORD button maps U16':'data-t="U16" onclick="setDType(this)">WORD' in ui,
 'BYTE button maps U8':'data-t="U8" onclick="setDType(this)">BYTE' in ui,
 'FLOAT button maps F32':'data-t="F32" onclick="setDType(this)">FLOAT' in ui,
 '64-bit exact string comparator':'function compareIntegerText(a, b)' in ui,
 'unknown scan uses exact comparator':'var cmp = compareScanValues(curRaw, prevRaw, r.type)' in ui,
 'modification verifies readback':'var verifyValue = (typeof h5.getValue' in ui,
 'favorites store target process':'processName: (currentTargetProc && currentTargetProc.name)' in ui,
 'speed slider max 100x':'id="spdSlider" min="10" max="10000"' in ui,
 'speed preset 100x':'onclick="setSpeed(10000)">100x' in ui,
 'UI speed native guard 100x':'safeMult > 100' in ui,
 'native speed max 100x':'newSpeed > 100.0' in speed and 'mult > 100.0' in speed,
 'legacy speed max 100x':'multiplier > 100.0' in legacy and 'mult > 100.0' in legacy,
 'DWORD alias':'isEqualToString:@"DWORD"' in mem,
 'UTF8 NUL terminator':'out[d.length] = 0;' in mem,
 'SpringBoard-only injection retained':'com.apple.springboard' in (root/'Huluxia.plist').read_text() and 'com.apple.UIKit' not in (root/'Huluxia.plist').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit(1)
with (root/'Huluxia.plist').open('rb') as f: plistlib.load(f)
print('PASS: plist parses')
