#!/bin/bash
# Create a TrollStore-style companion IPA with Huluxia.dylib embedded in the launcher app.
# Requires macOS/Xcode codesign, dpkg-deb, zip, and a rootful build of the launcher app.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$ROOT/out}"
# Resolve OUT before entering the temporary directory; otherwise the IPA is
# accidentally written under TMP/out and deleted by the EXIT trap.
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd)"
DEB="${2:-}"
DYLIB="$OUT/Huluxia.dylib"

if [[ -z "$DEB" ]]; then
  for candidate in "$OUT"/*rootful.deb "$OUT"/*.deb; do
    [[ -f "$candidate" ]] && { DEB="$candidate"; break; }
  done
fi
[[ -f "$DEB" ]] || { echo "Missing rootful DEB (usage: $0 [out-dir] [rootful.deb])" >&2; exit 1; }
[[ -f "$DYLIB" ]] || { echo "Missing $DYLIB; run build_dylib.sh first" >&2; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/extracted" "$TMP/Payload"
dpkg-deb -x "$DEB" "$TMP/extracted"
APP="$(find "$TMP/extracted" -type d -name 'Huluxia.app' -print -quit)"
[[ -n "$APP" && -f "$APP/Huluxia" ]] || { echo "Huluxia.app not found in $DEB" >&2; exit 1; }

cp -R "$APP" "$TMP/Payload/Huluxia.app"
mkdir -p "$TMP/Payload/Huluxia.app/Frameworks"
cp "$DYLIB" "$TMP/Payload/Huluxia.app/Frameworks/Huluxia.dylib"

# Ad-hoc sign the embedded library and app bundle. TrollStore applies its own installation signing.
codesign --force --sign - --timestamp=none "$TMP/Payload/Huluxia.app/Frameworks/Huluxia.dylib"
codesign --force --deep --sign - --timestamp=none "$TMP/Payload/Huluxia.app"
codesign --verify --deep --strict "$TMP/Payload/Huluxia.app"
rm -f "$OUT/Huluxia_TrollStore.ipa"
(cd "$TMP" && /usr/bin/zip -qry "$OUT/Huluxia_TrollStore.ipa" Payload)

unzip -l "$OUT/Huluxia_TrollStore.ipa" | grep -q 'Payload/Huluxia.app/Frameworks/Huluxia.dylib' || {
  echo "IPA verification failed: embedded dylib missing" >&2; exit 1;
}
echo "OK -> $OUT/Huluxia_TrollStore.ipa"
