#!/bin/bash
# macOS verifier for the DEB, standalone dylib, and embedded TrollStore companion IPA.
set -euo pipefail
cd "$(dirname "$0")"
OUT="${1:-out}"
fail() { echo "❌ $*" >&2; exit 1; }
ok()   { echo "✅ $*"; }
sha()  { shasum -a 256 "$1" | awk '{print $1}'; }

shopt -s nullglob
debs=("$OUT"/*.deb)
[ "${#debs[@]}" -ge 2 ] || fail "$OUT 里需要 rootful 和 rootless 两个 deb"
[ -f "$OUT/Huluxia.dylib" ] || fail "$OUT/Huluxia.dylib 不存在"
[ -f "$OUT/Huluxia_TrollStore.ipa" ] || fail "$OUT/Huluxia_TrollStore.ipa 不存在"

WANT_UI=$(sha Resources/ui.html)
WANT_BALL=$(sha Resources/ball.png)
WANT_I2=$(sha Launcher/Resources/Icon@2x.png)
WANT_I3=$(sha Launcher/Resources/Icon@3x.png)
WANT_VER=$(awk -F': ' '/^Version:/{print $2}' control)
WANT_APPVER=$(grep -o "APP_VERSION = '[^']*'" Resources/ui.html | sed "s/.*'\(.*\)'/\1/")
[ "$WANT_VER" = "$WANT_APPVER" ] || fail "control 版本($WANT_VER) 与 ui.html APP_VERSION($WANT_APPVER) 不一致"

check_dylib() {
  local d="$1" tmp archs a thin sec want got count
  tmp=$(mktemp -d)
  archs=$(lipo -archs "$d")
  echo "   架构: $archs"
  count=$(echo "$archs" | wc -w | tr -d ' ')
  for a in $archs; do
    if [ "$count" = "1" ]; then thin="$d"; else thin="$tmp/$a.dylib"; lipo "$d" -thin "$a" -output "$thin"; fi
    for sec in "hlxui:$WANT_UI" "hlxball:$WANT_BALL"; do
      want="${sec##*:}"; sec="${sec%%:*}"
      segedit "$thin" -extract __DATA "__$sec" "$tmp/$a.$sec" >/dev/null 2>&1 || fail "$d [$a] 缺少 __DATA,__$sec 段"
      got=$(sha "$tmp/$a.$sec")
      [ "$got" = "$want" ] || fail "$d [$a] 内嵌的 $sec 与仓库资源不一致"
    done
  done
  rm -rf "$tmp"
}

echo "── standalone dylib ──"
check_dylib "$OUT/Huluxia.dylib"
ok "standalone dylib 内嵌 ui.html / ball.png 与仓库一致"

for deb in "${debs[@]}"; do
  echo "── $(basename "$deb") ──"
  tmp=$(mktemp -d); dpkg-deb -x "$deb" "$tmp/root"; dpkg-deb -e "$deb" "$tmp/DEBIAN"
  [ "$(dpkg-deb -f "$deb" Version)" = "$WANT_VER" ] || fail "deb 版本 $(dpkg-deb -f "$deb" Version) != $WANT_VER"
  [ "$(dpkg-deb -f "$deb" Package)" = "com.huluxia.tweak" ] || fail "包名不对"
  dpkg-deb -f "$deb" Depends | grep -q mobilesubstrate || fail "Depends 缺少 mobilesubstrate"

  dylib=$(find "$tmp/root" -path '*MobileSubstrate/DynamicLibraries/Huluxia.dylib' | head -1); [ -n "$dylib" ] || fail "deb 里没有 Huluxia.dylib"
  filt=$(find "$tmp/root" -path '*MobileSubstrate/DynamicLibraries/Huluxia.plist' | head -1); [ -n "$filt" ] || fail "deb 里没有 Huluxia.plist"
  plutil -convert xml1 -o - "$filt" | grep -q 'com.apple.springboard' || fail "Huluxia.plist 的 Filter 缺少 com.apple.springboard"
  check_dylib "$dylib"

  app=$(find "$tmp/root" -type d -name 'Huluxia.app' | head -1); [ -n "$app" ] || fail "deb 里没有 Huluxia.app"
  [ -x "$app/Huluxia" ] || fail "Huluxia.app 主程序缺失/不可执行"
  [ "$(sha "$app/Icon@2x.png")" = "$WANT_I2" ] || fail "桌面图标 Icon@2x.png 不正确"
  [ "$(sha "$app/Icon@3x.png")" = "$WANT_I3" ] || fail "桌面图标 Icon@3x.png 不正确"
  plutil -p "$app/Info.plist" | grep -q 'CFBundleIconFiles' || fail "Info.plist 没有 CFBundleIconFiles"
  [ "$(plutil -extract CFBundleShortVersionString raw "$app/Info.plist")" = "$WANT_VER" ] || fail "Launcher 版本与 deb 不一致"
  for f in postinst postrm; do [ -x "$tmp/DEBIAN/$f" ] || fail "缺少可执行的 DEBIAN/$f"; done
  ok "$(basename "$deb") 内容与源码资源匹配"
  rm -rf "$tmp"
done

echo "── TrollStore companion IPA ──"
tmpi=$(mktemp -d)
unzip -q "$OUT/Huluxia_TrollStore.ipa" -d "$tmpi"
app="$tmpi/Payload/Huluxia.app"
[ -x "$app/Huluxia" ] || fail "IPA 内 Launcher 主程序缺失"
[ -f "$app/Frameworks/Huluxia.dylib" ] || fail "IPA 内未嵌入 Frameworks/Huluxia.dylib"
[ "$(plutil -extract CFBundleIdentifier raw "$app/Info.plist")" = "com.huluxia.launcher" ] || fail "IPA Bundle ID 不正确"
check_dylib "$app/Frameworks/Huluxia.dylib"
ok "TrollStore IPA 内已嵌入独立 DYLIB"
rm -rf "$tmpi"
echo "全部静态构建校验通过（不代表已在实机验证安全模式问题）"
