#import "HLXOverlay.h"
#import "HLXBridge.h"
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <dlfcn.h>
#import <mach-o/getsect.h>
#import <mach-o/dyld.h>
#import <objc/message.h>

static void HLXLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1,2);
static void HLXLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *m = [[NSString alloc] initWithFormat:fmt arguments:ap]; va_end(ap);
    NSLog(@"[Huluxia] %@", m);
    NSString *line = [NSString stringWithFormat:@"%@ %@\n", [NSDate date], m];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/huluxia.log"];
    if (!h) { [line writeToFile:@"/var/mobile/huluxia.log" atomically:NO encoding:NSUTF8StringEncoding error:nil]; return; }
    [h seekToEndOfFile]; [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
}

static NSString *const kMark = @"\x01HLX\x01";
static const CGSize kBallWindow = { 66, 72 };     // 悬浮球：48 + right:18 / bottom:24

// ───────── 加载 UI（优先读 dylib 内嵌段，其次读磁盘）─────────
static void HLXAnchor(void) {}
static NSData *HLXSection(const char *name) {
    Dl_info info;
    if (dladdr((void *)&HLXAnchor, &info) && info.dli_fbase) {
        unsigned long sz = 0;
        uint8_t *p = getsectiondata((const struct mach_header_64 *)info.dli_fbase, "__DATA", name, &sz);
        if (p && sz) return [NSData dataWithBytes:p length:sz];
    }
    return nil;
}
static NSString *HLXLoadUI(void) {
    NSData *d = HLXSection("__hlxui");
    NSString *e = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : nil;
    if (e) return e;
    for (NSString *path in @[ @"/var/jb/Library/Application Support/Huluxia/ui.html", @"/Library/Application Support/Huluxia/ui.html" ]) {
        NSString *s = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        if (s) return s;
    }
    return @"<html><body style='background:#222;color:#fff;font:16px sans-serif;padding:20px'>未找到内嵌界面（__hlxui 段）</body></html>";
}


static NSString *const kMarkP = @"\x01HLXP\x01";      // 页面→原生 的异步消息（窗口位置等），UIWebView 没有 messageHandlers，也走 prompt
static BOOL HLXIsSB(void) { return [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]; }

@class HLXRootVC;
static __weak HLXRootVC *gRoot;

// 同步等待异步结果。UIWebView 的 JS 对话框回调是在 WebThread 上调用的，不是主线程：
//  - 在主线程：嵌套 runloop（UI 不卡）
//  - 在其他线程：信号量等待（主线程照常工作）
static NSString *HLXBridgeSync(NSString *payload) {
    __block NSString *res = nil;
    if (NSThread.isMainThread) {
        __block BOOL done = NO;
        [HLXBridge handlePayload:payload completion:^(NSString *j) { res = j; done = YES; }];
        while (!done) CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.01, true);
    } else {
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        [HLXBridge handlePayload:payload completion:^(NSString *j) { res = j; dispatch_semaphore_signal(sem); }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    }
    return res ?: @"";
}
static void HLXOnMain(void (^blk)(void)) { if (NSThread.isMainThread) blk(); else dispatch_async(dispatch_get_main_queue(), blk); }

// ───────── 窗口 / 控制器 ─────────
@interface HLXRootVC : UIViewController <WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler, UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIView *web;        // WKWebView（App 内）或 UIWebView（SpringBoard 内，和 H5GG 一样）
@property (nonatomic, strong) UILabel *status;
@property (nonatomic, weak) UIWindow *hostWindow;
@property (nonatomic, assign) CGRect expanded;
@property (nonatomic, assign) CGRect dragRect;
@property (nonatomic, assign) BOOL collapsed;
@property (nonatomic, assign) CGPoint panStart;
@property (nonatomic, assign) CGRect panFrame;
- (void)applyFrame;
- (void)callLayout;
- (void)handleMessage:(NSDictionary *)d;
- (void)pageDidFinish;
- (void)pageDidFail:(NSString *)why;
- (void)js:(NSString *)code;
@end

@implementation HLXRootVC

- (void)js:(NSString *)code {
    if ([self.web isKindOfClass:WKWebView.class]) [(WKWebView *)self.web evaluateJavaScript:code completionHandler:nil];
    else ((id (*)(id, SEL, id))objc_msgSend)(self.web, NSSelectorFromString(@"stringByEvaluatingJavaScriptFromString:"), code);
}

// SpringBoard 使用 UIWebView，避免依赖独立的 WebContent 进程。
// 注意：JS prompt 的回调必须由真正的 delegate（HLXRootVC）实现，不能加在 UIWebView 子类上。

- (void)webViewDidFinishLoad:(id)w { [self pageDidFinish]; }
- (void)webView:(id)w didFailLoadWithError:(NSError *)e { [self pageDidFail:[NSString stringWithFormat:@"%@", e]]; }

// UIWebView 的 JS 桥接回调必须放在 delegate 对象（HLXRootVC）上。
- (NSString *)webView:(id)webView
runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt
          defaultText:(NSString *)defaultText
     initiatedByFrame:(id)frame {
    if ([prompt hasPrefix:kMark]) {
        return HLXBridgeSync([prompt substringFromIndex:kMark.length]);
    }
    if ([prompt hasPrefix:kMarkP]) {
        NSData *data = [[prompt substringFromIndex:kMarkP.length] dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *message = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        if ([message isKindOfClass:NSDictionary.class]) HLXOnMain(^{ [gRoot handleMessage:message]; });
        return @"";
    }
    return defaultText ?: @"";
}

- (void)webView:(id)webView
runJavaScriptAlertPanelWithMessage:(NSString *)message
     initiatedByFrame:(id)frame {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    HLXOnMain(^{ if (gRoot.presentedViewController == nil) [gRoot presentViewController:alert animated:YES completion:nil]; });
}

- (BOOL)webView:(id)webView
runJavaScriptConfirmPanelWithMessage:(NSString *)message
     initiatedByFrame:(id)frame {
    __block BOOL finished = NO;
    __block BOOL confirmed = NO;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { finished = YES; }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { confirmed = YES; finished = YES; }]];
    HLXOnMain(^{ if (gRoot.presentedViewController == nil) [gRoot presentViewController:alert animated:YES completion:nil]; else finished = YES; });
    while (!finished) {
        if (NSThread.isMainThread) CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.01, true);
        else usleep(10000);
    }
    return confirmed;
}

- (void)loadView {
    gRoot = self;
    NSString *html = HLXLoadUI();
    Class legacyWebView = HLXIsSB() ? NSClassFromString(@"UIWebView") : Nil;
    if (legacyWebView) {
        HLXLog(@"step: create UIWebView");
        UIView *wv = [[legacyWebView alloc] initWithFrame:CGRectZero];
        HLXLog(@"step: created");
        [wv setValue:self forKey:@"delegate"];
        wv.opaque = NO; wv.backgroundColor = UIColor.clearColor;
        UIScrollView *sv = [wv valueForKey:@"scrollView"];
        sv.backgroundColor = UIColor.clearColor; sv.scrollEnabled = NO; sv.bounces = NO;
        HLXLog(@"step: configured");
        self.web = wv;
        // UIWebView 没有 user script：把桥接脚本直接塞进 HTML 的 <head>
        NSString *inj = [NSString stringWithFormat:@"<head><script>%@</script>", HLXBridge.bootstrapScript];
        NSRange r = [html rangeOfString:@"<head>"];
        html = (r.location != NSNotFound) ? [html stringByReplacingCharactersInRange:r withString:inj] : [inj stringByAppendingString:html];
        HLXLog(@"engine = UIWebView");
    } else {
        WKWebViewConfiguration *cfg = [WKWebViewConfiguration new];
        WKUserContentController *ucc = [WKUserContentController new];
        [ucc addScriptMessageHandler:self name:@"hlx"];
        [ucc addUserScript:[[WKUserScript alloc] initWithSource:HLXBridge.bootstrapScript injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO]];
        cfg.userContentController = ucc;
        cfg.allowsInlineMediaPlayback = YES;
        WKWebView *wk = [[WKWebView alloc] initWithFrame:CGRectZero configuration:cfg];
        wk.UIDelegate = self;
        wk.navigationDelegate = self;
        wk.opaque = NO;
        wk.backgroundColor = UIColor.clearColor;
        wk.scrollView.backgroundColor = UIColor.clearColor;
        wk.scrollView.scrollEnabled = NO;
        wk.scrollView.bounces = NO;
        wk.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        if (@available(iOS 16.4, *)) wk.inspectable = YES;
        self.web = wk;
        HLXLog(@"engine = WKWebView");
    }
    self.view = self.web;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    pan.delegate = self; pan.cancelsTouchesInView = NO; pan.maximumNumberOfTouches = 1;
    [self.web addGestureRecognizer:pan];

    { CGSize sc = UIScreen.mainScreen.bounds.size; CGFloat w = MIN(390, sc.width), h = MIN(580, sc.height); self.expanded = CGRectMake((sc.width - w) / 2, (sc.height - h) / 2, w, h); }
    // 原生状态条：页面没加载出来时，至少能看到原因
    self.status = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 390, 580)];
    self.status.numberOfLines = 0; self.status.textAlignment = NSTextAlignmentLeft;
    self.status.lineBreakMode = NSLineBreakByCharWrapping;
    self.status.adjustsFontSizeToFitWidth = YES; self.status.minimumScaleFactor = 0.6;
    self.status.userInteractionEnabled = YES;
    [self.status addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(copyStatus)]];
    self.status.textColor = UIColor.whiteColor; self.status.font = [UIFont systemFontOfSize:12];
    self.status.backgroundColor = [UIColor colorWithWhite:0.1 alpha:0.92];
    self.status.text = @"葫芦侠 加载中…\n（如果一直停在这里，说明 WebKit 没在 SpringBoard 里跑起来）";
    [self.web addSubview:self.status];
    HLXLog(@"loadView, ui bytes=%lu", (unsigned long)html.length);
    __weak HLXRootVC *ws = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if (ws.status.superview) { ws.status.text = @"加载超时：网页引擎没有返回页面。\n请查看 /var/mobile/huluxia.log"; HLXLog(@"load timeout"); [ws reveal]; }
    });
    // 用固定的 https 源，localStorage（收藏/脚本/主题）才能跨次保存
    if ([self.web isKindOfClass:WKWebView.class]) [(WKWebView *)self.web loadHTMLString:html baseURL:[NSURL URLWithString:@"https://huluxia.local/"]];
    else ((void (*)(id, SEL, id, id))objc_msgSend)(self.web, NSSelectorFromString(@"loadHTMLString:baseURL:"), html, [NSURL URLWithString:@"https://huluxia.local/"]);
}

// 作为 key window 时别去改宿主 App 的方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UIInterfaceOrientation o = UIInterfaceOrientationPortrait;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class]) { o = ((UIWindowScene *)s).interfaceOrientation; break; }
    return (UIInterfaceOrientationMask)(1 << o);
}
- (BOOL)prefersStatusBarHidden { return YES; }

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.status.frame = CGRectInset(self.web.bounds, 8, 8);     // 始终贴合窗口，文字不会被裁到屏幕外
}
- (void)copyStatus { UIPasteboard.generalPasteboard.string = self.status.text; self.status.text = [self.status.text stringByAppendingString:@"\n\n（已复制）"]; }
- (void)reveal { self.hostWindow.alpha = 1; }

#pragma mark 窗口几何

- (CGSize)screenSize { return UIScreen.mainScreen.bounds.size; }

- (CGRect)clamp:(CGRect)r {
    CGSize s = [self screenSize];
    r.size.width = MIN(r.size.width, s.width); r.size.height = MIN(r.size.height, s.height);
    r.origin.x = MAX(0, MIN(r.origin.x, s.width - r.size.width));
    r.origin.y = MAX(0, MIN(r.origin.y, s.height - r.size.height));
    return r;
}

- (void)applyFrame {
    if (!self.hostWindow) return;
    CGRect f = self.collapsed
        ? CGRectMake(CGRectGetMaxX(self.expanded) - kBallWindow.width, CGRectGetMaxY(self.expanded) - kBallWindow.height, kBallWindow.width, kBallWindow.height)
        : self.expanded;
    self.hostWindow.frame = [self clamp:f];
}

- (void)callLayout {
    CGSize s = [self screenSize];
    NSString *js = [NSString stringWithFormat:@"window.__hlxLayout && window.__hlxLayout(%g,%g)", s.width, s.height];
    [self js:js];
}

#pragma mark JS → 原生消息

- (void)userContentController:(WKUserContentController *)c didReceiveScriptMessage:(WKScriptMessage *)msg {
    if ([msg.body isKindOfClass:NSDictionary.class]) [self handleMessage:msg.body];
}

- (void)handleMessage:(NSDictionary *)d {
    HLXLog(@"msg %@", d[@"t"]);
    NSString *t = d[@"t"];
    NSArray *r = d[@"r"];
    if ([t isEqualToString:@"rect"] && r.count == 4) {
        self.expanded = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
        [self applyFrame];
        [self reveal];                                // 页面把窗口摆好位置后再显示，避免先出现在左上角再跳到中间
    } else if ([t isEqualToString:@"drag"] && r.count == 4) {
        self.dragRect = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
    } else if ([t isEqualToString:@"visible"]) {
        if (![d[@"v"] boolValue]) [HLXOverlay.shared hide]; else [HLXOverlay.shared show];
    } else if ([t isEqualToString:@"layout"]) {
        [self callLayout];
    } else if ([t isEqualToString:@"collapsed"]) {
        BOOL c2 = [d[@"v"] boolValue];
        if (c2) {   // 页面自带的小球不用，改由原生悬浮球负责：还原页面并收起窗口
            [self js:@"var a=document.getElementById('app'),f=document.getElementById('float');if(a)a.style.display='flex';if(f)f.style.display='none';"];
            [HLXOverlay.shared hide];
            return;
        }
        if (c2 == self.collapsed) return;
        if (!c2) {                                    // 展开：让展开窗口的右下角对齐当前悬浮球
            CGRect ball = self.hostWindow.frame;
            CGRect e = self.expanded;
            e.origin = CGPointMake(CGRectGetMaxX(ball) - e.size.width, CGRectGetMaxY(ball) - e.size.height);
            self.expanded = [self clamp:e];
        }
        self.collapsed = c2;
        [self applyFrame];
    }
}

#pragma mark 拖动

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)g {
    if (![g isKindOfClass:UIPanGestureRecognizer.class]) return YES;
    if (self.collapsed) return YES;                                       // 悬浮球整块可拖
    CGPoint p = [g locationInView:self.web];
    return CGRectContainsPoint(self.dragRect, p);                         // 展开时只有拖拽栏可拖
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)a shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)b { return YES; }

- (void)onPan:(UIPanGestureRecognizer *)g {
    UIView *v = self.web;
    CGPoint p = [v.coordinateSpace convertPoint:[g locationInView:v] toCoordinateSpace:UIScreen.mainScreen.coordinateSpace];
    if (g.state == UIGestureRecognizerStateBegan) { self.panStart = p; self.panFrame = self.hostWindow.frame; }
    else if (g.state == UIGestureRecognizerStateChanged) {
        CGRect f = self.panFrame;
        f.origin.x += p.x - self.panStart.x; f.origin.y += p.y - self.panStart.y;
        f = [self clamp:f];
        self.hostWindow.frame = f;
        if (!self.collapsed) self.expanded = f;
    }
}

#pragma mark 加载状态

- (void)pageDidFinish { HLXLog(@"didFinish"); [self.status removeFromSuperview]; [self callLayout]; [self reveal]; }
- (void)pageDidFail:(NSString *)why { HLXLog(@"didFail %@", why); self.status.text = [NSString stringWithFormat:@"加载失败（点一下复制）：\n%@", why]; [self reveal]; }
- (void)webView:(WKWebView *)w didFinishNavigation:(WKNavigation *)n { [self pageDidFinish]; }
- (void)webView:(WKWebView *)w didFailNavigation:(WKNavigation *)n withError:(NSError *)e {
    HLXLog(@"didFail %@", e); self.status.text = [NSString stringWithFormat:@"加载失败（点一下复制）：\n%@", e]; [self reveal]; }
- (void)webView:(WKWebView *)w didFailProvisionalNavigation:(WKNavigation *)n withError:(NSError *)e {
    HLXLog(@"didFailProvisional %@", e); self.status.text = [NSString stringWithFormat:@"加载失败（点一下复制）：\n%@", e]; [self reveal]; }
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)w {
    HLXLog(@"web content process terminated"); self.status.text = @"WebContent 进程被终止（SpringBoard 里 WKWebView 不可用？）"; [self reveal]; }

#pragma mark 同步桥 + 原生对话框

- (void)webView:(WKWebView *)w runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)def
initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(NSString *))done {
    if ([prompt hasPrefix:kMark]) {
        [HLXBridge handlePayload:[prompt substringFromIndex:kMark.length] completion:done];
        return;
    }
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:prompt preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.text = def; }];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(nil); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(ac.textFields.firstObject.text ?: @""); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptAlertPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(void))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptConfirmPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(BOOL))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(NO); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(YES); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
@end


// ───────── 原生悬浮球（像 iGG / H5GG）─────────
@interface HLXBallVC : UIViewController @end
@implementation HLXBallVC
- (BOOL)prefersStatusBarHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UIInterfaceOrientation o = UIInterfaceOrientationPortrait;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class]) { o = ((UIWindowScene *)s).interfaceOrientation; break; }
    return (UIInterfaceOrientationMask)(1 << o);
}
@end

@interface HLXBallHandler : NSObject
@property (nonatomic, weak) UIWindow *win;
@end
@implementation HLXBallHandler
- (void)tap { [HLXOverlay.shared toggle]; }
- (void)pan:(UIPanGestureRecognizer *)g {
    UIWindow *w = self.win; if (!w) return;
    CGPoint t = [g translationInView:w.rootViewController.view];
    [g setTranslation:CGPointZero inView:w.rootViewController.view];
    CGSize sc = UIScreen.mainScreen.bounds.size; CGRect f = w.frame;
    f.origin.x = MAX(0, MIN(f.origin.x + t.x, sc.width - f.size.width));
    f.origin.y = MAX(0, MIN(f.origin.y + t.y, sc.height - f.size.height));
    w.frame = f;
    if (g.state == UIGestureRecognizerStateEnded) {      // 松手吸附到左右边缘
        f.origin.x = (CGRectGetMidX(f) < sc.width / 2) ? 4 : sc.width - f.size.width - 4;
        [UIView animateWithDuration:0.2 animations:^{ w.frame = f; }];
    }
}
@end

// ───────── 管理器 ─────────
@implementation HLXOverlay {
    UIWindow *_window; HLXRootVC *_vc; __weak UIWindow *_prevKey; UIWindow *_ball; id _ballHandler;
}

+ (instancetype)shared {
    static HLXOverlay *o; static dispatch_once_t once;
    dispatch_once(&once, ^{ o = [HLXOverlay new]; });
    return o;
}

- (UIWindow *)makeWindow {
    UIWindow *w = nil;
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = nil;
        // 优先用 ForegroundActive 的 scene；SpringBoard 里找不到就退回第一个 connected scene
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
            if ([s isKindOfClass:UIWindowScene.class]) { scene = (UIWindowScene *)s; if (s.activationState == UISceneActivationStateForegroundActive) break; }
        w = scene ? [[UIWindow alloc] initWithWindowScene:scene] : [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    } else {
        w = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    }
    w.windowLevel = UIWindowLevelAlert + 2.0;
    w.backgroundColor = UIColor.clearColor;
    return w;
}

- (void)showBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->_ball) { self->_ball.hidden = NO; return; }
        CGFloat D = 56; CGSize sc = UIScreen.mainScreen.bounds.size;
        UIWindow *w = [self makeWindow];
        w.windowLevel = UIWindowLevelAlert + 3.0;
        w.frame = CGRectMake(sc.width - D - 6, sc.height * 0.35, D, D);
        w.rootViewController = [HLXBallVC new];
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, D, D)];
        NSData *d = HLXSection("__hlxball");
        iv.image = d ? [UIImage imageWithData:d] : nil;
        iv.backgroundColor = iv.image ? UIColor.clearColor : [UIColor colorWithRed:0.18 green:0.49 blue:0.2 alpha:1];
        iv.contentMode = UIViewContentModeScaleAspectFill;
        iv.layer.cornerRadius = D / 2; iv.clipsToBounds = YES; iv.alpha = 0.92;
        iv.userInteractionEnabled = YES;
        HLXBallHandler *h = [HLXBallHandler new]; h.win = w; self->_ballHandler = h;
        [iv addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:h action:@selector(tap)]];
        [iv addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:h action:@selector(pan:)]];
        [w.rootViewController.view addSubview:iv];
        w.hidden = NO; self->_ball = w;
    });
}

- (void)hideBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        self->_ball.hidden = YES;
    });
}

- (void)toggleBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->_ball && !self->_ball.hidden) {
            self->_ball.hidden = YES;
        } else {
            [self showBall];
        }
    });
}

- (void)ensure {
    if (_window) return;
    _vc = [HLXRootVC new];
    _window = [self makeWindow];
    _window.rootViewController = _vc;
    _vc.hostWindow = _window;
    _window.alpha = 0;                                // 页面就绪前不可见
    [_vc applyFrame];
    [[NSNotificationCenter defaultCenter] addObserverForName:UIDeviceOrientationDidChangeNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
        // 旋转后让页面按新尺寸重新布局（页面的 setLayoutAction 会再次调用 setWindowRect）
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self->_vc callLayout]; });
    }];
}

- (void)show {
    dispatch_async(dispatch_get_main_queue(), ^{
        HLXLog(@"show");
        [self ensure];
        self->_window.hidden = NO;
        [self->_vc applyFrame];
        [self->_vc callLayout];
    });
}
- (void)hide {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->_window) return;
        self->_window.hidden = YES;
    });
}
- (void)toggle {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->_window || self->_window.hidden) [self show]; else [self hide];
    });
}
@end
