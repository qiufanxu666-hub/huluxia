// HLXTouch.h — 触摸注入（IOHIDEvent 私有 API，运行时 dlsym，不依赖链接）
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface HLXTouch : NSObject
// 以下方法会 sleep，请在后台线程调用；坐标为“当前界面方向下的屏幕点坐标”
+ (BOOL)available;
+ (void)tap:(CGPoint)p;
+ (void)longPress:(CGPoint)p ms:(int)ms;
+ (void)swipe:(CGPoint)a to:(CGPoint)b ms:(int)ms;
+ (void)down:(CGPoint)p;
+ (void)move:(CGPoint)p;
+ (void)up:(CGPoint)p;
@end
