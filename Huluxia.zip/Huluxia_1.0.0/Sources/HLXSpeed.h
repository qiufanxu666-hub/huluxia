// HLXSpeed.h — 变速（hook 时间函数；宿主进程通过 Darwin 通知把倍率发给目标进程里的“代理”）
#import <Foundation/Foundation.h>

@interface HLXSpeed : NSObject
// 目标进程内：启动代理（安装 hook + 监听倍率通知）
+ (void)startAgent;
// 本进程直接变速（UI 和游戏在同一进程时）
+ (BOOL)applyLocal:(double)mult error:(NSString **)err;
// 宿主进程（SpringBoard）：把倍率发给 pid 里的代理
+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err;
+ (double)current;
@end
