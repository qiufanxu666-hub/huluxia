#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <os/lock.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>
#import <math.h>
#import <unistd.h>
#import <string.h>

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock gInstallLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock gRebaseLock = OS_UNFAIR_LOCK_INIT;
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono;                // mach ticks / CLOCK_MONOTONIC ns
// 不缩放 CLOCK_REALTIME/gettimeofday：改变墙上时钟会破坏系统超时、证书和网络逻辑。

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

static inline uint64_t HLXScaleLocked(const HLXBase *b, uint64_t real) {
    // 1.0x 也必须经过基准映射：直接返回 real 会在从其他倍率切回 1x 时
    // 让单调时钟突然跳回真实时间，破坏 dispatch / CADisplayLink / 游戏计时器。
    if (real <= b->realBase) return b->virtBase;
    long double delta = (long double)(real - b->realBase) * (long double)gSpeed;
    long double value = (long double)b->virtBase + delta;
    if (value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    os_unfair_lock_lock(&gLock);
    uint64_t value = HLXScaleLocked(b, real);
    os_unfair_lock_unlock(&gLock);
    return value;
}

static uint64_t h_mach_absolute_time(void) {
    return scale(&gMach, o_mach_absolute_time());
}

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts || c != CLOCK_MONOTONIC) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    ns = scale(&gMono, ns);
    ts->tv_sec = (time_t)(ns / 1000000000ULL);
    ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    // RAW / UPTIME / REALTIME 各有自己的时钟语义，不混用 MONOTONIC 基准。
    return c == CLOCK_MONOTONIC ? scale(&gMono, ns) : ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    // 墙钟必须保持真实时间，不能随游戏倍率一起快进/倒退。
    return o_gettimeofday(tv, tz);
}

static BOOL rebase(double newSpeed) {
    // 序列化倍率更新，防止两个线程先后取样、反向拿锁而把较旧的基准写回。
    os_unfair_lock_lock(&gRebaseLock);
    if (!o_mach_absolute_time || !o_clock_gettime) {
        os_unfair_lock_unlock(&gRebaseLock);
        return NO;
    }
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts = {0};
    if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        os_unfair_lock_unlock(&gRebaseLock);
        return NO;
    }
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;

    os_unfair_lock_lock(&gLock);
    uint64_t vm = HLXScaleLocked(&gMach, rm);
    uint64_t vn = HLXScaleLocked(&gMono, rn);
    gMach.realBase = rm;
    gMach.virtBase = vm;
    gMono.realBase = rn;
    gMono.virtBase = vn;
    gSpeed = newSpeed;
    os_unfair_lock_unlock(&gLock);
    os_unfair_lock_unlock(&gRebaseLock);
    return YES;
}

// ───────── 变速后端选择 ─────────
// 普通侧载：不尝试改写 Mach-O GOT/链式修复指针（尤其不能把未签名指针写入 arm64e AUTH 段）。
// 走 UI 中保留的旧版路径：游戏自身公开的原生变速接口 -> 用户指定的内存锚点。
// 越狱环境：仅当 Substrate/ElleKit 兼容的 MSHookFunction 确实可用时，启用进程内时间 Hook。
static MSHookFunction_t HLXResolveHookBackend(void) {
    return (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
}

static BOOL HLXHasJailbreakHookBackend(void) {
    return HLXResolveHookBackend() != NULL;
}

static NSString *HLXBackendMode(void) {
    return HLXHasJailbreakHookBackend() ? @"jailbreak-hook" : @"sideload-legacy";
}

static BOOL install(NSString **err) {
    os_unfair_lock_lock(&gInstallLock);
    if (gInstalled) { os_unfair_lock_unlock(&gInstallLock); return YES; }

    MSHookFunction_t hook = HLXResolveHookBackend();
    if (!hook) {
        if (err) *err = @"当前为普通侧载模式：不依赖越狱基板。请使用游戏原生变速接口；未命中时使用内存锚点降级。";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }

    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) {
        if (err) *err = @"越狱 Hook 模式：系统时钟符号解析失败";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }

    // Hook 前用原始入口初始化真实/虚拟时间基准。
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts = {0};
    if (((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts) != 0) {
        if (err) *err = @"越狱 Hook 模式：CLOCK_MONOTONIC 初始化失败";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    gMono = (HLXBase){ n, n };

    // 仅在真实存在 MSHookFunction 的越狱环境调用。普通侧载永远不会走到这里。
    hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
    hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
    hook(sym_gtd, (void *)h_gettimeofday,       (void **)&o_gettimeofday);
    if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);

    if (!o_mach_absolute_time || !o_clock_gettime || !o_gettimeofday) {
        if (err) *err = @"越狱 Hook 后端未返回完整原函数入口，已拒绝启用变速";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }
    gInstalled = YES;
    os_unfair_lock_unlock(&gInstallLock);
    return YES;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current {
    os_unfair_lock_lock(&gLock);
    double value = gSpeed;
    os_unfair_lock_unlock(&gLock);
    return value;
}

+ (NSString *)backendMode { return HLXBackendMode(); }

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x；0x 暂停会冻结时间源，已禁用"; return NO; }
    // SpringBoard / 葫芦侠启动器只是控制端，不能对自身做时钟 Hook 或内存锚点写入。
    // 这个错误标记会让前端停止回退，避免误把锚点写入桌面/控制器进程。
    NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
    if ([bid isEqualToString:@"com.apple.springboard"] || [bid isEqualToString:@"com.huluxia.launcher"]) {
        if (err) *err = @"当前是桌面/控制器进程，已阻止修改宿主时钟和内存锚点；请在已注入的目标 App 内操作";
        return NO;
    }
    // 无越狱基板时，绝不假装系统时钟 Hook 已启用；把控制权交还 UI 的旧版原生 API / 内存锚点降级路径。
    if (!HLXHasJailbreakHookBackend()) {
        if (err) *err = @"普通侧载模式：时间 Hook 不可用，改走旧版原生变速接口 / 内存锚点方式";
        return NO;
    }
    if (!install(err)) return NO;
    if (!rebase(mult)) { if (err) *err = @"切换时钟基准失败，倍率未应用"; return NO; }
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!HLXHasJailbreakHookBackend()) {
        NSLog(@"[Huluxia] 普通侧载模式：保留原生 API / 内存锚点变速，不启动越狱时间代理");
        return;
    }
    if (!install(&err)) {
        NSLog(@"[Huluxia] 变速代理启动失败：%@", err ?: @"unknown");
        return;
    }
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (isfinite(m) && m >= 0.1 && m <= 10.0) {
            if (!rebase(m)) NSLog(@"[Huluxia] speed rebase failed for pid %d", me);
        }
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x；0x 暂停会冻结时间源，已禁用"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Huluxia 代理：把目标 App 的 Bundle ID 加进 Huluxia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
