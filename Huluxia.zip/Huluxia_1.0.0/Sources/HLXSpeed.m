#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <os/lock.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach/mach.h>
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono, gWall;        // mach ticks / 单调 ns / 墙钟 ns

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    os_unfair_lock_lock(&gLock);
    double sp = gSpeed; uint64_t rb = b->realBase, vb = b->virtBase;
    os_unfair_lock_unlock(&gLock);
    if (real < rb) return real;
    return vb + (uint64_t)((double)(real - rb) * sp);
}

static uint64_t h_mach_absolute_time(void) { return scale(&gMach, o_mach_absolute_time()); }

static BOOL isMono(clockid_t c) { return c == CLOCK_MONOTONIC || c == CLOCK_MONOTONIC_RAW || c == CLOCK_UPTIME_RAW; }

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    if (isMono(c))               ns = scale(&gMono, ns);
    else if (c == CLOCK_REALTIME) ns = scale(&gWall, ns);
    else return r;
    ts->tv_sec = (time_t)(ns / 1000000000ULL); ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    if (isMono(c))               return scale(&gMono, ns);
    if (c == CLOCK_REALTIME)     return scale(&gWall, ns);
    return ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    int r = o_gettimeofday(tv, tz);
    if (r != 0 || !tv) return r;
    uint64_t ns = ((uint64_t)tv->tv_sec * 1000000ULL + (uint64_t)tv->tv_usec) * 1000ULL;
    ns = scale(&gWall, ns);
    tv->tv_sec = (time_t)(ns / 1000000000ULL); tv->tv_usec = (suseconds_t)((ns % 1000000000ULL) / 1000ULL);
    return r;
}

static void rebase(double newSpeed) {
    // 先取各域当前虚拟时间，再把基准推进到“现在”，避免调倍率时时间跳变
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts; o_clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
    struct timeval tv; o_gettimeofday(&tv, NULL);
    uint64_t rw = ((uint64_t)tv.tv_sec * 1000000ULL + tv.tv_usec) * 1000ULL;

    os_unfair_lock_lock(&gLock);
    HLXBase *bs[3] = { &gMach, &gMono, &gWall }; uint64_t rs[3] = { rm, rn, rw };
    for (int i = 0; i < 3; i++) {
        uint64_t v = bs[i]->virtBase + (uint64_t)((double)(rs[i] - bs[i]->realBase) * gSpeed);
        bs[i]->realBase = rs[i]; bs[i]->virtBase = v;
    }
    gSpeed = newSpeed;
    os_unfair_lock_unlock(&gLock);
}


// ───────── 无 Substrate 时的后备方案：改写各镜像的符号指针表（fishhook 原理，免越狱可用）─────────
#if defined(__arm64__) && !__has_feature(ptrauth_calls)
static const char *kNames[4] = { "mach_absolute_time", "clock_gettime", "gettimeofday", "clock_gettime_nsec_np" };
static void *kRepl[4];

static void rebind_image(const struct mach_header *mh, intptr_t slide) {
    const struct mach_header_64 *h = (const struct mach_header_64 *)mh;
    const struct segment_command_64 *linkedit = NULL;
    const struct symtab_command *symtab = NULL;
    const struct dysymtab_command *dysymtab = NULL;
    const uint8_t *cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmd == LC_SEGMENT_64) { const struct segment_command_64 *sg = (const void *)cur; if (!strcmp(sg->segname, "__LINKEDIT")) linkedit = sg; }
        else if (lc->cmd == LC_SYMTAB) symtab = (const void *)cur;
        else if (lc->cmd == LC_DYSYMTAB) dysymtab = (const void *)cur;
    }
    if (!linkedit || !symtab || !dysymtab) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const void *)(base + symtab->symoff);
    const char *strtab = (const char *)(base + symtab->stroff);
    const uint32_t *indirect = (const void *)(base + dysymtab->indirectsymoff);

    cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        if (((const struct load_command *)cur)->cmd != LC_SEGMENT_64) continue;
        const struct segment_command_64 *sg = (const void *)cur;
        if (strcmp(sg->segname, "__DATA") && strcmp(sg->segname, "__DATA_CONST")) continue;
        const struct section_64 *sec = (const void *)(sg + 1);
        for (uint32_t j = 0; j < sg->nsects; j++, sec++) {
            uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            const uint32_t *ind = indirect + sec->reserved1;
            void **ptrs = (void **)((uintptr_t)slide + sec->addr);
            for (uint64_t k = 0; k < sec->size / sizeof(void *); k++) {
                uint32_t si = ind[k];
                if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL || si == (INDIRECT_SYMBOL_LOCAL | INDIRECT_SYMBOL_ABS)) continue;
                const char *nm = strtab + syms[si].n_un.n_strx;
                if (nm[0] != '_') continue;
                for (int n = 0; n < 4; n++) {
                    if (kRepl[n] && !strcmp(nm + 1, kNames[n])) {
                        mach_vm_protect(mach_task_self(), (mach_vm_address_t)&ptrs[k], sizeof(void *), FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                        ptrs[k] = kRepl[n];
                    }
                }
            }
        }
    }
}
static BOOL rebindAll(void) {
    kRepl[0] = (void *)h_mach_absolute_time; kRepl[1] = (void *)h_clock_gettime;
    kRepl[2] = (void *)h_gettimeofday;       kRepl[3] = o_clock_gettime_nsec_np ? (void *)h_clock_gettime_nsec_np : NULL;
    _dyld_register_func_for_add_image(rebind_image);        // 已加载的和以后加载的镜像都会处理
    return YES;
}
#else
static BOOL rebindAll(void) { return NO; }
#endif

static BOOL install(NSString **err) {
    if (gInstalled) return YES;
    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) { if (err) *err = @"符号解析失败"; return NO; }

    // 基准先用“真实=虚拟”初始化；hook 前先读一次原函数值
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts; ((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts);
    struct timeval tv;  ((int (*)(struct timeval *, void *))sym_gtd)(&tv, NULL);
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec; gMono = (HLXBase){ n, n };
    uint64_t w = ((uint64_t)tv.tv_sec * 1000000ULL + tv.tv_usec) * 1000ULL; gWall = (HLXBase){ w, w };

    if (hook) {
        hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
        hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
        hook(sym_gtd, (void *)h_gettimeofday,       (void **)&o_gettimeofday);
        if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
    } else {
        // 没有 Substrate/ElleKit（轻松签/全能签等侧载环境）：原函数直接取真实地址，再改写符号指针表
        o_mach_absolute_time = sym_mat; o_clock_gettime = sym_cg; o_gettimeofday = sym_gtd; o_clock_gettime_nsec_np = sym_cgn;
        if (!rebindAll()) { if (err) *err = @"此环境没有 Substrate，且 arm64e 不支持符号表改写，无法变速"; return NO; }
    }
    gInstalled = YES;
    return YES;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current { return gSpeed; }

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!(mult >= 0) || mult > 100) { if (err) *err = @"无效的变速倍率"; return NO; }
    if (!install(err)) return NO;
    rebase(mult);
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!install(&err)) return;                    // 没有 hook 框架就什么都不做
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (m >= 0 && m <= 100) rebase(m);
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!(mult >= 0) || mult > 100) { if (err) *err = @"无效的变速倍率"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Huluxia 代理：把目标 App 的 Bundle ID 加进 Huluxia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
