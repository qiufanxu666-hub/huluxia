#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <pthread.h>
#import <math.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach/mach.h>
#import <string.h>
#import <stdint.h>
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static pthread_mutex_t gLock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t gInstallLock = PTHREAD_MUTEX_INITIALIZER;
static double   gSpeed = 1.0;
// 0=未尝试，1=安装中，2=全部成功，3=失败/部分安装（必须重启进程后再试）
static int      gInstallState = 0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono, gWall;        // mach ticks / 单调 ns / 墙钟 ns

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

// Must be called with gLock held. Saturating arithmetic prevents wraparound on long sessions.
static inline uint64_t HLXScaleLocked(const HLXBase *b, uint64_t real) {
    if (real <= b->realBase) return b->virtBase;
    long double delta = (long double)(real - b->realBase) * (long double)gSpeed;
    long double value = (long double)b->virtBase + delta;
    if (!(value >= 0.0L) || value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    pthread_mutex_lock(&gLock);
    uint64_t value = HLXScaleLocked(b, real);
    pthread_mutex_unlock(&gLock);
    return value;
}

static uint64_t h_mach_absolute_time(void) { return scale(&gMach, o_mach_absolute_time()); }

static BOOL isMono(clockid_t c) { return c == CLOCK_MONOTONIC || c == CLOCK_MONOTONIC_RAW || c == CLOCK_UPTIME_RAW; }

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    if (isMono(c))               ns = scale(&gMono, ns);
    else if (c == CLOCK_REALTIME) ns = scale(&gWall, ns);
    else return r;
    ts->tv_sec = (time_t)(ns / 1000000000ULL); ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    if (isMono(c))               return scale(&gMono, ns);
    if (c == CLOCK_REALTIME)     return scale(&gWall, ns);
    return ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    int r = o_gettimeofday(tv, tz);
    if (r != 0 || !tv) return r;
    uint64_t ns = ((uint64_t)tv->tv_sec * 1000000ULL + (uint64_t)tv->tv_usec) * 1000ULL;
    ns = scale(&gWall, ns);
    tv->tv_sec = (time_t)(ns / 1000000000ULL); tv->tv_usec = (suseconds_t)((ns % 1000000000ULL) / 1000ULL);
    return r;
}

static BOOL rebase(double newSpeed) {
    if (!isfinite(newSpeed) || newSpeed < 0.1 || newSpeed > 10.0) return NO;
    // Serialize sampling + virtual-time advancement + multiplier change as one transaction.
    // This prevents rapid slider updates from applying stale samples over newer bases.
    pthread_mutex_lock(&gLock);
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts = {0};
    if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        pthread_mutex_unlock(&gLock);
        return NO;
    }
    struct timeval tv = {0};
    if (o_gettimeofday(&tv, NULL) != 0) {
        pthread_mutex_unlock(&gLock);
        return NO;
    }
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    uint64_t rw = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL;
    uint64_t vm = HLXScaleLocked(&gMach, rm);
    uint64_t vn = HLXScaleLocked(&gMono, rn);
    uint64_t vw = HLXScaleLocked(&gWall, rw);
    gMach.realBase = rm; gMach.virtBase = vm;
    gMono.realBase = rn; gMono.virtBase = vn;
    gWall.realBase = rw; gWall.virtBase = vw;
    gSpeed = newSpeed;
    pthread_mutex_unlock(&gLock);
    return YES;
}


// ───────── 无 Substrate 时的后备方案：改写各镜像的符号指针表（fishhook 原理，免越狱可用）─────────
#if defined(__arm64__) && !__has_feature(ptrauth_calls)
static const char *kNames[4] = { "mach_absolute_time", "clock_gettime", "gettimeofday", "clock_gettime_nsec_np" };
static void *kRepl[4];
static volatile int32_t gRebindImages = 0;
static volatile int32_t gRebindMatches = 0;
static volatile int32_t gRebindWrites = 0;
static volatile int32_t gRebindFailures = 0;

static void rebind_image(const struct mach_header *mh, intptr_t slide) {
    if (!mh || mh->magic != MH_MAGIC_64) return;
    __sync_fetch_and_add(&gRebindImages, 1);
    const struct mach_header_64 *h = (const struct mach_header_64 *)mh;
    const struct segment_command_64 *linkedit = NULL;
    const struct symtab_command *symtab = NULL;
    const struct dysymtab_command *dysymtab = NULL;
    const uint8_t *cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmdsize < sizeof(struct load_command)) return;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *sg = (const void *)cur;
            if (!strcmp(sg->segname, "__LINKEDIT")) linkedit = sg;
        } else if (lc->cmd == LC_SYMTAB) symtab = (const void *)cur;
        else if (lc->cmd == LC_DYSYMTAB) dysymtab = (const void *)cur;
        cur += lc->cmdsize;
    }
    if (!linkedit || !symtab || !dysymtab || !symtab->nsyms || !symtab->strsize) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const void *)(base + symtab->symoff);
    const char *strtab = (const char *)(base + symtab->stroff);
    const uint32_t *indirect = (const void *)(base + dysymtab->indirectsymoff);

    cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmd != LC_SEGMENT_64) { cur += lc->cmdsize; continue; }
        const struct segment_command_64 *sg = (const void *)cur;
        cur += lc->cmdsize;
        if (strcmp(sg->segname, "__DATA") && strcmp(sg->segname, "__DATA_CONST")) continue;
        const struct section_64 *sec = (const void *)(sg + 1);
        for (uint32_t j = 0; j < sg->nsects; j++, sec++) {
            uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            uint64_t count = sec->size / sizeof(void *);
            if (sec->reserved1 >= dysymtab->nindirectsyms || count > (uint64_t)dysymtab->nindirectsyms - sec->reserved1) continue;
            const uint32_t *ind = indirect + sec->reserved1;
            void **ptrs = (void **)((uintptr_t)slide + sec->addr);
            for (uint64_t k = 0; k < count; k++) {
                uint32_t si = ind[k];
                if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL || si == (INDIRECT_SYMBOL_LOCAL | INDIRECT_SYMBOL_ABS) || si >= symtab->nsyms) continue;
                uint32_t strIndex = syms[si].n_un.n_strx;
                if (strIndex >= symtab->strsize) continue;
                const char *nm = strtab + strIndex;
                if (nm[0] != '_') continue;
                for (int n = 0; n < 4; n++) {
                    if (!kRepl[n] || strcmp(nm + 1, kNames[n])) continue;
                    __sync_fetch_and_add(&gRebindMatches, 1);
                    if (ptrs[k] == kRepl[n]) continue;
                    vm_size_t page = vm_page_size;
                    mach_vm_address_t slot = (mach_vm_address_t)&ptrs[k];
                    mach_vm_address_t pageStart = slot & ~((mach_vm_address_t)page - 1);
                    mach_vm_size_t pageLength = page;
                    kern_return_t kr = mach_vm_protect(mach_task_self(), pageStart, pageLength, FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                    if (kr != KERN_SUCCESS) { __sync_fetch_and_add(&gRebindFailures, 1); continue; }
                    ptrs[k] = kRepl[n];
                    __sync_synchronize();
                    BOOL wrote = (ptrs[k] == kRepl[n]);
                    // Restore the segment's declared protection instead of leaving GOT pages writable.
                    vm_prot_t restore = !strcmp(sg->segname, "__DATA_CONST")
                        ? VM_PROT_READ
                        : (vm_prot_t)(sg->initprot & (VM_PROT_READ | VM_PROT_WRITE | VM_PROT_EXECUTE));
                    if (restore == VM_PROT_NONE) restore = VM_PROT_READ;
                    kern_return_t restoreResult = mach_vm_protect(mach_task_self(), pageStart, pageLength, FALSE, restore);
                    if (wrote && restoreResult == KERN_SUCCESS) __sync_fetch_and_add(&gRebindWrites, 1);
                    else __sync_fetch_and_add(&gRebindFailures, 1);
                }
            }
        }
    }
}
static BOOL rebindAll(void) {
    kRepl[0] = (void *)h_mach_absolute_time;
    kRepl[1] = (void *)h_clock_gettime;
    kRepl[2] = (void *)h_gettimeofday;
    kRepl[3] = o_clock_gettime_nsec_np ? (void *)h_clock_gettime_nsec_np : NULL;
    gRebindImages = gRebindMatches = gRebindWrites = gRebindFailures = 0;
    // dyld synchronously visits already-loaded images, then calls back for later images.
    _dyld_register_func_for_add_image(rebind_image);
    return gRebindImages > 0 && gRebindWrites > 0 && gRebindFailures == 0;
}
#else
static BOOL rebindAll(void) { return NO; }
#endif

static BOOL install(NSString **err) {
    pthread_mutex_lock(&gInstallLock);
    if (gInstallState == 2) { pthread_mutex_unlock(&gInstallLock); return YES; }
    if (gInstallState != 0) {
        if (err) *err = (gInstallState == 1) ? @"变速 Hook 正在安装，请稍后重试" : @"Hook 曾经安装失败或部分成功；请完全退出并重新启动目标 App 后再试，避免重复 Hook 导致崩溃";
        pthread_mutex_unlock(&gInstallLock);
        return NO;
    }
    gInstallState = 1;

    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) {
        if (err) *err = @"系统时间符号解析失败，未安装变速 Hook";
        gInstallState = 3; pthread_mutex_unlock(&gInstallLock); return NO;
    }

    // 基准先用“真实=虚拟”初始化；在 Hook 前读取原始时钟。
    struct timespec ts = {0};
    struct timeval tv = {0};
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    if (((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts) != 0 ||
        ((int (*)(struct timeval *, void *))sym_gtd)(&tv, NULL) != 0) {
        if (err) *err = @"初始化原始时间基准失败，未安装变速 Hook";
        gInstallState = 3; pthread_mutex_unlock(&gInstallLock); return NO;
    }
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec; gMono = (HLXBase){ n, n };
    uint64_t w = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL; gWall = (HLXBase){ w, w };

    BOOL ok = NO;
    if (hook) {
        hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
        hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
        hook(sym_gtd, (void *)h_gettimeofday,       (void **)&o_gettimeofday);
        if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
        ok = o_mach_absolute_time && o_clock_gettime && o_gettimeofday && (!sym_cgn || o_clock_gettime_nsec_np);
        if (!ok && err) *err = @"Hook 框架未能完整返回原始函数指针；可能已部分安装。请重启目标 App，不要在当前进程重复安装";
    } else {
        // 侧载后备只适用于非 arm64e；逐项验证真实写入，不把 dyld 回调注册成功当作安装成功。
        o_mach_absolute_time = (uint64_t (*)(void))sym_mat;
        o_clock_gettime = (int (*)(clockid_t, struct timespec *))sym_cg;
        o_gettimeofday = (int (*)(struct timeval *, void *))sym_gtd;
        o_clock_gettime_nsec_np = (uint64_t (*)(clockid_t))sym_cgn;
        ok = rebindAll();
        if (!ok && err) *err = @"侧载符号表 Hook 未实际完成（可能没有可改写的导入槽、页面保护失败或当前为 arm64e）；本进程不支持变速";
    }
    gInstalled = ok;
    gInstallState = ok ? 2 : 3;
    pthread_mutex_unlock(&gInstallLock);
    return ok;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current {
    pthread_mutex_lock(&gLock);
    double value = gSpeed;
    pthread_mutex_unlock(&gLock);
    return value;
}

+ (uint64_t)realMachAbsoluteTime {
    uint64_t (*realFn)(void) = o_mach_absolute_time;
    return realFn ? realFn() : mach_absolute_time();
}

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x"; return NO; }
    if (!install(err)) return NO;
    if (!rebase(mult)) { if (err) *err = @"读取原始时钟失败，倍率未更新"; return NO; }
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!install(&err)) return;                    // 没有 hook 框架就什么都不做
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (isfinite(m) && m >= 0.1 && m <= 10.0) rebase(m);
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Huluxia 代理：把目标 App 的 Bundle ID 加进 Huluxia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
