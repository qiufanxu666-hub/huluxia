// HLXMemory.m
// 说明：iOS SDK 把 mach_vm_* / task_for_pid / libproc 标成了不可用或没给头文件，
// 这里全部自己声明（task_for_pid 走 dlsym，绕开 SDK 的 unavailable 标记）。
#import "HLXMemory.h"
#import <dlfcn.h>
#import <sys/sysctl.h>
#import <sys/types.h>
#import <errno.h>
#import <math.h>

extern kern_return_t mach_vm_read_overwrite(vm_map_t, mach_vm_address_t, mach_vm_size_t, mach_vm_address_t, mach_vm_size_t *);
extern kern_return_t mach_vm_write(vm_map_t, mach_vm_address_t, vm_offset_t, mach_msg_type_number_t);
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);
extern kern_return_t mach_vm_region(vm_map_t, mach_vm_address_t *, mach_vm_size_t *, vm_region_flavor_t,
                                    vm_region_info_t, mach_msg_type_number_t *, mach_port_t *);
extern int proc_pidpath(int pid, void *buffer, uint32_t buffersize);
extern int proc_regionfilename(int pid, uint64_t address, void *buffer, uint32_t buffersize);

#define HLX_PATHMAX   4096
#define HLX_CHUNK     (1u << 20)
#define HLX_MAXRES    (5u * 1000 * 1000)     // 单次结果上限（全范围/模糊首扫会触顶）
#define HLX_PAGE      16384u

// ───────────────────────── 类型 / 条件 ─────────────────────────

typedef struct { int kind; int size; const char *name; } HLXType;   // kind: 0 有符号 1 无符号 2 浮点 3 字符串
typedef union  { int64_t s; uint64_t u; double d; } HLXNum;
enum { M_EQ = 0, M_RANGE, M_GT, M_LT, M_ANY, M_JOINT };
typedef struct { int mode; HLXNum a, b; } HLXCond;
typedef struct { uint64_t s, e; } HLXRange;

static BOOL HLXParseType(NSString *str, HLXType *t) {
    static const HLXType tbl[] = {
        {0,1,"I8"},{0,2,"I16"},{0,4,"I32"},{0,8,"I64"},
        {1,1,"U8"},{1,2,"U16"},{1,4,"U32"},{1,8,"U64"},
        {2,4,"F32"},{2,8,"F64"},{3,1,"UTF8"}
    };
    NSString *u = [[str ?: @"I32" stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet] uppercaseString];
    if ([u isEqualToString:@"STR"] || [u isEqualToString:@"TEXT"] || [u isEqualToString:@"STRING"]) u = @"UTF8";
    for (size_t i = 0; i < sizeof(tbl) / sizeof(tbl[0]); i++) {
        if ([u isEqualToString:@(tbl[i].name)]) { *t = tbl[i]; return YES; }
    }
    return NO;
}

static BOOL HLXParseNum(NSString *s, HLXType t, HLXNum *o) {
    s = [s stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    const char *c = s.UTF8String;
    if (!c || !*c) return NO;
    char *end = NULL;
    BOOL hex = (c[0] == '0' && (c[1] == 'x' || c[1] == 'X')) || (c[0] == '-' && c[1] == '0' && (c[2] == 'x' || c[2] == 'X'));
    if (t.kind == 2) {
        double d = strtod(c, &end);
        if (end == c || *end) return NO;
        o->d = (t.size == 4) ? (double)(float)d : d;
        return YES;
    }
    if (!hex && strpbrk(c, ".eE")) {                 // 整数类型里输入了小数：截断
        double d = strtod(c, &end);
        if (end == c || *end) return NO;
        if (t.kind == 0) o->s = (int64_t)d; else o->u = (d < 0) ? (uint64_t)(int64_t)d : (uint64_t)d;
        return YES;
    }
    if (t.kind == 0) {
        o->s = strtoll(c, &end, hex ? 16 : 10);
    } else if (c[0] == '-') {
        o->u = (uint64_t)strtoll(c, &end, hex ? 16 : 10);
    } else {
        o->u = strtoull(c, &end, hex ? 16 : 10);
    }
    return end != c && !*end;
}

// 表达式：123 / 100~200 / >100 / <100 / 1;2;3(联合)
static BOOL HLXParseCond(NSString *expr, HLXType t, HLXCond *c, NSArray<NSString *> **joint) {
    expr = [expr stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    memset(c, 0, sizeof(*c));
    if (expr.length == 0) return NO;
    if ([expr containsString:@";"]) {
        NSMutableArray *parts = [NSMutableArray array];
        for (NSString *p in [expr componentsSeparatedByString:@";"]) {
            NSString *q = [p stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
            if (q.length) [parts addObject:q];
        }
        if (parts.count == 0) return NO;
        c->mode = (parts.count > 1) ? M_JOINT : M_EQ;
        if (joint) *joint = parts;
        return HLXParseNum(parts[0], t, &c->a);
    }
    unichar f = [expr characterAtIndex:0];
    if (f == '>' || f == '<') {
        c->mode = (f == '>') ? M_GT : M_LT;
        return HLXParseNum([expr substringFromIndex:1], t, &c->a);
    }
    NSRange tilde = [expr rangeOfString:@"~" options:0 range:NSMakeRange(1, expr.length - 1)];
    if (tilde.location != NSNotFound) {
        c->mode = M_RANGE;
        if (!HLXParseNum([expr substringToIndex:tilde.location], t, &c->a)) return NO;
        if (!HLXParseNum([expr substringFromIndex:tilde.location + 1], t, &c->b)) return NO;
        BOOL swap = (t.kind == 0) ? c->a.s > c->b.s : (t.kind == 1) ? c->a.u > c->b.u : c->a.d > c->b.d;
        if (swap) { HLXNum x = c->a; c->a = c->b; c->b = x; }
        return YES;
    }
    c->mode = M_EQ;
    return HLXParseNum(expr, t, &c->a);
}

static inline uint64_t HLXLoadRaw(const uint8_t *p, int size) {
    uint64_t v = 0; memcpy(&v, p, size); return v;
}

static inline BOOL HLXMatchRaw(const HLXCond *c, HLXType t, uint64_t raw) {
    if (c->mode == M_ANY) return YES;
    switch (t.kind) {
        case 0: {
            int64_t v;
            switch (t.size) { case 1: v = (int8_t)raw; break; case 2: v = (int16_t)raw; break; case 4: v = (int32_t)raw; break; default: v = (int64_t)raw; }
            switch (c->mode) { case M_EQ: case M_JOINT: return v == c->a.s; case M_RANGE: return v >= c->a.s && v <= c->b.s; case M_GT: return v > c->a.s; case M_LT: return v < c->a.s; }
            return NO;
        }
        case 1: {
            uint64_t v = (t.size == 8) ? raw : (raw & ((1ULL << (t.size * 8)) - 1));
            switch (c->mode) { case M_EQ: case M_JOINT: return v == c->a.u; case M_RANGE: return v >= c->a.u && v <= c->b.u; case M_GT: return v > c->a.u; case M_LT: return v < c->a.u; }
            return NO;
        }
        default: {
            double v;
            if (t.size == 4) { float f; uint32_t r32 = (uint32_t)raw; memcpy(&f, &r32, 4); v = f; } else { memcpy(&v, &raw, 8); }
            switch (c->mode) { case M_EQ: case M_JOINT: return v == c->a.d; case M_RANGE: return v >= c->a.d && v <= c->b.d; case M_GT: return v > c->a.d; case M_LT: return v < c->a.d; }
            return NO;
        }
    }
}

static NSString *HLXFormatRaw(uint64_t raw, HLXType t) {
    char b[64];
    switch (t.kind) {
        case 0: {
            int64_t v; switch (t.size) { case 1: v = (int8_t)raw; break; case 2: v = (int16_t)raw; break; case 4: v = (int32_t)raw; break; default: v = (int64_t)raw; }
            return [NSString stringWithFormat:@"%lld", v];
        }
        case 1: {
            uint64_t v = (t.size == 8) ? raw : (raw & ((1ULL << (t.size * 8)) - 1));
            return [NSString stringWithFormat:@"%llu", v];
        }
        default:
            if (t.size == 4) {
                float f; uint32_t r32 = (uint32_t)raw; memcpy(&f, &r32, 4);
                if (isnan(f)) return @"nan"; if (isinf(f)) return f > 0 ? @"inf" : @"-inf";
                for (int p = 1; p <= 9; p++) { snprintf(b, sizeof b, "%.*g", p, f); if (strtof(b, NULL) == f) break; }
            } else {
                double d; memcpy(&d, &raw, 8);
                if (isnan(d)) return @"nan"; if (isinf(d)) return d > 0 ? @"inf" : @"-inf";
                for (int p = 1; p <= 17; p++) { snprintf(b, sizeof b, "%.*g", p, d); if (strtod(b, NULL) == d) break; }
            }
            return @(b);
    }
}

// 把 "value" 编码成目标类型字节；返回长度，0=失败
static size_t HLXEncode(NSString *value, HLXType t, uint8_t out[512]) {
    if (t.kind == 3) {
        NSData *d = [value dataUsingEncoding:NSUTF8StringEncoding];
        if (!d.length || d.length > 512) return 0;
        memcpy(out, d.bytes, d.length); return d.length;
    }
    HLXNum n;
    if (!HLXParseNum(value, t, &n)) return 0;
    if (t.kind == 2) {
        if (t.size == 4) { float f = (float)n.d; memcpy(out, &f, 4); } else memcpy(out, &n.d, 8);
    } else {
        uint64_t u = (t.kind == 0) ? (uint64_t)n.s : n.u;
        memcpy(out, &u, t.size);
    }
    return t.size;
}

// ───────────────────────── 读写 ─────────────────────────

static BOOL HLXRead(task_t task, uint64_t addr, void *buf, size_t len) {
    mach_vm_size_t out = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, addr, len, (mach_vm_address_t)buf, &out);
    return kr == KERN_SUCCESS && out == len;
}

static BOOL HLXWrite(task_t task, uint64_t addr, const void *data, size_t len) {
    if (mach_vm_write(task, addr, (vm_offset_t)data, (mach_msg_type_number_t)len) == KERN_SUCCESS) return YES;
    // 页不可写：临时改成 RW(+COPY)，写完还原
    mach_vm_address_t ra = addr; mach_vm_size_t rs = 0; mach_port_t obj = 0;
    vm_region_basic_info_data_64_t info; mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    if (mach_vm_region(task, &ra, &rs, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj) != KERN_SUCCESS || ra > addr) return NO;
    uint64_t ps = vm_page_size;
    mach_vm_address_t pg = addr & ~(ps - 1);
    mach_vm_size_t span = ((addr + len + ps - 1) & ~(ps - 1)) - pg;
    if (mach_vm_protect(task, pg, span, FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY) != KERN_SUCCESS) return NO;
    kern_return_t kr = mach_vm_write(task, addr, (vm_offset_t)data, (mach_msg_type_number_t)len);
    mach_vm_protect(task, pg, span, FALSE, info.protection);
    return kr == KERN_SUCCESS;
}

typedef struct { uint64_t base; BOOL ok; uint8_t buf[HLX_PAGE]; } HLXCache;

static BOOL HLXReadCached(HLXCache *c, task_t t, uint64_t addr, void *out, size_t n) {
    if (n <= 256) {
        uint64_t pg = addr & ~(uint64_t)(HLX_PAGE - 1);
        if (c->base != pg) { c->base = pg; c->ok = HLXRead(t, pg, c->buf, HLX_PAGE); }
        if (c->ok && addr + n <= pg + HLX_PAGE) { memcpy(out, c->buf + (addr - pg), n); return YES; }
    }
    return HLXRead(t, addr, out, n);
}

// ───────────────────────── 引擎 ─────────────────────────

static BOOL HLXGreater(uint64_t a, uint64_t b, HLXType t) {
    if (t.kind == 2) {
        double x, y;
        if (t.size == 4) { float fx, fy; uint32_t ux = (uint32_t)a, uy = (uint32_t)b; memcpy(&fx, &ux, 4); memcpy(&fy, &uy, 4); x = fx; y = fy; }
        else { memcpy(&x, &a, 8); memcpy(&y, &b, 8); }
        return x > y;
    }
    if (t.kind == 0) {
        int64_t x, y;
        switch (t.size) { case 1: x = (int8_t)a; y = (int8_t)b; break; case 2: x = (int16_t)a; y = (int16_t)b; break; case 4: x = (int32_t)a; y = (int32_t)b; break; default: x = (int64_t)a; y = (int64_t)b; }
        return x > y;
    }
    return a > b;
}


@interface HLXMemory () {
    task_t _task; pid_t _pid; BOOL _self;
    NSString *_tName, *_tBundle;
    uint64_t *_addrs; uint64_t *_vals; size_t _count, _cap;
    HLXType _rt; size_t _rtLen;
    uint8_t *_scratch; size_t _scratchLen;
    int _prot;                       // 1=r 2=w 4=x
    HLXRange *_custom; size_t _customN;
}
@end

@implementation HLXMemory

+ (instancetype)shared {
    static HLXMemory *m; static dispatch_once_t once;
    dispatch_once(&once, ^{ m = [HLXMemory new]; });
    return m;
}

- (instancetype)init {
    if ((self = [super init])) {
        _prot = 3;
        _scratchLen = HLX_CHUNK + 1024;
        _scratch = malloc(_scratchLen);
        _rt = (HLXType){0, 4, "I32"};
        [self attachPid:0 error:nil];
    }
    return self;
}

- (pid_t)pid { return _pid; }
- (task_t)task { return _task; }
- (BOOL)isSelf { return _self; }

// ── 进程 ──

static void HLXAppInfo(NSString *path, NSString **name, NSString **bundle) {
    *name = path.lastPathComponent; *bundle = @"";
    NSRange r = [path rangeOfString:@".app/"];
    if (r.location == NSNotFound) { if ([path hasSuffix:@".app"]) r = NSMakeRange(path.length - 4, 4); else return; }
    NSString *appDir = [path substringToIndex:r.location + 4];
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appDir stringByAppendingPathComponent:@"Info.plist"]];
    NSString *dn = info[@"CFBundleDisplayName"] ?: info[@"CFBundleName"];
    if (dn.length) *name = dn;
    *bundle = info[@"CFBundleIdentifier"] ?: @"";
}

- (NSArray<NSDictionary *> *)processList {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t sz = 0;
    if (sysctl(mib, 3, NULL, &sz, NULL, 0) != 0) return @[ [self targetInfoFor:getpid()] ];
    struct kinfo_proc *procs = malloc(sz * 2);
    size_t sz2 = sz * 2;
    if (sysctl(mib, 3, procs, &sz2, NULL, 0) != 0) { free(procs); return @[ [self targetInfoFor:getpid()] ]; }
    size_t n = sz2 / sizeof(struct kinfo_proc);
    NSMutableArray *apps = [NSMutableArray array], *others = [NSMutableArray array];
    for (size_t i = 0; i < n; i++) {
        pid_t pid = procs[i].kp_proc.p_pid;
        if (pid <= 1) continue;
        char path[HLX_PATHMAX] = {0};
        if (proc_pidpath(pid, path, sizeof path) <= 0) continue;
        NSString *p = @(path), *name, *bundle;
        HLXAppInfo(p, &name, &bundle);
        NSDictionary *d = @{ @"pid": @(pid), @"name": name ?: @"?", @"bundle": bundle ?: @"", @"path": p };
        [(bundle.length ? apps : others) addObject:d];
    }
    free(procs);
    return [apps arrayByAddingObjectsFromArray:others];
}

- (NSDictionary *)targetInfoFor:(pid_t)pid {
    char path[HLX_PATHMAX] = {0};
    NSString *name = @"Unknown", *bundle = @"";
    if (proc_pidpath(pid, path, sizeof path) > 0) HLXAppInfo(@(path), &name, &bundle);
    return @{ @"pid": @(pid), @"name": name, @"bundle": bundle, @"packageName": bundle };
}

- (BOOL)attachPid:(pid_t)pid error:(NSString **)err {
    task_t t = MACH_PORT_NULL;
    if (pid == 0 || pid == getpid()) {
        t = mach_task_self(); pid = getpid(); _self = YES;
    } else {
        typedef kern_return_t (*tfp_t)(mach_port_t, int, mach_port_t *);
        tfp_t tfp = (tfp_t)dlsym(RTLD_DEFAULT, "task_for_pid");
        kern_return_t kr = tfp ? tfp(mach_task_self(), pid, &t) : KERN_NOT_SUPPORTED;
        if (kr != KERN_SUCCESS || t == MACH_PORT_NULL) {
            if (err) *err = [NSString stringWithFormat:@"task_for_pid(%d) 失败 kr=%d（需要 task_for_pid-allow / com.apple.system-task-ports 权限）", pid, kr];
            return NO;
        }
        _self = NO;
    }
    _task = t; _pid = pid;
    NSDictionary *info = [self targetInfoFor:pid];
    _tName = info[@"name"]; _tBundle = info[@"bundle"];
    if (_self) {
        _tName = NSProcessInfo.processInfo.processName;
        _tBundle = NSBundle.mainBundle.bundleIdentifier ?: @"";
    }
    [self clearResults];
    return YES;
}

- (NSDictionary *)targetInfo {
    return @{ @"pid": @(_pid), @"name": _tName ?: @"Unknown", @"bundle": _tBundle ?: @"", @"packageName": _tBundle ?: @"" };
}

// ── 区域 ──

- (void)enumerate:(BOOL (^)(uint64_t s, uint64_t e, vm_region_basic_info_data_64_t *info))cb {
    mach_vm_address_t addr = 0;
    for (;;) {
        mach_vm_size_t size = 0; mach_port_t obj = 0;
        vm_region_basic_info_data_64_t info; mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
        if (mach_vm_region(_task, &addr, &size, VM_REGION_BASIC_INFO_64, (vm_region_info_t)&info, &cnt, &obj) != KERN_SUCCESS) break;
        if (!cb(addr, addr + size, &info)) break;
        addr += size;
        if (addr == 0) break;
    }
}

static NSString *HLXHex(uint64_t v) { return [NSString stringWithFormat:@"0x%llx", v]; }

- (NSArray<NSDictionary *> *)rangesList:(NSString *)filter {
    NSMutableArray *out = [NSMutableArray array];
    NSString *flt = filter.length ? filter.lowercaseString : nil;
    [self enumerate:^BOOL(uint64_t s, uint64_t e, vm_region_basic_info_data_64_t *info) {
        if (!(info->protection & VM_PROT_READ)) return YES;
        char nm[HLX_PATHMAX] = {0};
        proc_regionfilename(self->_pid, s, nm, sizeof nm);
        NSString *name = nm[0] ? @(nm) : @"";
        if (flt && ![name.lowercaseString containsString:flt]) return YES;
        char pr[4] = { (info->protection & VM_PROT_READ) ? 'r' : '-', (info->protection & VM_PROT_WRITE) ? 'w' : '-', (info->protection & VM_PROT_EXECUTE) ? 'x' : '-', 0 };
        [out addObject:@{ @"start": HLXHex(s), @"end": HLXHex(e), @"type": @(pr), @"name": name }];
        return YES;
    }];
    return out;
}

- (void)setRanges:(id)spec {
    free(_custom); _custom = NULL; _customN = 0;
    if ([spec isKindOfClass:NSString.class]) {
        NSString *s = [(NSString *)spec lowercaseString];
        _prot = [s isEqualToString:@"all"] ? 7 : ([s isEqualToString:@"r"] ? 1 : ([s isEqualToString:@"rwx"] ? 7 : 3));
    } else if ([spec isKindOfClass:NSArray.class]) {
        NSArray *a = spec;
        _custom = calloc(a.count ?: 1, sizeof(HLXRange));
        for (id it in a) {
            if (![it isKindOfClass:NSDictionary.class]) continue;
            uint64_t s = strtoull([[NSString stringWithFormat:@"%@", it[@"start"]] UTF8String], NULL, 0);
            uint64_t e = strtoull([[NSString stringWithFormat:@"%@", it[@"end"]] UTF8String], NULL, 0);
            if (e > s) _custom[_customN++] = (HLXRange){ s, e };
        }
    } else {
        _prot = 3;
    }
}

// 生成要扫描的区域；调用方 free
- (HLXRange *)scanRegionsFrom:(uint64_t)from to:(uint64_t)to count:(size_t *)n {
    __block size_t cap = 256, cnt = 0;
    __block HLXRange *rs = malloc(cap * sizeof(HLXRange));
    int need = _prot;
    [self enumerate:^BOOL(uint64_t s, uint64_t e, vm_region_basic_info_data_64_t *info) {
        int have = ((info->protection & VM_PROT_READ) ? 1 : 0) | ((info->protection & VM_PROT_WRITE) ? 2 : 0) | ((info->protection & VM_PROT_EXECUTE) ? 4 : 0);
        if (need == 1 ? !(have & 1) : need == 3 ? (have & 3) != 3 : !(have & 1)) return YES;
        if (s < from) s = from;
        if (e > to) e = to;
        if (e <= s) return (s < to);
        void (^push)(uint64_t, uint64_t) = ^(uint64_t a, uint64_t b) {
            if (cnt == cap) { cap *= 2; rs = realloc(rs, cap * sizeof(HLXRange)); }
            rs[cnt++] = (HLXRange){ a, b };
        };
        if (self->_customN) {
            for (size_t i = 0; i < self->_customN; i++) {
                uint64_t a = MAX(s, self->_custom[i].s), b = MIN(e, self->_custom[i].e);
                if (b > a) push(a, b);
            }
        } else push(s, e);
        return YES;
    }];
    *n = cnt;
    return rs;
}

// ── 结果存取 ──

- (void)clearResults {
    free(_addrs); free(_vals); _addrs = NULL; _vals = NULL; _count = _cap = 0;
}

- (BOOL)addAddr:(uint64_t)a raw:(uint64_t)r {
    if (_count >= HLX_MAXRES) return NO;
    if (_count == _cap) {
        _cap = _cap ? _cap * 2 : 4096;
        _addrs = realloc(_addrs, _cap * sizeof(uint64_t));
        _vals  = realloc(_vals,  _cap * sizeof(uint64_t));
    }
    _addrs[_count] = a; _vals[_count] = r; _count++;
    return YES;
}

- (NSUInteger)resultsCount { return _count; }

- (NSString *)stringAt:(uint64_t)addr max:(size_t)maxLen {
    uint8_t b[512]; if (maxLen > 512) maxLen = 512;
    size_t got = 0;
    for (size_t step = maxLen; step > 0 && !got; step /= 2) if (HLXRead(_task, addr, b, step)) got = step;
    if (!got) return nil;
    size_t l = 0; while (l < got && b[l]) l++;
    NSString *s = [[NSString alloc] initWithBytes:b length:l encoding:NSUTF8StringEncoding];
    return s ?: [[NSString alloc] initWithBytes:b length:l encoding:NSISOLatin1StringEncoding];
}

- (NSString *)valueAt:(uint64_t)addr type:(HLXType)t {
    if (t.kind == 3) return [self stringAt:addr max:MAX(_rtLen, 64)];
    uint8_t b[8] = {0};
    if (!HLXRead(_task, addr, b, t.size)) return nil;
    return HLXFormatRaw(HLXLoadRaw(b, t.size), t);
}

- (NSArray<NSDictionary *> *)results:(NSUInteger)count skip:(NSUInteger)skip {
    NSMutableArray *out = [NSMutableArray array];
    HLXCache *cache = calloc(1, sizeof(HLXCache)); cache->base = ~0ULL;
    for (size_t i = skip; i < _count && out.count < count; i++) {
        NSString *v = nil;
        if (_rt.kind == 3) v = [self valueAt:_addrs[i] type:_rt];
        else { uint8_t b[8] = {0}; if (HLXReadCached(cache, _task, _addrs[i], b, _rt.size)) v = HLXFormatRaw(HLXLoadRaw(b, _rt.size), _rt); }
        [out addObject:@{ @"address": HLXHex(_addrs[i]), @"value": v ?: @"?", @"type": @(_rt.name) }];
    }
    free(cache);
    return out;
}

// ── 扫描核心 ──

- (void)scanRegions:(HLXRange *)rs count:(size_t)n cond:(HLXCond)c type:(HLXType)t
             needle:(NSData *)needle joint:(NSArray<NSString *> *)joint {
    BOOL isStr = (t.kind == 3);
    const uint8_t *nd = needle.bytes; size_t ndl = needle.length;
    int sz = t.size;
    BOOL fastEq = (c.mode == M_EQ || c.mode == M_JOINT) && t.kind != 2 && (sz == 4 || sz == 8);
    uint64_t pat = 0;
    if (fastEq) { uint64_t u = (t.kind == 0) ? (uint64_t)c.a.s : c.a.u; pat = (sz == 4) ? (u & 0xffffffffULL) : u; }
    uint64_t scLo = (uint64_t)_scratch, scHi = (uint64_t)_scratch + _scratchLen;
    BOOL selfTask = _self;
    __block BOOL full = NO;

    // 联合搜索：其余值需出现在首值附近 512 字节内
    HLXCond *jc = NULL; size_t jn = 0;
    if (c.mode == M_JOINT && joint.count > 1) {
        jc = calloc(joint.count, sizeof(HLXCond)); jn = 0;
        for (NSUInteger i = 1; i < joint.count; i++) { HLXCond x = {0}; x.mode = M_EQ; if (HLXParseNum(joint[i], t, &x.a)) jc[jn++] = x; }
    }

    void (^emit)(uint64_t, uint64_t) = ^(uint64_t addr, uint64_t raw) {
        if (selfTask && addr >= scLo && addr < scHi) return;
        if (jn) {
            uint8_t w[512];
            if (!HLXRead(self->_task, addr, w, 512)) { if (!HLXRead(self->_task, addr, w, 64)) return; memset(w + 64, 0, 448); }
            for (size_t k = 0; k < jn; k++) {
                BOOL hit = NO;
                for (size_t o = 0; o + sz <= 512; o += sz) if (HLXMatchRaw(&jc[k], t, HLXLoadRaw(w + o, sz))) { hit = YES; break; }
                if (!hit) return;
            }
        }
        if (![self addAddr:addr raw:raw]) full = YES;
    };

    void (^scanBuf)(uint64_t, const uint8_t *, size_t) = ^(uint64_t base, const uint8_t *buf, size_t len) {
        if (isStr) {
            const uint8_t *p = buf, *end = buf + len;
            while (p + ndl <= end && (p = memmem(p, end - p, nd, ndl))) { emit(base + (p - buf), 0); if (full) return; p++; }
            return;
        }
        size_t off = (size_t)((sz - (base % sz)) % sz);
        if (fastEq && sz == 4) {
            for (size_t i = off; i + 4 <= len; i += 4) { uint32_t v; memcpy(&v, buf + i, 4); if (v == (uint32_t)pat) { emit(base + i, v); if (full) return; } }
        } else if (fastEq) {
            for (size_t i = off; i + 8 <= len; i += 8) { uint64_t v; memcpy(&v, buf + i, 8); if (v == pat) { emit(base + i, v); if (full) return; } }
        } else {
            for (size_t i = off; i + sz <= len; i += sz) {
                uint64_t raw = HLXLoadRaw(buf + i, sz);
                if (HLXMatchRaw(&c, t, raw)) { emit(base + i, raw); if (full) return; }
            }
        }
    };

    size_t overlap = isStr ? (ndl > 0 ? ndl - 1 : 0) : 0;
    uint64_t ps = vm_page_size;
    for (size_t r = 0; r < n && !full; r++) {
        for (uint64_t cur = rs[r].s; cur < rs[r].e && !full; ) {
            size_t len = (size_t)MIN((uint64_t)HLX_CHUNK, rs[r].e - cur);
            size_t want = MIN((uint64_t)(len + overlap), rs[r].e - cur);
            if (HLXRead(_task, cur, _scratch, want)) {
                scanBuf(cur, _scratch, want);
            } else {                                  // 整块读失败 → 按页重试，跳过坏页
                for (uint64_t pg = cur; pg < cur + len && !full; pg += ps) {
                    size_t pl = (size_t)MIN(ps, rs[r].e - pg);
                    if (HLXRead(_task, pg, _scratch, pl)) scanBuf(pg, _scratch, pl);
                }
            }
            cur += len;
        }
    }
    free(jc);
}

- (BOOL)prepare:(NSString *)expr typeName:(NSString *)typeStr cond:(HLXCond *)c type:(HLXType *)t needle:(NSData **)needle joint:(NSArray **)joint {
    if (!HLXParseType(typeStr, t)) [NSException raise:@"HLX" format:@"不支持的类型: %@", typeStr];
    if (t->kind == 3) {
        NSData *d = [expr dataUsingEncoding:NSUTF8StringEncoding];
        if (!d.length) [NSException raise:@"HLX" format:@"搜索文字为空"];
        *needle = d; memset(c, 0, sizeof(*c)); c->mode = M_EQ; return YES;
    }
    if (!HLXParseCond(expr, *t, c, joint)) [NSException raise:@"HLX" format:@"无法解析数值: %@", expr];
    *needle = nil; return YES;
}

- (NSUInteger)searchNumber:(NSString *)expr type:(NSString *)type from:(uint64_t)from to:(uint64_t)to {
    if (_count > 0) return [self refineNumber:expr type:type];       // 再次扫描
    HLXCond c; HLXType t; NSData *needle = nil; NSArray *joint = nil;
    [self prepare:expr typeName:type cond:&c type:&t needle:&needle joint:&joint];
    [self clearResults];
    _rt = t; _rtLen = needle.length;
    size_t n = 0;
    HLXRange *rs = [self scanRegionsFrom:from to:(to ? to : UINT64_MAX) count:&n];
    [self scanRegions:rs count:n cond:c type:t needle:needle joint:joint];
    free(rs);
    return _count;
}

- (NSUInteger)refineNumber:(NSString *)expr type:(NSString *)type {
    HLXCond c; HLXType t; NSData *needle = nil; NSArray *joint = nil;
    [self prepare:expr typeName:type cond:&c type:&t needle:&needle joint:&joint];
    if (_count == 0) return 0;
    if (t.kind != _rt.kind || t.size != _rt.size) { [self clearResults]; return 0; }   // 类型变了：结果作废
    HLXCache *cache = calloc(1, sizeof(HLXCache)); cache->base = ~0ULL;
    size_t w = 0;
    for (size_t i = 0; i < _count; i++) {
        uint8_t b[512];
        if (t.kind == 3) {
            if (HLXRead(_task, _addrs[i], b, needle.length) && !memcmp(b, needle.bytes, needle.length)) { _addrs[w] = _addrs[i]; _vals[w] = 0; w++; }
        } else if (HLXReadCached(cache, _task, _addrs[i], b, t.size)) {
            uint64_t raw = HLXLoadRaw(b, t.size);
            if (HLXMatchRaw(&c, t, raw)) { _addrs[w] = _addrs[i]; _vals[w] = raw; w++; }
        }
    }
    free(cache);
    _count = w;
    return _count;
}

// mode: nil/""=首次快照；changed/unchanged/increased/decreased
- (NSUInteger)searchFuzzy:(NSString *)mode type:(NSString *)type {
    HLXType t; if (!HLXParseType(type, &t) || t.kind == 3) [NSException raise:@"HLX" format:@"模糊搜索只支持数值类型"];
    NSString *m = [mode.lowercaseString stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
    if (_count == 0 || m.length == 0) {
        [self clearResults]; _rt = t; _rtLen = 0;
        HLXCond any = {0}; any.mode = M_ANY;
        size_t n = 0; HLXRange *rs = [self scanRegionsFrom:0 to:UINT64_MAX count:&n];
        [self scanRegions:rs count:n cond:any type:t needle:nil joint:nil];
        free(rs);
        return _count;
    }
    HLXCache *cache = calloc(1, sizeof(HLXCache)); cache->base = ~0ULL;
    size_t w = 0;
    for (size_t i = 0; i < _count; i++) {
        uint8_t b[8] = {0};
        if (!HLXReadCached(cache, _task, _addrs[i], b, t.size)) continue;
        uint64_t cur = HLXLoadRaw(b, t.size), old = _vals[i];
        BOOL keep = NO;
        if ([m isEqualToString:@"changed"] || [m isEqualToString:@"!="]) keep = (cur != old);
        else if ([m isEqualToString:@"unchanged"] || [m isEqualToString:@"="]) keep = (cur == old);
        else {
            BOOL inc = HLXGreater(cur, old, t);
            if ([m isEqualToString:@"increased"] || [m isEqualToString:@">"]) keep = (cur != old) && inc;
            else if ([m isEqualToString:@"decreased"] || [m isEqualToString:@"<"]) keep = (cur != old) && !inc;
        }
        if (keep) { _addrs[w] = _addrs[i]; _vals[w] = cur; w++; }
    }
    free(cache);
    _count = w;
    return _count;
}

// 以现有结果为中心 ±range 字节重新搜索
- (NSUInteger)searchNearby:(NSString *)expr type:(NSString *)type range:(uint64_t)range {
    HLXCond c; HLXType t; NSData *needle = nil; NSArray *joint = nil;
    [self prepare:expr typeName:type cond:&c type:&t needle:&needle joint:&joint];
    if (_count == 0) return 0;
    uint64_t *old = _addrs; size_t oldN = _count;
    free(_vals); _addrs = NULL; _vals = NULL; _count = _cap = 0;
    HLXRange *rs = malloc(oldN * sizeof(HLXRange)); size_t n = 0;
    for (size_t i = 0; i < oldN; i++) {
        uint64_t s = old[i] > range ? old[i] - range : 0, e = old[i] + range + (needle ? needle.length : t.size);
        if (n && s <= rs[n - 1].e) { if (e > rs[n - 1].e) rs[n - 1].e = e; } else rs[n++] = (HLXRange){ s, e };
    }
    free(old);
    _rt = t; _rtLen = needle.length;
    [self scanRegions:rs count:n cond:c type:t needle:needle joint:joint];
    free(rs);
    return _count;
}

- (NSUInteger)searchPointer:(uint64_t)target {
    [self clearResults];
    _rt = (HLXType){1, 8, "U64"}; _rtLen = 0;
    HLXCond c = {0}; c.mode = M_EQ; c.a.u = target;
    size_t n = 0; HLXRange *rs = [self scanRegionsFrom:0 to:UINT64_MAX count:&n];
    [self scanRegions:rs count:n cond:c type:_rt needle:nil joint:nil];
    free(rs);
    return _count;
}

- (NSUInteger)editAll:(NSString *)value type:(NSString *)type {
    HLXType t; if (!HLXParseType(type ?: @(_rt.name), &t)) return 0;
    uint8_t b[512]; size_t l = HLXEncode(value, t, b);
    if (!l) [NSException raise:@"HLX" format:@"无法解析要写入的值: %@", value];
    NSUInteger ok = 0;
    for (size_t i = 0; i < _count; i++) {
        if (HLXWrite(_task, _addrs[i], b, l)) { ok++; if (t.kind != 3) _vals[i] = HLXLoadRaw(b, t.size); }
    }
    return ok;
}

// ── 单地址读写 ──

- (NSString *)getValue:(uint64_t)addr type:(NSString *)type {
    HLXType t; if (!HLXParseType(type, &t)) [NSException raise:@"HLX" format:@"不支持的类型: %@", type];
    HLXType saved = _rt; size_t sl = _rtLen;
    if (t.kind == 3) _rtLen = 64;
    NSString *v = [self valueAt:addr type:t];
    _rt = saved; _rtLen = sl;
    return v;
}

- (BOOL)setValue:(uint64_t)addr value:(NSString *)value type:(NSString *)type {
    HLXType t; if (!HLXParseType(type, &t)) [NSException raise:@"HLX" format:@"不支持的类型: %@", type];
    uint8_t b[512]; size_t l = HLXEncode(value, t, b);
    if (!l) [NSException raise:@"HLX" format:@"无法解析要写入的值: %@", value];
    return HLXWrite(_task, addr, b, l);
}

- (NSArray<NSNumber *> *)readBytes:(uint64_t)addr length:(NSUInteger)len {
    if (len == 0 || len > 65536) return nil;
    uint8_t *b = malloc(len);
    if (!HLXRead(_task, addr, b, len)) {              // 整段失败 → 逐字节容错
        NSMutableArray *a = [NSMutableArray arrayWithCapacity:len]; BOOL any = NO;
        for (NSUInteger i = 0; i < len; i++) { uint8_t x = 0; if (HLXRead(_task, addr + i, &x, 1)) any = YES; [a addObject:@(x)]; }
        free(b); return any ? a : nil;
    }
    NSMutableArray *a = [NSMutableArray arrayWithCapacity:len];
    for (NSUInteger i = 0; i < len; i++) [a addObject:@(b[i])];
    free(b);
    return a;
}

- (BOOL)writeBytes:(uint64_t)addr bytes:(NSArray<NSNumber *> *)bytes {
    if (!bytes.count || bytes.count > 65536) return NO;
    uint8_t *b = malloc(bytes.count);
    for (NSUInteger i = 0; i < bytes.count; i++) b[i] = (uint8_t)bytes[i].unsignedIntValue;
    BOOL ok = HLXWrite(_task, addr, b, bytes.count);
    free(b);
    return ok;
}

@end
