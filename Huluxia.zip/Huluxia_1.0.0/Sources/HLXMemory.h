// HLXMemory.h — 内存引擎（mach_vm_* / task_for_pid / libproc 私有接口）
#import <Foundation/Foundation.h>
#import <mach/mach.h>

NS_ASSUME_NONNULL_BEGIN

@interface HLXMemory : NSObject
+ (instancetype)shared;

@property (nonatomic, readonly) pid_t pid;
@property (nonatomic, readonly) task_t task;
@property (nonatomic, readonly) BOOL isSelf;

// 进程
- (NSArray<NSDictionary *> *)processList;
- (BOOL)attachPid:(pid_t)pid error:(NSString *_Nullable *_Nullable)err;   // pid==0 → 本进程
- (NSDictionary *)targetInfo;

// 区域
- (NSArray<NSDictionary *> *)rangesList:(nullable NSString *)filter;
- (void)setRanges:(nullable id)spec;   // nil=默认rw / "r" "rw" "rwx" "all" / [{start,end}]

// 搜索（searchNumber：无结果=首次扫描，有结果=再次扫描，和 H5GG 语义一致）
- (NSUInteger)searchNumber:(NSString *)expr type:(NSString *)type from:(uint64_t)from to:(uint64_t)to;
- (NSUInteger)refineNumber:(NSString *)expr type:(NSString *)type;
- (NSUInteger)searchFuzzy:(nullable NSString *)mode type:(NSString *)type;
- (NSUInteger)searchNearby:(NSString *)expr type:(NSString *)type range:(uint64_t)range;
- (NSUInteger)searchPointer:(uint64_t)target;

// 结果
- (NSUInteger)resultsCount;
- (NSArray<NSDictionary *> *)results:(NSUInteger)count skip:(NSUInteger)skip;
- (void)clearResults;
- (NSUInteger)editAll:(NSString *)value type:(NSString *)type;

// 读写
- (nullable NSString *)getValue:(uint64_t)addr type:(NSString *)type;
- (BOOL)setValue:(uint64_t)addr value:(NSString *)value type:(NSString *)type;
- (nullable NSArray<NSNumber *> *)readBytes:(uint64_t)addr length:(NSUInteger)len;
- (BOOL)writeBytes:(uint64_t)addr bytes:(NSArray<NSNumber *> *)bytes;
@end

NS_ASSUME_NONNULL_END
