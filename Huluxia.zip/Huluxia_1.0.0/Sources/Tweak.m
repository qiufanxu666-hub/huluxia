// Tweak.m — 入口
// SpringBoard：只注册桌面启动器发来的通知；安装/重启后绝不自动显示悬浮球。
// Launcher：TrollStore 配套控制器在本 App 进程内响应按钮通知。
// 独立 DYLIB 注入的普通 App：自动选择普通侧载旧版变速路径或越狱基板 Hook，并显示本进程悬浮球。
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.huluxia.toggle";
static NSString *const kBallToggle = @"com.huluxia.ball.toggle";
static NSString *const kLauncherBundle = @"com.huluxia.launcher";

static NSUncaughtExceptionHandler *gPrevHandler;
static NSString *HLXDiagnosticPath(NSString *name) {
    NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
    if ([bid isEqualToString:@"com.apple.springboard"]) return [@"/var/mobile" stringByAppendingPathComponent:name];
    NSURL *dir = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:nil];
    return [[dir path] stringByAppendingPathComponent:name];
}
static void HLXCrashHandler(NSException *e) {
    NSString *t = [NSString stringWithFormat:@"%@ CRASH %@: %@\n%@\n\n", [NSDate date], e.name, e.reason, [e.callStackSymbols componentsJoinedByString:@"\n"]];
    NSString *path = HLXDiagnosticPath(@"huluxia_crash.log");
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
    if (!h) [t writeToFile:path atomically:NO encoding:NSUTF8StringEncoding error:nil];
    else { [h seekToEndOfFile]; [h writeData:[t dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile]; }
    if (gPrevHandler) gPrevHandler(e);
}

// SpringBoard 监听 Launcher 的命令。面板和悬浮球分开控制，安装后不会自行弹出。
static void HLXRegisterHostCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int panelToken = 0;
        static int ballToken = 0;
        notify_register_dispatch(kToggle.UTF8String, &panelToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggle];
        });
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
    });
}

// TrollStore IPA 没有 SpringBoard 注入环境，因此只在自己的 Launcher 进程里响应按钮。
static void HLXRegisterLocalLauncherCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int ballToken = 0;
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
    });
}

// 普通 App 内被注入时，在 App 进入前台后显示本进程悬浮球。
// 这样独立 DYLIB 注入目标 IPA 后不需要额外 Bundle ID 配置，也不会依赖 SpringBoard 注入。
static id gInjectedAppActiveObserver;
static void HLXShowBallInInjectedAppWhenReady(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = UIApplication.sharedApplication;
        if (!app) return;
        if (app.applicationState == UIApplicationStateActive) {
            [HLXOverlay.shared showBall];
            return;
        }
        if (gInjectedAppActiveObserver) return;
        gInjectedAppActiveObserver = [[NSNotificationCenter defaultCenter]
            addObserverForName:UIApplicationDidBecomeActiveNotification
            object:nil queue:NSOperationQueue.mainQueue
            usingBlock:^(NSNotification *note) {
                [HLXOverlay.shared showBall];
                if (gInjectedAppActiveObserver) {
                    [[NSNotificationCenter defaultCenter] removeObserver:gInjectedAppActiveObserver];
                    gInjectedAppActiveObserver = nil;
                }
            }];
    });
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/huluxia_disable"]) return;
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if (bid.length == 0) return;

        gPrevHandler = NSGetUncaughtExceptionHandler();
        NSSetUncaughtExceptionHandler(&HLXCrashHandler);

        if ([bid isEqualToString:@"com.apple.springboard"]) {
            HLXRegisterHostCommands();
            return; // 关键：不在注入/安装后自动 showBall
        }

        if ([bid isEqualToString:kLauncherBundle]) {
            HLXRegisterLocalLauncherCommands();
            return;
        }

        // 独立 DYLIB 被注入到普通 App 时：自动选择后端；普通侧载走原生 API/内存锚点，越狱环境启动时间代理，并显示本进程悬浮球。
        // SpringBoard / Launcher 已在上面单独处理，不会重复创建窗口。
        [HLXSpeed startAgent];
        HLXShowBallInInjectedAppWhenReady();
    }
}
