// Tweak.m — 入口
// SpringBoard：只注册桌面启动器发来的通知；安装/重启后绝不自动显示悬浮球。
// Launcher：TrollStore IPA 内嵌 dylib 时，在本 App 进程内响应按钮通知。
// 其他被 Filter 注入的 App：只启动变速代理，不擅自创建悬浮窗。
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.huluxia.toggle";
static NSString *const kBallToggle = @"com.huluxia.ball.toggle";
static NSString *const kLauncherBundle = @"com.huluxia.launcher";

static NSUncaughtExceptionHandler *gPrevHandler;
static void HLXCrashHandler(NSException *e) {
    NSString *t = [NSString stringWithFormat:@"%@ CRASH %@: %@\n%@\n\n", [NSDate date], e.name, e.reason, [e.callStackSymbols componentsJoinedByString:@"\n"]];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/huluxia_crash.log"];
    if (!h) { [t writeToFile:@"/var/mobile/huluxia_crash.log" atomically:NO encoding:NSUTF8StringEncoding error:nil]; }
    else { [h seekToEndOfFile]; [h writeData:[t dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile]; }
    if (gPrevHandler) gPrevHandler(e);
}

// SpringBoard 监听 Launcher 的命令。面板和悬浮球分开控制，安装后不会自行弹出。
static void HLXRegisterHostCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int panelToken = 0;
        static int ballToken = 0;
        notify_register_dispatch(kToggle.UTF8String, &panelToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggle];
        });
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
    });
}

// TrollStore IPA 没有 SpringBoard 注入环境，因此只在自己的 Launcher 进程里响应按钮。
static void HLXRegisterLocalLauncherCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int ballToken = 0;
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
    });
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/huluxia_disable"]) return;
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if (bid.length == 0) return;

        gPrevHandler = NSGetUncaughtExceptionHandler();
        NSSetUncaughtExceptionHandler(&HLXCrashHandler);

        if ([bid isEqualToString:@"com.apple.springboard"]) {
            HLXRegisterHostCommands();
            return; // 关键：不在注入/安装后自动 showBall
        }

        if ([bid isEqualToString:kLauncherBundle]) {
            HLXRegisterLocalLauncherCommands();
            return;
        }

        // 只有显式加入 Huluxia.plist Filter 的目标 App 才会走到这里。
        // 目标进程内注册变速代理；不在游戏里自动创建悬浮球。
        [HLXSpeed startAgent];
    }
}
