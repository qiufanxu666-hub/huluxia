// HLXOverlay.h — 悬浮窗（UIWindow + WKWebView），实现 H5GG 的 setWindowRect/Drag/Visible/LayoutAction
#import <Foundation/Foundation.h>

@interface HLXOverlay : NSObject
+ (instancetype)shared;
- (void)toggle;
- (void)show;
- (void)hide;
- (void)showBall;   // 显示原生悬浮球
- (void)hideBall;
- (void)toggleBall;
@end
