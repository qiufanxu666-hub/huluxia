#import "HLXBridge.h"
#import "HLXMemory.h"
#import "HLXTouch.h"
#import "HLXSpeed.h"
#import <UIKit/UIKit.h>

// 面板里会调用的所有宿主方法（页面会逐个探测 typeof h5.xxx === 'function'）
static NSArray<NSString *> *HLXMethodNames(void) {
    return @[
        @"require", @"getProcList", @"setTargetProc", @"getTargetInfo",
        @"getRangesList", @"getRanges", @"setRanges",
        @"searchNumber", @"refineNumber", @"searchFuzzy", @"searchNearby", @"searchPointer",
        @"getResultsCount", @"getResultCount", @"getResults", @"clearResults", @"editAll",
        @"getValue", @"setValue", @"readBytes", @"readData", @"writeBytes",
        @"copyText",
        @"click", @"tap", @"swipe", @"longClick", @"touchDown", @"touchMove", @"touchUp",
        @"setSpeed", @"setSpeedValue", @"setGameSpeed", @"getSpeed"
    ];
}

static dispatch_queue_t HLXQueue(void) {
    static dispatch_queue_t q; static dispatch_once_t once;
    dispatch_once(&once, ^{ q = dispatch_queue_create("com.huluxia.engine", DISPATCH_QUEUE_SERIAL); });
    return q;
}

static NSString *HLXStr(id v) {
    if (v == nil || v == NSNull.null) return @"";
    if ([v isKindOfClass:NSString.class]) return v;
    if ([v isKindOfClass:NSNumber.class]) {
        NSNumber *n = v;
        if (CFNumberIsFloatType((CFNumberRef)n)) return [NSString stringWithFormat:@"%.17g", n.doubleValue];
        return [NSString stringWithFormat:@"%lld", n.longLongValue];
    }
    return [NSString stringWithFormat:@"%@", v];
}
static uint64_t HLXAddr(id v) {
    if ([v isKindOfClass:NSNumber.class]) return [v unsignedLongLongValue];
    NSString *s = [HLXStr(v) stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (!s.length) return 0;
    BOOL hex = [s hasPrefix:@"0x"] || [s hasPrefix:@"0X"];
    return strtoull(s.UTF8String, NULL, hex ? 16 : 10);
}
static double HLXNum(id v, double def) {
    if ([v isKindOfClass:NSNumber.class]) return [v doubleValue];
    NSString *s = HLXStr(v); return s.length ? s.doubleValue : def;
}
static id HLXArg(NSArray *a, NSUInteger i) { return i < a.count ? a[i] : nil; }

@implementation HLXBridge

+ (void)handlePayload:(NSString *)payload completion:(void (^)(NSString *))done {
    NSData *d = [payload dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *req = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    NSString *m = [req[@"m"] isKindOfClass:NSString.class] ? req[@"m"] : @"";
    NSArray *a = [req[@"a"] isKindOfClass:NSArray.class] ? req[@"a"] : @[];
    dispatch_async(HLXQueue(), ^{
        id result = nil; NSString *err = nil;
        @try { result = [self call:m args:a]; }
        @catch (NSException *e) { err = e.reason ?: e.name; }
        NSDictionary *resp = err ? @{ @"__err": err } : @{ @"v": result ?: NSNull.null };
        NSData *out = [NSJSONSerialization dataWithJSONObject:resp options:0 error:nil];
        NSString *s = out ? [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] : @"{\"v\":null}";
        dispatch_async(dispatch_get_main_queue(), ^{ done(s); });
    });
}

+ (id)call:(NSString *)m args:(NSArray *)a {
    HLXMemory *mem = HLXMemory.shared;

    if ([m isEqualToString:@"require"]) return @YES;

    // ── 进程 ──
    if ([m isEqualToString:@"getProcList"]) return [mem processList];
    if ([m isEqualToString:@"getTargetInfo"]) return [mem targetInfo];
    if ([m isEqualToString:@"setTargetProc"]) {
        NSString *err = nil;
        BOOL ok = [mem attachPid:(pid_t)HLXNum(HLXArg(a, 0), 0) error:&err];
        if (!ok) [NSException raise:@"HLX" format:@"%@", err ?: @"附加失败"];
        return @YES;
    }

    // ── 区域 ──
    if ([m isEqualToString:@"getRangesList"] || [m isEqualToString:@"getRanges"]) {
        id f = HLXArg(a, 0);
        return [mem rangesList:[f isKindOfClass:NSString.class] ? f : nil];
    }
    if ([m isEqualToString:@"setRanges"]) { [mem setRanges:HLXArg(a, 0)]; return @YES; }

    // ── 搜索 ──
    if ([m isEqualToString:@"searchNumber"]) {
        uint64_t from = HLXArg(a, 2) ? HLXAddr(a[2]) : 0, to = HLXArg(a, 3) ? HLXAddr(a[3]) : UINT64_MAX;
        return @([mem searchNumber:HLXStr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1)) from:from to:to]);
    }
    if ([m isEqualToString:@"refineNumber"]) return @([mem refineNumber:HLXStr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1))]);
    if ([m isEqualToString:@"searchFuzzy"])  return @([mem searchFuzzy:HLXStr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1) ?: @"I32")]);
    if ([m isEqualToString:@"searchNearby"]) return @([mem searchNearby:HLXStr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1)) range:(uint64_t)HLXNum(HLXArg(a, 2), 64)]);
    if ([m isEqualToString:@"searchPointer"]) return @([mem searchPointer:HLXAddr(HLXArg(a, 0))]);

    // ── 结果 ──
    if ([m isEqualToString:@"getResultsCount"] || [m isEqualToString:@"getResultCount"]) return @(mem.resultsCount);
    if ([m isEqualToString:@"getResults"]) {
        NSUInteger n = (NSUInteger)MIN(MAX(HLXNum(HLXArg(a, 0), 100), 0), 5000), skip = (NSUInteger)MAX(HLXNum(HLXArg(a, 1), 0), 0);
        return [mem results:n skip:skip];
    }
    if ([m isEqualToString:@"clearResults"]) { [mem clearResults]; return @YES; }
    if ([m isEqualToString:@"editAll"]) return @([mem editAll:HLXStr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1))]);

    // ── 读写 ──
    if ([m isEqualToString:@"getValue"]) {
        NSString *v = [mem getValue:HLXAddr(HLXArg(a, 0)) type:HLXStr(HLXArg(a, 1) ?: @"I32")];
        return v ?: NSNull.null;                       // 读失败返回 null，页面按 NaN 处理
    }
    if ([m isEqualToString:@"setValue"]) return @([mem setValue:HLXAddr(HLXArg(a, 0)) value:HLXStr(HLXArg(a, 1)) type:HLXStr(HLXArg(a, 2) ?: @"I32")]);
    if ([m isEqualToString:@"readBytes"] || [m isEqualToString:@"readData"]) {
        id r = [mem readBytes:HLXAddr(HLXArg(a, 0)) length:(NSUInteger)HLXNum(HLXArg(a, 1), 64)];
        return r ?: NSNull.null;
    }
    if ([m isEqualToString:@"writeBytes"]) return @([mem writeBytes:HLXAddr(HLXArg(a, 0)) bytes:[HLXArg(a, 1) isKindOfClass:NSArray.class] ? a[1] : @[]]);

    // ── 剪贴板 ──
    if ([m isEqualToString:@"copyText"]) {
        NSString *t = HLXStr(HLXArg(a, 0));
        dispatch_sync(dispatch_get_main_queue(), ^{ UIPasteboard.generalPasteboard.string = t; });
        return @YES;
    }

    // ── 触摸 ──
    if ([m isEqualToString:@"click"] || [m isEqualToString:@"tap"]) {
        [HLXTouch tap:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0))]; return @YES;
    }
    if ([m isEqualToString:@"longClick"]) {
        [HLXTouch longPress:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0)) ms:(int)HLXNum(HLXArg(a, 2), 800)]; return @YES;
    }
    if ([m isEqualToString:@"swipe"]) {
        [HLXTouch swipe:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0))
                     to:CGPointMake(HLXNum(HLXArg(a, 2), 0), HLXNum(HLXArg(a, 3), 0)) ms:(int)HLXNum(HLXArg(a, 4), 300)];
        return @YES;
    }
    if ([m isEqualToString:@"touchDown"]) { [HLXTouch down:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0))]; return @YES; }
    if ([m isEqualToString:@"touchMove"]) { [HLXTouch move:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0))]; return @YES; }
    if ([m isEqualToString:@"touchUp"])   { [HLXTouch up:CGPointMake(HLXNum(HLXArg(a, 0), 0), HLXNum(HLXArg(a, 1), 0))]; return @YES; }

    // ── 变速 ──
    if ([m isEqualToString:@"getSpeed"]) return @(HLXSpeed.current);
    if ([m isEqualToString:@"setSpeed"] || [m isEqualToString:@"setSpeedValue"] || [m isEqualToString:@"setGameSpeed"]) {
        double mult = HLXNum(HLXArg(a, 0), 1.0);
        NSString *err = nil; BOOL ok;
        if (mem.isSelf) ok = [HLXSpeed applyLocal:mult error:&err];
        else            ok = [HLXSpeed sendToPid:mem.pid mult:mult error:&err];
        if (!ok) [NSException raise:@"HLX" format:@"%@", err ?: @"变速失败"];   // 抛错 → 页面自动降级成“内存锚点变速”
        return @YES;
    }

    [NSException raise:@"HLX" format:@"未实现的宿主方法: %@", m];
    return nil;
}

// ───────── 注入页面的脚本 ─────────
+ (NSString *)bootstrapScript {
    NSString *names = [[HLXMethodNames() valueForKey:@"description"] componentsJoinedByString:@"','"];
    return [NSString stringWithFormat:@
    "(function(){\n"
    "  if (window.__hlxBooted) return; window.__hlxBooted = true;\n"
    "  var MARK = '\\u0001HLX\\u0001';\n"
    "  function call(m, args){\n"
    "    var r = window.prompt(MARK + JSON.stringify({m:m, a:args}), '');\n"
    "    if (r === null || r === undefined || r === '') return undefined;\n"
    "    var o; try { o = JSON.parse(r); } catch(e) { return undefined; }\n"
    "    if (o && o.__err) throw new Error(o.__err);\n"
    "    return o ? o.v : undefined;\n"
    "  }\n"
    "  var h = {};\n"
    "  ['%@'].forEach(function(n){ h[n] = function(){ return call(n, Array.prototype.slice.call(arguments)); }; });\n"
    "  window.h5gg = h;\n"
    "  function post(o){ try { if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.hlx) window.webkit.messageHandlers.hlx.postMessage(o); else window.prompt('\\u0001HLXP\\u0001' + JSON.stringify(o), ''); } catch(e) {} }\n"
    "  window.setWindowDrag    = function(x,y,w,hh){ post({t:'drag', r:[x,y,w,hh]}); };\n"
    "  window.setWindowRect    = function(x,y,w,hh){ post({t:'rect', r:[x,y,w,hh]}); };\n"
    "  window.setWindowVisible = function(v){ post({t:'visible', v:!!v}); };\n"
    "  window.setLayoutAction  = function(fn){ window.__hlxLayout = function(w,hh){ try{ fn(w,hh); }catch(e){} }; post({t:'layout'}); };\n"
    "  if (window.top === window) {\n"
    "    var last = null;\n"
    "    function report(){\n"
    "      var a = document.getElementById('app');\n"
    "      if (!a) return;\n"
    "      var c = (a.style.display === 'none');\n"
    "      if (c !== last) { last = c; post({t:'collapsed', v:c}); }\n"
    "    }\n"
    "    document.addEventListener('DOMContentLoaded', function(){\n"
    "      var a = document.getElementById('app');\n"
    "      if (a && window.MutationObserver) new MutationObserver(report).observe(a, {attributes:true, attributeFilter:['style']});\n"
    "      setInterval(report, 300);\n"
    "    });\n"
    "  }\n"
    "})();\n", names];
}
@end
