#import "HLXTouch.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <mach/mach_time.h>
#import <objc/message.h>

// ── IOHID 私有类型 / 函数（运行时解析）──
typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDEventSystemClient *IOHIDEventSystemClientRef;

static IOHIDEventRef (*pCreateDigitizer)(CFAllocatorRef, uint64_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t,
                                         double, double, double, double, double, Boolean, Boolean, uint32_t);
static IOHIDEventRef (*pCreateFinger)(CFAllocatorRef, uint64_t, uint32_t, uint32_t, uint32_t,
                                      double, double, double, double, double, Boolean, Boolean, uint32_t);
static void (*pAppend)(IOHIDEventRef, IOHIDEventRef, uint32_t);
static void (*pSetInt)(IOHIDEventRef, uint32_t, int64_t);
static void (*pSetFloat)(IOHIDEventRef, uint32_t, double);
static void (*pSetSender)(IOHIDEventRef, uint64_t);
static IOHIDEventSystemClientRef (*pClientCreate)(CFAllocatorRef);
static void (*pClientDispatch)(IOHIDEventSystemClientRef, IOHIDEventRef);
static IOHIDEventSystemClientRef gClient;

// IOHIDEventTypes.h 里的常量（digitizer 事件类型 = 11）
#define kHLXFieldBuiltIn              0x00000004u
#define kHLXFieldDigitizerDisplayInt  0x000B0019u
#define kHLXFieldMajorRadius          0x000B0014u
#define kHLXFieldMinorRadius          0x000B0015u
#define kHLXEvRange     (1u << 0)
#define kHLXEvTouch     (1u << 1)
#define kHLXEvPosition  (1u << 2)
#define kHLXTransducerHand 3u

static dispatch_once_t gOnce;
static void HLXLoad(void) {
    dispatch_once(&gOnce, ^{
        void *h = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
        if (!h) return;
        pCreateDigitizer = dlsym(h, "IOHIDEventCreateDigitizerEvent");
        pCreateFinger    = dlsym(h, "IOHIDEventCreateDigitizerFingerEvent");
        pAppend          = dlsym(h, "IOHIDEventAppendEvent");
        pSetInt          = dlsym(h, "IOHIDEventSetIntegerValue");
        pSetFloat        = dlsym(h, "IOHIDEventSetFloatValue");
        pSetSender       = dlsym(h, "IOHIDEventSetSenderID");
        pClientCreate    = dlsym(h, "IOHIDEventSystemClientCreate");
        pClientDispatch  = dlsym(h, "IOHIDEventSystemClientDispatchEvent");
        if (pClientCreate) gClient = pClientCreate(kCFAllocatorDefault);
    });
}

// ── 坐标：界面方向 → 竖屏归一化坐标 ──
static NSInteger HLXInterfaceOrientation(void) {
    __block NSInteger o = 1;     // portrait
    void (^blk)(void) = ^{
        UIApplication *app = UIApplication.sharedApplication;
        if ([app respondsToSelector:NSSelectorFromString(@"activeInterfaceOrientation")]) {       // SpringBoard 私有：前台 App 的方向
            o = ((NSInteger (*)(id, SEL))objc_msgSend)(app, NSSelectorFromString(@"activeInterfaceOrientation"));
        } else {
            for (UIScene *s in app.connectedScenes) {
                if ([s isKindOfClass:UIWindowScene.class]) { o = ((UIWindowScene *)s).interfaceOrientation; break; }
            }
        }
        if (o < 1 || o > 4) o = 1;
    };
    if (NSThread.isMainThread) blk(); else dispatch_sync(dispatch_get_main_queue(), blk);
    return o;
}

static CGPoint HLXNormalize(CGPoint p) {
    __block CGSize portrait = CGSizeMake(390, 844);
    void (^blk)(void) = ^{ portrait = UIScreen.mainScreen.fixedCoordinateSpace.bounds.size; };
    if (NSThread.isMainThread) blk(); else dispatch_sync(dispatch_get_main_queue(), blk);
    CGFloat W = portrait.width, H = portrait.height;
    switch (HLXInterfaceOrientation()) {
        case 2:  return CGPointMake(1 - p.x / W, 1 - p.y / H);                // 倒置竖屏
        case 3:  return CGPointMake(p.y / W, 1 - p.x / H);                    // 横屏(Home键在左)  *若方向反了，对调 3 和 4
        case 4:  return CGPointMake(1 - p.y / W, p.x / H);                    // 横屏(Home键在右)
        default: return CGPointMake(p.x / W, p.y / H);
    }
}

// ── 派发 ──
static void HLXSend(CGPoint uiPoint, uint32_t mask, BOOL touching) {
    HLXLoad();
    if (!pCreateDigitizer || !pCreateFinger || !pAppend) return;
    CGPoint n = HLXNormalize(uiPoint);
    uint64_t t = mach_absolute_time();
    IOHIDEventRef parent = pCreateDigitizer(kCFAllocatorDefault, t, kHLXTransducerHand, 0, 0, mask, 0, 0, 0, 0, 0, 0, touching, touching, 0);
    if (!parent) return;
    if (pSetInt) { pSetInt(parent, kHLXFieldBuiltIn, 1); pSetInt(parent, kHLXFieldDigitizerDisplayInt, 1); }
    IOHIDEventRef child = pCreateFinger(kCFAllocatorDefault, t, 1, 2, mask, n.x, n.y, 0, touching ? 0.5 : 0, 0, touching, touching, 0);
    if (child) {
        if (pSetFloat) { pSetFloat(child, kHLXFieldMajorRadius, 0.04); pSetFloat(child, kHLXFieldMinorRadius, 0.04); }
        pAppend(parent, child, 0);
        CFRelease(child);
    }
    if (pSetSender) pSetSender(parent, 0xDEFACEDBEEFFECE5ULL);

    BOOL isHost = [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"];
    if (gClient && pClientDispatch && isHost) {
        pClientDispatch(gClient, parent);                       // SpringBoard：系统级派发，作用于前台任意 App
    } else {
        // App 内：直接塞给 UIApplication（私有）
        dispatch_sync(dispatch_get_main_queue(), ^{
            UIApplication *app = UIApplication.sharedApplication;
            SEL s1 = NSSelectorFromString(@"_enqueueHIDEvent:"), s2 = NSSelectorFromString(@"_handleHIDEvent:");
            if ([app respondsToSelector:s1]) ((void (*)(id, SEL, void *))objc_msgSend)(app, s1, parent);
            else if ([app respondsToSelector:s2]) ((void (*)(id, SEL, void *))objc_msgSend)(app, s2, parent);
            else if (gClient && pClientDispatch) pClientDispatch(gClient, parent);
        });
    }
    CFRelease(parent);
}

@implementation HLXTouch
+ (BOOL)available { HLXLoad(); return pCreateDigitizer && pCreateFinger && pAppend; }
+ (void)down:(CGPoint)p { HLXSend(p, kHLXEvRange | kHLXEvTouch, YES); }
+ (void)move:(CGPoint)p { HLXSend(p, kHLXEvPosition, YES); }
+ (void)up:(CGPoint)p   { HLXSend(p, kHLXEvRange | kHLXEvTouch, NO); }
+ (void)tap:(CGPoint)p  { [self down:p]; usleep(50 * 1000); [self up:p]; }
+ (void)longPress:(CGPoint)p ms:(int)ms { [self down:p]; usleep(MAX(ms, 50) * 1000); [self up:p]; }
+ (void)swipe:(CGPoint)a to:(CGPoint)b ms:(int)ms {
    ms = MAX(ms, 50);
    int steps = MAX(4, ms / 16);
    [self down:a];
    for (int i = 1; i <= steps; i++) {
        CGFloat k = (CGFloat)i / steps;
        usleep((ms * 1000) / steps);
        [self move:CGPointMake(a.x + (b.x - a.x) * k, a.y + (b.y - a.y) * k)];
    }
    [self up:b];
}
@end
