// HLXBridge.h — JS ↔ 原生 同步桥（window.prompt 通道）+ H5GG 兼容 API 分发
#import <Foundation/Foundation.h>

@interface HLXBridge : NSObject
// payload 是 JS 端 prompt 里带的 JSON：{"m":"方法名","a":[参数...]}；结果异步回调(主线程)，内容 {"v":...} 或 {"__err":"..."}
+ (void)handlePayload:(NSString *)payload completion:(void (^)(NSString *json))done;
// 注入页面的 JS（定义 window.h5gg / setWindowRect 等）
+ (NSString *)bootstrapScript;
@end
