# 葫芦侠原生版 1.0.0

本工程输出越狱 DEB、独立 `Huluxia.dylib`，以及一个内嵌 DYLIB 的配套 IPA。

## 本次修复

- 安装或重启 SpringBoard 后不再自动显示悬浮球。
- 桌面图标打开的是控制页；只有点击“显示 / 隐藏悬浮球”按钮才发送悬浮球切换通知。
- 悬浮球和功能面板使用不同通知，悬浮球点击后再打开/关闭面板。
- 删除启动器启动时自动发送切换通知和 3 秒后调用私有 `UIApplication suspend` 的逻辑。
- 修复 SpringBoard 的 `UIWebView` JS prompt 回调：回调处理现在由真正的 delegate（`HLXRootVC`）实现，而不是错误地放在 `UIWebView` 子类上。
- 移除非必要的私有 `_setSecure:` 调用，并把窗口层级改为较小的增量值，减少与系统窗口层级冲突的风险。
- 非 SpringBoard 的被注入进程启动变速代理；它们不会擅自显示悬浮球。
- rootless 构建最低部署版本调整为 iOS 15.0（Theos rootless 方案面向 iOS 15+）。

## GitHub 上传时特别注意（本次 IPA 缺失问题的关键）

GitHub Actions 在任务启动时会先读取仓库里真实存在的 `.github/workflows/build.yml`。如果只把本工程 ZIP 上传到仓库根目录，ZIP 内的 workflow 虽然会在构建任务运行时解压出来，但**不能替换本次已经启动的 workflow 定义**。因此必须另外把本 ZIP 内的 `.github/workflows/build.yml` 更新到 GitHub 仓库对应路径，并单独提交一次；然后再运行 Actions。新版 workflow 会出现 `Build TrollStore IPA (必须生成 out/Huluxia_TrollStore.ipa)` 步骤。

## 编译产物

GitHub Actions 成功后会上传名为 `Huluxia_Release` 的 artifact。GitHub 下载的 artifact 本身就是 ZIP，解压一次即可看到以下结构：

```text
Huluxia_Release/
├── 越狱版/
│   ├── Huluxia_rootful.deb
│   └── Huluxia_rootless.deb
├── TrollStore版/
│   ├── Huluxia_TrollStore.ipa
│   ├── Huluxia.dylib
│   └── Huluxia_TrollStore.plist
└── 使用说明.txt
```

本地需要 macOS + Xcode 命令行工具 + Theos：

```sh
make package FINALPACKAGE=1
make clean
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
./build_dylib.sh
./build_trollstore_ipa.sh out out/*rootful.deb
```

## 越狱版

- `Huluxia_rootful.deb`：rootful 越狱环境。
- `Huluxia_rootless.deb`：rootless 越狱环境（iOS 15+）。
- 安装后悬浮球不会自动出现。
- 点击桌面“葫芦侠”图标，再点击控制页里的“显示 / 隐藏悬浮球”按钮。悬浮球出现后，点它打开/关闭功能面板。
- SpringBoard 作为宿主显示跨 App 悬浮窗。跨进程内存访问仍取决于设备越狱环境是否授予相应 task port 权限；若 `task_for_pid` 被系统或越狱环境拒绝，进程读取/修改功能会返回权限错误，不保证所有目标进程都可附加。
- 变速代理只会加载到显式加入 `Huluxia.plist` Filter 的进程。把目标 App 的 Bundle ID 加进 Filter 后，重启目标 App。

## TrollStore / IPA 版

- `Huluxia_TrollStore.ipa` 是一个配套启动器 IPA，`Huluxia.dylib` 已嵌入 `Payload/Huluxia.app/Frameworks/`，启动器启动时会加载它。
- `Huluxia.dylib` 是单独提供的动态库；`Huluxia_TrollStore.plist` 是对应的 Bundle Filter 示例。
- TrollStore 版只能在这个 IPA 自身进程内显示面板/悬浮控件。它不能把 Tweak 注入 SpringBoard，也不能因此获得越狱 DEB 的系统级悬浮窗或对其他 App 的通用跨进程内存修改权限。
- TrollStore 官方项目公布的支持范围为 iOS 14.0 beta 2 至 iOS 16.6.1、iOS 16.7 RC（20H18）和 iOS 17.0；iOS 17.0.1 及以后版本不受支持。因此 iOS 18.x 设备不能通过 TrollStore 安装这个 IPA。请先核对目标设备系统版本，不要把“IPA 构建成功”误认为“TrollStore 一定能安装”。

## 验证说明

当前开发容器没有 Apple Xcode/iOS SDK，不能在这里真正编译或在设备上复现 SpringBoard 安全模式。本次对源码、通知流程、打包脚本和工作流做了静态修改与检查；最终是否消除安全模式，仍需在目标越狱环境上安装测试。若仍崩溃，需要设备生成的完整 SpringBoard `Jetsam/Crash` 日志或 `/var/mobile/huluxia.log`，仅有 `didFinish` 片段不足以定位异常指令。
