#!/bin/bash
# 不用 Theos，直接用 Xcode 命令行工具产出【单文件 Huluxia.dylib】（界面 HTML 已嵌入；普通侧载使用原生 API/内存锚点，越狱环境可自动启用基板 Hook）
# 需要 macOS + Xcode。产物在 build/Huluxia.dylib
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
xcrun -sdk iphoneos clang \
  -arch arm64 -miphoneos-version-min=13.0 \
  -dynamiclib -fobjc-arc -O2 -fvisibility=hidden \
  -Wno-deprecated-declarations -Wno-unused-function -Wno-error \
  -framework Foundation -framework UIKit -framework WebKit -framework CoreGraphics -framework QuartzCore \
  -Wl,-sectcreate,__DATA,__hlxui,Resources/ui.html \
  -Wl,-sectcreate,__DATA,__hlxball,Resources/ball.png \
  -install_name @rpath/Huluxia.dylib \
  Sources/*.m -o build/Huluxia.dylib
codesign -f -s - build/Huluxia.dylib
echo "OK → build/Huluxia.dylib"
