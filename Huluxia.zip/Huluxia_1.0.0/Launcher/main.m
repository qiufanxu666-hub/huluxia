// 桌面启动器：只显示控制页，不在打开 App 时自动呼出悬浮球。
// 越狱版由 SpringBoard 中的 tweak 响应通知；TrollStore IPA 由内嵌 dylib 在本进程内响应。
#import <UIKit/UIKit.h>
#import <notify.h>
#import <dlfcn.h>

static NSString *const kBallToggle = @"com.huluxia.ball.toggle";

static void HLXLoadEmbeddedDylib(void) {
    NSString *path = [NSBundle.mainBundle.bundlePath stringByAppendingPathComponent:@"Frameworks/Huluxia.dylib"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) return;
    static void *handle = NULL;
    if (!handle) {
        handle = dlopen(path.fileSystemRepresentation, RTLD_NOW | RTLD_GLOBAL);
        if (!handle) NSLog(@"[Huluxia] embedded dylib load failed: %s", dlerror());
    }
}

@interface HLXLauncherDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation HLXLauncherDelegate

- (void)toggleBall {
    notify_post(kBallToggle.UTF8String);
}

- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = [UIColor colorWithRed:0.08 green:0.10 blue:0.14 alpha:1.0];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(24, 100, vc.view.bounds.size.width - 48, 42)];
    title.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    title.text = @"葫芦侠";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:28];
    [vc.view addSubview:title];

    UILabel *info = [[UILabel alloc] initWithFrame:CGRectMake(24, 158, vc.view.bounds.size.width - 48, 150)];
    info.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    info.numberOfLines = 0;
    info.textColor = [UIColor colorWithWhite:1 alpha:0.78];
    info.font = [UIFont systemFontOfSize:15];
    info.text = @"安装完成后不会自动显示悬浮球。\n\n点击下面的按钮显示或隐藏悬浮球，再点击悬浮球打开功能面板。\n\n越狱版由 SpringBoard 提供跨 App 悬浮窗。TrollStore 版悬浮窗只在本 App 前台显示；IPA 已配置 task_for_pid 相关权限，安装时可能需要开启开发者模式。跨进程访问仍取决于系统版本、目标进程保护和实际授权，不保证所有系统进程均可读取。";
    [vc.view addSubview:info];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(24, 340, vc.view.bounds.size.width - 48, 52);
    button.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    button.backgroundColor = [UIColor colorWithRed:0.18 green:0.48 blue:0.88 alpha:1.0];
    button.layer.cornerRadius = 14;
    [button setTitle:@"显示 / 隐藏悬浮球" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    [button addTarget:self action:@selector(toggleBall) forControlEvents:UIControlEventTouchUpInside];
    [vc.view addSubview:button];

    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        // 若 IPA 中含 Frameworks/Huluxia.dylib，启动时加载；越狱 DEB 中没有该文件，不受影响。
        HLXLoadEmbeddedDylib();
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(HLXLauncherDelegate.class));
    }
}
