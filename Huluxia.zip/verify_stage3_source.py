#!/usr/bin/env python3
from pathlib import Path
p = Path(__file__).parent / 'Sources' / 'HLXSpeed.m'
s = p.read_text()
checks = {
    'serialized hook installation': 'gInstallLock' in s and 'gInstallState' in s,
    'partial install is terminal until process restart': '此前发生过部分/失败的时钟 Hook 安装' in s and 'gInstallState = ok ? 2 : 3' in s,
    'all required original pointers checked': '!o_mach_absolute_time || !o_clock_gettime || !o_gettimeofday' in s,
    'fallback requires actual successful writes': 'gRebindCounts[0] > 0' in s and 'gRebindCounts[1] > 0' in s and 'gRebindCounts[2] > 0' in s,
    'page protection failure counted': 'gRebindFailures' in s and 'mach_vm_protect' in s,
    'DATA_CONST protection restored to original permissions': 'mach_vm_protect(mach_task_self(), page, vm_page_size, FALSE, oldProtection)' in s,
    'no fake success on dyld callback registration': 'return gRebindCounts[0] > 0 && gRebindCounts[1] > 0 && gRebindCounts[2] > 0' in s,
    'multiplier remains bounded at 100x': 'mult < 0.1 || mult > 100.0' in s,
    'serialized rebase transaction retained': 'Serialize sampling + virtual-time advancement + multiplier change' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
