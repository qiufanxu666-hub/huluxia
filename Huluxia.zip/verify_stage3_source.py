#!/usr/bin/env python3
from pathlib import Path
p = Path(__file__).parent / 'Sources' / 'HLXSpeed.m'
s = p.read_text()
checks = {
    'serialized hook installation': 'gInstallLock' in s and 'gInstallState' in s,
    'partial install is terminal until process restart': 'Hook 曾经安装失败或部分成功' in s and 'gInstallState = ok ? 2 : 3' in s,
    'all required original pointers checked': 'o_mach_absolute_time && o_clock_gettime && o_gettimeofday' in s,
    'fallback requires actual successful writes': 'gRebindWrites > 0' in s and 'gRebindFailures == 0' in s,
    'page protection failure counted': 'gRebindFailures' in s and 'mach_vm_protect' in s,
    'DATA_CONST protection restored read-only': 'VM_PROT_READ\n                        :' in s,
    'no fake success on dyld callback registration': 'return gRebindImages > 0 && gRebindWrites > 0' in s,
    'multiplier remains bounded': 'mult < 0.1 || mult > 10.0' in s,
    'serialized rebase transaction retained': 'Serialize sampling + virtual-time advancement + multiplier change' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
