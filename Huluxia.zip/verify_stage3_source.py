#!/usr/bin/env python3
"""Regression checks for the exact Stage-1 speed baseline retained by this source tree.

The previous Stage-3 verifier targeted a different, unmerged implementation
(gInstallLock/gInstallState and pointer-table write counters).  The project has
explicitly retained the byte-identical Stage-1 speed file; this verifier must
check what is actually shipped, not demand symbols that are not in that file.
"""
from pathlib import Path
import hashlib
import sys

p = Path(__file__).parent / 'Sources' / 'HLXSpeed.m'
s = p.read_text(encoding='utf-8')
sha = hashlib.sha256(p.read_bytes()).hexdigest()
checks = {
    'retained Stage-1 speed source is byte-identical': sha == '65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911',
    'multiplier remains bounded to 0.1x-10x': 'mult < 0.1 || mult > 10.0' in s,
    'rebase serializes clock sampling and base updates with mutex': 'pthread_mutex_lock(&gLock);' in s and 'pthread_mutex_unlock(&gLock);' in s and 'Serialize sampling + virtual-time advancement + multiplier change as one transaction.' in s,
    'failed monotonic clock sample unlocks and aborts rebase': 'if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0)' in s and 'pthread_mutex_unlock(&gLock);\n        return NO;' in s,
    'failed wall clock sample unlocks and aborts rebase': 'if (o_gettimeofday(&tv, NULL) != 0)' in s and 'pthread_mutex_unlock(&gLock);\n        return NO;' in s,
    'clock scaling saturates instead of overflowing uint64': 'value >= (long double)UINT64_MAX' in s and 'return UINT64_MAX;' in s,
    'remote speed command requires a live target agent': 'if (!alive)' in s and '目标进程里没有加载 Huluxia 代理' in s,
    'target agent validates multiplier before rebasing': 'if (isfinite(m) && m >= 0.1 && m <= 10.0) rebase(m);' in s,
    'per-process notification channels use target PID': 'speedName(pid)' in s and 'agentName(pid)' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print('HLXSpeed.m SHA256:', sha)
if not all(checks.values()):
    raise SystemExit(1)
