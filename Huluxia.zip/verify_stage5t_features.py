#!/usr/bin/env python3
from pathlib import Path
import hashlib
import plistlib
import re

ROOT = Path(__file__).resolve().parent
read = lambda p: (ROOT / p).read_text(encoding='utf-8')

memory = read('Sources/HLXMemory.m')
service = read('Sources/HLXTaskService.m')
daemon = read('Daemon/main.c')
touch = read('Sources/HLXTouch.m')
points = read('Sources/HLXTouchPoints.m')
ui = read('Resources/ui.html')
makefile = read('Makefile')
workflow = read('.github/workflows/build.yml')
filter_plist = plistlib.loads((ROOT / 'Huluxia.plist').read_bytes())
entitlements = plistlib.loads((ROOT / 'Daemon/entitlements.plist').read_bytes())
speed_hash = hashlib.sha256((ROOT / 'Sources/HLXSpeed.m').read_bytes()).hexdigest()

checks = {
    'memory attach delegates task-port acquisition to daemon': 'HLXTaskServiceCopyTaskPort(pid, &candidate)' in memory,
    'memory attach no longer requires an injected agent': 'agentStatusForPid' not in memory and 'HLXTaskServiceCopyTaskPort(pid, &candidate)' in memory,
    'process picker filters out non-app daemons and the host SpringBoard PID': 'if (pid <= 1 || pid == getpid()) continue;' in memory and 'if (!bundle.length) continue;' in memory and 'return apps;' in memory,
    'SpringBoard path delegates to daemon while TrollStore task_for_pid is runtime-gated': ('if (HLXIsTrollStoreLauncherRuntime())' in memory and 'HLXTaskServiceCopyTaskPort(pid, &candidate)' in memory and 'dlsym(RTLD_DEFAULT, \"task_for_pid\")' in memory),
    'daemon owns task_for_pid for jailbreak path and client service never calls it': 'dlsym(RTLD_DEFAULT, "task_for_pid")' in daemon and 'task_for_pid' not in service,
    'daemon authenticates caller through the Mach audit-token shim': 'MACH_RCV_TRAILER_AUDIT' in daemon and 'HLXAuditTokenPID(trailer->msgh_audit)' in daemon and 'HLXIsSpringBoardClient' in daemon and 'HLX_BOOTSTRAP_MAX_NAME_LEN 128' in read('Sources/HLXBootstrapShim.h'),
    'daemon validates app target path and rechecks it after task acquisition': 'HLXSameTargetPath(pid, before)' in daemon and 'proc_pidpath(pid, before' in daemon and 'if (!strstr(before, ".app/")) return KERN_INVALID_ARGUMENT;' in daemon,
    'client request/reply share a correctly sized receive buffer': 'HLXMemoryMessageBuffer' in service and 'uint8_t trailerSpace[256]' in service and '(mach_msg_size_t)sizeof(buffer)' in service,
    'client validates received task port type without assuming send disposition survives receive': 'reply->taskPort.type != MACH_MSG_PORT_DESCRIPTOR' in service and 'reply->taskPort.disposition != MACH_MSG_TYPE_COPY_SEND' not in service,
    'daemon launchd MachServices name is configured': 'com.huluxia.memoryd' in makefile and '<key>MachServices</key>' in makefile,
    'daemon is staged and added as a Theos subproject': 'SUBPROJECTS += Launcher Daemon' in makefile and 'HuluxiaD_INSTALL_PATH = /usr/libexec' in read('Daemon/Makefile'),
    'daemon has task_for_pid-allow entitlement': entitlements.get('task_for_pid-allow') is True and 'TARGET_CODESIGN_FLAGS = -S$(THEOS_PROJECT_DIR)/Daemon/entitlements.plist' in read('Daemon/Makefile'),
    'tweak injection remains SpringBoard-only': filter_plist.get('Filter', {}).get('Bundles') == ['com.apple.springboard'],
    'workflow has no manual Bundle ID input': 'target_bundle_id' not in workflow and 'target_bundle_id:' not in workflow,
    'workflow selects Stage 5U before Stage 5T': workflow.find('阶段5U_内存搜索文字修复与100倍变速.zip') >= 0 and workflow.find('阶段5U_内存搜索文字修复与100倍变速.zip') < workflow.find('阶段5T_独立辅助服务与触摸派发修复.zip'),
    'touch DOWN/MOVE/UP masks are phase-specific': 'const uint32_t parentMask = moving' in touch and 'const uint32_t childMask = moving' in touch and 'kHLXDigitizerPosition' in touch and 'kHLXDigitizerRange | kHLXDigitizerTouch' in touch,
    'touch status exposes phase masks and honest async-dispatch caveat': '@"eventMasks"' in touch and '@"dispatchNote"' in touch and '没有系统接收回执' in touch,
    'touch coordinates use stable full-screen SpringBoard point space and WebKit window points': 'HLXCoordinateBounds(UIWindow *window)' in touch and 'if (HLXIsSpringBoard()) return UIScreen.mainScreen.bounds.size;' in touch and 'p.x, p.y, 0, 0.0, 0' in touch and 'normalizedX' not in touch and 'normalizedY' not in touch,
    'native point operations are serialized on main thread': '+ (void)performOnMain:(dispatch_block_t)block' in points and 'dispatch_sync(dispatch_get_main_queue(), block)' in points,
    'point window has explicit pass-through mode': '@property(nonatomic,assign) BOOL passThrough' in points and 'if (self.passThrough) return nil;' in points,
    'point dragging is restricted to edit/swipe states': 'self.mode != 0 && self.mode != 2' in points,
    'runner can enter actual screen placement and hide only the panel': 'clickerEnterPlacement()' in ui and 'window.setWindowVisible(false)' in ui,
    'clicker locks overlay pass-through for both tap and swipe runs': ui.count("setTouchPointMode('run')") >= 2,
    'manual X/Y point fields are removed for taps and swipes': all(x not in ui for x in ('clickerPointX', 'clickerPointY', 'clickerSX', 'clickerSY', 'clickerEX', 'clickerEY')) and 'host.swipe(startPoint.x, startPoint.y, endPoint.x, endPoint.y, duration)' in ui,
    'clicker still uses native point synchronization': 'host.getTouchPoints()' in ui and 'host.setTouchPoints(' in ui,
    'native speed accepts 0.1x through 100x': 'newSpeed > 100.0' in read('Sources/HLXSpeed.m') and 'mult > 100.0' in read('Sources/HLXSpeed.m'),
}

for name, ok in checks.items():
    print(('PASS: ' if ok else 'FAIL: ') + name)
if not all(checks.values()):
    raise SystemExit(1)
print('Stage 5T static source checks passed. This does not prove iOS runtime entitlement or HID delivery.')
