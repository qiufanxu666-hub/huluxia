#!/usr/bin/env python3
from pathlib import Path
p = Path('build_dylib.sh')
s = p.read_text()
assert 'DIAG_ARGS=()' not in s, 'empty diagnostic array must not be expanded under Bash 3.2 nounset'
assert '"${DIAG_ARGS[@]}"' not in s, 'unsafe empty array expansion remains'
assert 'if [[ "${HLX_NATIVE_DIAGNOSTIC:-0}" == "1" ]]' in s
assert 'elif [[ "${HLX_WEBKIT_SMOKE_DIAGNOSTIC:-0}" == "1" ]]' in s
assert '"${COMMON_ARGS[@]}" "${SOURCES[@]}"' in s
print('[HLX-STAGE5N] Bash 3.2 empty-array regression check passed')
