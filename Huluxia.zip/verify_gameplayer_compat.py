#!/usr/bin/env python3
"""Static regression checks for the GamePlayer-style process selector and scan types."""
from pathlib import Path
import plistlib
import re
import sys

ROOT = Path(__file__).resolve().parent
checks = []

def check(label, ok):
    checks.append((label, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ': ' + label)

def read(path):
    p = ROOT / path
    return p.read_text(encoding='utf-8') if p.is_file() else ''

mem = read('Sources/HLXMemory.m')
mem_h = read('Sources/HLXMemory.h')
bridge = read('Sources/HLXBridge.m')
ui = read('Resources/ui.html')
tweak = read('Sources/Tweak.m')
launcher = read('Launcher/main.m')
main_mk = read('Makefile')
dylib_sh = read('build_dylib.sh')
ipa_sh = read('build_trollstore_ipa.sh')
workflow = read('.github/workflows/build.yml')

# Native type parser: these are unsigned fixed-width aliases, not signed I8/I16/I32.
for label, token, width in [('BYTE', '{1,1,"BYTE"}', 1), ('WORD', '{1,2,"WORD"}', 2), ('DWORD', '{1,4,"DWORD"}', 4)]:
    check(f'native parser declares {label} as unsigned {width * 8}-bit', token in mem)
check('native parser accepts ORD as WORD alias', 'if ([u isEqualToString:@"ORD"]) u = @"WORD";' in mem)
check('native parser accepts BY TE as BYTE alias', 'if ([u isEqualToString:@"BY TE"]) u = @"BYTE";' in mem)
check('native parser still supports signed, unsigned, float and UTF8 types', all(x in mem for x in ['"I8"','"I16"','"I32"','"I64"','"U8"','"U16"','"U32"','"U64"','"F32"','"F64"','"UTF8"']))

# Process list and attachment semantics.
check('process picker exposes only app bundles and excludes SpringBoard', 'if (!bundle.length || [bundle isEqualToString:@"com.apple.springboard"]' in mem and 'return apps;' in mem)
check('process enumeration excludes the host PID', 'pid == getpid()' in mem)
check('native bridge exposes own PID API', '@"getOwnPid"' in bridge and '@(getpid())' in bridge)
check('native process attach rejects SpringBoard even if called directly', 'SpringBoard 仅负责悬浮球，禁止作为内存扫描目标' in bridge and 'targetPid == getpid() && HLXIsSpringBoardHost()' in bridge)
check('task_for_pid failure returns before changing the active task', 'if (kr != KERN_SUCCESS || t == MACH_PORT_NULL)' in mem and mem.index('if (kr != KERN_SUCCESS || t == MACH_PORT_NULL)') < mem.index('_task = t; _pid = pid; _self = newSelf;'))
check('old remote task port is released once on successful switch', mem.count('mach_port_deallocate(mach_task_self(), oldTask);') == 1)
check('all memory search/read/write operations require a real external target on SpringBoard', bridge.count('HLXRequireExternalTarget(mem)') >= 12)
check('SpringBoard remains the floating-ball host, not the default scan target', 'HLXRegisterHostCommands();\n            return;' in tweak and 'HLXTryShowInjectedGameBall' in tweak)
check('Theos Tweak build marks itself and avoids duplicate per-game balls', '-DHLX_TWEAK_BUILD=1' in main_mk and '#if !defined(HLX_TWEAK_BUILD)' in tweak)
check('standalone DYLIB keeps direct-injection game-ball behavior', 'HLXRegisterInjectedGameOverlay();' in tweak and '#if !defined(HLX_TWEAK_BUILD)' in tweak)

# UI flow must attach first and only then commit currentTargetProc.
selector = ui[ui.find('function selectProcess(el)'):ui.find('function skipProcessSelection()')]
check('UI process switch calls native attach before setting currentTargetProc', selector.find('trySwitchTargetProcess(pid)') < selector.find('currentTargetProc = { pid: pid'))
check('failed attach preserves the previous target and reports the reason', "if (!res.ok)" in selector and "toast('附加失败：' + reason)" in selector and selector.find('if (!res.ok)') < selector.find('currentTargetProc = { pid: pid'))
check('SpringBoard host is never inferred as current target', 'if (isSpringBoardHost()) return null;' in ui)
check('boot captures host identity before process-selector logic', 'hostProcessInfo = h5.getTargetInfo();' in ui)

# UI buttons, numeric ranges and GameGuardian type map.
check('main scan toolbar visibly offers DWORD / WORD / BYTE', all(f'data-t="{t}"' in ui for t in ['DWORD','WORD','BYTE']))
check('UI numeric ranges include unsigned 8/16/32-bit limits', all(x in ui for x in ["case 'BYTE': return '0~255'", "case 'WORD': return '0~65535'", "case 'DWORD':return '0~4294967295'"]))
check('Lua/JS GameGuardian constants use unsigned widths', all(x in ui for x in ["TYPE_BYTE:'U8'", "TYPE_WORD:'U16'", "TYPE_DWORD:'U32'", "TYPE_QWORD:'U64'"]))
check('GameGuardian parser maps DWORD / WORD / BYTE to unsigned native types', all(x in ui for x in ["'BYTE': 'U8'", "'WORD': 'U16'", "'DWORD': 'U32'", "'ORD': 'U16'", "'BY TE': 'U8'"]))
check('GameGuardian QWORD uses unsigned U64 (not signed I64)', not re.search(r'TYPE_QWORD\s*:\s*[\'\"]I64', ui))

# All product families include the same HTML/native source in their build path.
check('Theos tweak embeds the shared ui.html and ball asset', '__hlxui,$(THEOS_PROJECT_DIR)/Resources/ui.html' in main_mk and '__hlxball,$(THEOS_PROJECT_DIR)/Resources/ball.png' in main_mk)
check('standalone DYLIB embeds the same ui.html and ball asset', '__hlxui,Resources/ui.html' in dylib_sh and '__hlxball,Resources/ball.png' in dylib_sh)
check('TrollStore IPA packages the standalone DYLIB into the app', 'Frameworks/Huluxia.dylib' in ipa_sh and 'cp "$DYLIB"' in ipa_sh)
check('workflow builds legacy, modern rootful, rootless, DYLIB and IPA from this source', all(x in workflow for x in ['Build legacy iOS 8-10 DEB', 'Build rootful DEB', 'Build rootless DEB', 'Build standalone DYLIB', 'Build TrollStore companion IPA']))
check('workflow prioritizes the corrected GamePlayer ZIP over stale project archives', workflow.find('Huluxia_1.0.0_阶段5B_GamePlayer跨进程_DWORD_WORD_BYTE.zip') < workflow.find('Huluxia_1.0.0_阶段5A_iOS8-26_兼容修复_V5_Bash32安全版.zip'))
check('workflow executes this compatibility verifier', 'python3 verify_gameplayer_compat.py' in workflow)

# GamePlayer-style launcher notification wiring and entitlements are present.
check('Launcher automatically requests the floating ball at startup', 'notify_post(kBallShow.UTF8String)' in launcher)
check('SpringBoard listens for the launcher show-ball notification', 'notify_register_dispatch(kBallShow.UTF8String' in tweak)
check('Launcher probes SpringBoard before choosing global or local ball behavior', 'notify_post(kHostProbe.UTF8String)' in launcher and 'notify_get_state(readyToken, &ready)' in launcher)
check('SpringBoard persists a ready-state token and answers launcher probes', 'static int hostReadyStateToken = 0;' in tweak and 'notify_set_state(hostReadyStateToken, 1)' in tweak)
check('Launcher suspends only after SpringBoard confirms the global overlay host', 'if (ready == 1)' in launcher and 'respondsToSelector:suspendSelector' in launcher)
check('TrollStore/no-host path does not suspend the launcher', 'if (ready == 1)' in launcher and 'TrollStore 没有 SpringBoard Tweak 应答时' in launcher)
check('task_for_pid error text does not claim an unrelated system-task-ports entitlement', 'com.apple.system-task-ports' not in mem and 'task_for_pid-allow' in mem)
check('README startup instructions match the GamePlayer-style auto-show flow', '不再自动显示悬浮球' not in read('README.md') and '收到越狱 Tweak 应答后' in read('README.md'))
try:
    with (ROOT / 'Resources/Huluxia.entitlements').open('rb') as f:
        ent = plistlib.load(f)
    check('Launcher entitlement plist includes task_for_pid-allow', ent.get('task_for_pid-allow') is True)
    check('Launcher entitlement plist includes GamePlayer debug entitlement', ent.get('com.apple.springboard.debugapplications') is True)
except Exception:
    check('Launcher entitlement plist is parseable', False)

failed = [name for name, ok in checks if not ok]
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
if failed:
    print('Failed checks: ' + ', '.join(failed))
    sys.exit(1)
