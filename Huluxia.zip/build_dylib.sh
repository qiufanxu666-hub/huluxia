#!/bin/bash
# Build a universal modern DYLIB (arm64 + arm64e). iOS 13+ only; legacy iOS 8-12
# must use the Theos legacy package family and its armv7/arm64 slices.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/thin
SOURCES=()
while IFS= read -r source; do SOURCES+=("$source"); done < <(find Sources -maxdepth 1 -name '*.m' ! -name 'HLXSpeedLegacy.m' -print | sort)
[[ ${#SOURCES[@]} -gt 0 ]] || { echo "No Objective-C source files found" >&2; exit 1; }
COMMON_ARGS=(
  -miphoneos-version-min=13.0 -dynamiclib -fobjc-arc -O2 -fvisibility=hidden
  -Wno-deprecated-declarations -Wno-unused-function -Wno-error
  -framework Foundation -framework UIKit -framework WebKit -framework CoreGraphics
  -Wl,-sectcreate,__DATA,__hlxui,Resources/ui.html
  -Wl,-sectcreate,__DATA,__hlxball,Resources/ball.png
  -Wl,-undefined,dynamic_lookup -install_name @rpath/Huluxia.dylib
)
for ARCH in arm64 arm64e; do
  echo "Building $ARCH"
  DIAG_ARGS=()
  if [[ "${HLX_NATIVE_DIAGNOSTIC:-0}" == "1" ]]; then
    DIAG_ARGS+=(-DHLX_NATIVE_DIAGNOSTIC=1)
  elif [[ "${HLX_WEBKIT_SMOKE_DIAGNOSTIC:-0}" == "1" ]]; then
    DIAG_ARGS+=(-DHLX_WEBKIT_SMOKE_DIAGNOSTIC=1)
  fi
  xcrun -sdk iphoneos clang -arch "$ARCH" "${DIAG_ARGS[@]}" "${COMMON_ARGS[@]}" "${SOURCES[@]}" -o "build/thin/Huluxia-$ARCH.dylib"
done
lipo -create build/thin/Huluxia-arm64.dylib build/thin/Huluxia-arm64e.dylib -output build/Huluxia.dylib
codesign -f -s - build/Huluxia.dylib
lipo -archs build/Huluxia.dylib
echo "OK → build/Huluxia.dylib (arm64 + arm64e; iOS 13+)"
