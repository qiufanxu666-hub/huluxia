#!/bin/bash
# 不用 Theos，直接用 Xcode 命令行工具产出【单文件 Huluxia.dylib】（界面 HTML 已嵌入，免越狱注入 IPA 用）
# 需要 macOS + Xcode。产物在 build/Huluxia.dylib
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
SOURCES=()
while IFS= read -r source; do SOURCES+=("$source"); done < <(find Sources -maxdepth 1 -name '*.m' ! -name 'HLXSpeedLegacy.m' -print | sort)
[[ ${#SOURCES[@]} -gt 0 ]] || { echo "No Objective-C source files found" >&2; exit 1; }

# Do not expand an empty array with `set -u`: macOS ships Bash 3.2, where
# `${empty_array[@]}` can abort with "unbound variable". Keep common args
# in a non-empty array and branch only for the optional preprocessor define.
CLANG_COMMON_ARGS=(
  -arch arm64 -miphoneos-version-min=13.0
  -dynamiclib -fobjc-arc -O2 -fvisibility=hidden
  -Wno-deprecated-declarations -Wno-unused-function -Wno-error
  -framework Foundation -framework UIKit -framework WebKit -framework CoreGraphics
  -Wl,-sectcreate,__DATA,__hlxui,Resources/ui.html
  -Wl,-sectcreate,__DATA,__hlxball,Resources/ball.png
  -Wl,-undefined,dynamic_lookup
  -install_name @rpath/Huluxia.dylib
)
if [[ "${HLX_NATIVE_DIAGNOSTIC:-0}" == "1" ]]; then
  echo "Building opt-in native UIKit diagnostic variant (WebKit bypassed)"
  xcrun -sdk iphoneos clang -DHLX_NATIVE_DIAGNOSTIC=1 \
    "${CLANG_COMMON_ARGS[@]}" "${SOURCES[@]}" -o build/Huluxia.dylib
else
  xcrun -sdk iphoneos clang \
    "${CLANG_COMMON_ARGS[@]}" "${SOURCES[@]}" -o build/Huluxia.dylib
fi
codesign -f -s - build/Huluxia.dylib
echo "OK → build/Huluxia.dylib"
