#!/usr/bin/env python3
"""Stage 5L native HID touch regression checks; filename retained for workflow compatibility."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
touch = (root / "Sources/HLXTouch.m").read_text()
header = (root / "Sources/HLXTouch.h").read_text()
bridge = (root / "Sources/HLXBridge.m").read_text()
ui = (root / "Resources/ui.html").read_text()
workflow = (root / ".github/workflows/build.yml").read_text()
overlay = (root / "Sources/HLXOverlay.m").read_text()

checks = {
    "BKSHIDEventSetDigitizerInfo uses the exact 7-argument ABI": "IOHIDEventRef,uint32_t,uint8_t,uint8_t,CFStringRef,CFTimeInterval,float" in touch,
    "digitizer parent is a Hand transducer": "#define kHLXTransducerHand 3u" in touch,
    "HID identity mask uses bit 5, not bit 3": "#define kHLXDigitizerIdentity (1u << 5)" in touch,
    "HID attribute mask uses bit 6": "#define kHLXDigitizerAttribute (1u << 6)" in touch,
    "touch begin/end include Range, Touch and Identity": "kHLXDigitizerRange | kHLXDigitizerTouch | kHLXDigitizerIdentity" in touch,
    "SpringBoard system-client path sets sender ID only for that path": "if (pSetSender) pSetSender(parent, 0xDEFACEDBEEFFECE5ULL);" in touch and touch.index("if (sbCanFallback)") < touch.index("if (pSetSender) pSetSender"),
    "movement includes Position and Attribute": "kHLXDigitizerPosition | kHLXDigitizerAttribute" in touch,
    "finger child events use distinct WebKit-style identities for index and identity": "{ 2, 3, 4, 5, 1 }" in touch and "kHLXFingerIdentifiers[i], kHLXFingerIdentifiers[i], childMask" in touch,
    "each parent event contains appended finger child events": "pAppend(parent, finger, 0)" in touch and "CFRelease(finger)" in touch,
    "display-integrated marker setter is required before HID send": "return pCreateDigitizer && pCreateFinger && pAppend && pSetInt;" in touch,
    "stale delayed gesture events are invalidated on stop or new gesture": "gTouchGeneration" in touch and "gTouchGeneration != generation" in touch,
    "SpringBoard system-client path is selected before app-local enqueue": touch.index("if (sbCanFallback)") < touch.index("} else if (appCanEnqueue)"),
    "ordinary injected-app path attaches the window context before enqueue": "pSetDigitizerInfo(parent, contextID, 0, 0, NULL, 0, 0)" in touch and "objc_msgSend)(app, enqueue, parent)" in touch,
    "touch event timestamps use mach_absolute_time": "uint64_t timestamp = mach_absolute_time();" in touch,
    "coordinates are validated against the active window": "HLXNormalizePoint" in touch and "window.bounds.size" in touch,
    "multi-touch is capped at five fingers": "kHLXMaxTouches 5u" in touch and "points.count > kHLXMaxTouches" in touch,
    "touch cancellation releases all active fingers": "+ (void)cancelAll" in touch and "HLXEmit(NO, NO)" in touch,
    "multi-touch APIs are exposed through the native bridge": all(x in bridge for x in ('@"multiTap"', '@"multiDown"', '@"multiMove"', '@"multiUp"', '@"cancelTouch"')),
    "multi-touch JSON points are validated before dispatch": "HLXPointArray" in bridge and "多点触摸参数无效" in bridge,
    "Lua compatibility API exposes native multiTap": "multiTap:function(points,holdMs){return nativeTouch('multiTap'" in ui,
    "independent clicker panel exposes click, multi-touch, swipe and stop": all(x in ui for x in ('id="clickerRunner"', "host.multiTap(clickerPoints.map", "host.swipe(sx, sy, ex, ey, duration)", "host.cancelTouch()")),
    "JavaScript API exposes native multiTap": "rt.multiTap  = function(points, holdMs)" in ui,
    "HTML iframe receives native multi-touch methods": "w.multiTap   = rt.multiTap" in ui and "w.multiDown  = rt.multiDown" in ui,
    "legacy helper no longer falls back to DOM touch synthesis": "不会伪造 DOM 触摸" in ui and "[DOM] swipe(" not in ui and "[DOM] click(" not in ui,
    "getTouchStatus remains exposed with permission caveat": '@"getTouchStatus"' in bridge and '[HLXTouch status]' in bridge and 'dispatchNote' in touch,
    "iOS 13 windowScene is dynamically queried for old SDK compatibility": 'NSSelectorFromString(@"windowScene")' in overlay and "newWindow.windowScene" not in overlay,
    "iOS 11 content inset API is runtime-guarded": 'NSSelectorFromString(@"setContentInsetAdjustmentBehavior:")' in overlay and "UIScrollViewContentInsetAdjustmentNever" not in overlay,
    "workflow is labeled Stage 5L": "Stage 5L native multi-touch HID and clicker" in workflow,
    "workflow prefers Stage 5L, then 5K, then Stage 5J": workflow.index("Huluxia_1.0.0_阶段5L_原生多点HID触摸修复.zip") < workflow.index("Huluxia_1.0.0_阶段5K_iOS11SDK兼容构建修复.zip") < workflow.index("Huluxia_1.0.0_阶段5J_原生HID触摸修复.zip"),
    "workflow runs the native touch regression validator": "python3 verify_stage5j_source.py" in workflow,
}

speed_hash = hashlib.sha256((root / "Sources/HLXSpeed.m").read_bytes()).hexdigest()
checks["HLXSpeed.m preserved byte-for-byte against Stage 5I baseline"] = speed_hash == "65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911"

for label, ok in checks.items():
    print(("PASS: " if ok else "FAIL: ") + label)
sys.exit(0 if all(checks.values()) else 1)
