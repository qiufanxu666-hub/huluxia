#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

root = Path(__file__).resolve().parent
touch = (root / "Sources/HLXTouch.m").read_text()
header = (root / "Sources/HLXTouch.h").read_text()
bridge = (root / "Sources/HLXBridge.m").read_text()
ui = (root / "Resources/ui.html").read_text()
workflow = (root / ".github/workflows/build.yml").read_text()
checks = {
    "digitizer context SPI has the exact 7-argument declaration": "IOHIDEventRef,uint32_t,uint8_t,uint8_t,CFStringRef,CFTimeInterval,float" in touch,
    "BKS digitizer context is attached before UIApplication enqueue": "pSetDigitizerInfo(parent, contextID, 0, 0, NULL, 0, 0)" in touch and "objc_msgSend)(app, enqueue, parent)" in touch,
    "normal app path requires a valid key-window context": "contextID != 0 && pSetDigitizerInfo" in touch,
    "SpringBoard prioritizes system-wide dispatch over its own app window": touch.index("if (springBoardCanDispatch)") < touch.index("} else if (appCanEnqueue)"),
    "HID finger child is appended and released": "pAppend(parent, finger, 0)" in touch and "CFRelease(finger)" in touch,
    "touch coordinates are UIKit points, not normalized 0..1": "point.x / bounds.width" not in touch and "point.x, point.y, 0, touching" in touch,
    "movement events include Position/Range/Touch": "kDigitizerPosition | kDigitizerRange | kDigitizerTouch" in touch,
    "touch API status is declared": "+ (NSDictionary *)status;" in header,
    "bridge exposes getTouchStatus": '@"getTouchStatus"' in bridge and '[HLXTouch status]' in bridge,
    "Lua runtime exposes getTouchStatus through the native bridge": "rt.getTouchStatus = function()" in ui and "getTouchStatus: rt.getTouchStatus" in ui,
    "workflow selects Stage 5J before Stage 5I": workflow.index("Huluxia_1.0.0_阶段5J_原生HID触摸修复.zip") < workflow.index("Huluxia_1.0.0_阶段5I_shell续行符修复.zip"),
    "workflow runs the Stage 5J source validator": "python3 verify_stage5j_source.py" in workflow,
}
speed_hash = hashlib.sha256((root / "Sources/HLXSpeed.m").read_bytes()).hexdigest()
checks["HLXSpeed.m preserved byte-for-byte against Stage 5I baseline"] = speed_hash == "65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911"
for label, ok in checks.items():
    print(("PASS: " if ok else "FAIL: ") + label)
sys.exit(0 if all(checks.values()) else 1)
