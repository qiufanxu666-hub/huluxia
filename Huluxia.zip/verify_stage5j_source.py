#!/usr/bin/env python3
"""Stage 5N native HID touch + Bash 3.2 regression checks; filename retained for workflow compatibility."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
touch = (root / "Sources/HLXTouch.m").read_text()
header = (root / "Sources/HLXTouch.h").read_text()
bridge = (root / "Sources/HLXBridge.m").read_text()
ui = (root / "Resources/ui.html").read_text()
workflow = (root / ".github/workflows/build.yml").read_text()
overlay = (root / "Sources/HLXOverlay.m").read_text()

checks = {
    "IOHIDEventCreateDigitizerFingerEvent uses the exact 13-argument ABI": "typedef IOHIDEventRef (*HLXCreateFingerFn)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);" in touch,
    "BKSHIDEventSetDigitizerInfo uses the exact 7-argument ABI": "IOHIDEventRef,uint32_t,uint8_t,uint8_t,CFStringRef,CFTimeInterval,float" in touch,
    "digitizer parent is a Hand transducer": "#define kHLXTransducerHand 3u" in touch,
    "HID identity mask uses bit 5, not bit 3": "#define kHLXDigitizerIdentity (1u << 5)" in touch,
    "HID attribute mask uses bit 6": "#define kHLXDigitizerAttribute (1u << 6)" in touch,
    "touch child DOWN/UP use Range+Touch; MOVE uses Position": "const uint32_t childMask = moving" in touch and "(kHLXDigitizerRange | kHLXDigitizerTouch)" in touch and "? kHLXDigitizerPosition" in touch,
    "SpringBoard system-client path sets sender ID only for that path": "if (pSetSender) pSetSender(parent, 0xDEFACEDBEEFFECE5ULL);" in touch and touch.index("if (sbCanFallback)") < touch.index("if (pSetSender) pSetSender"),
    "movement includes Position and Attribute": "kHLXDigitizerPosition | kHLXDigitizerAttribute" in touch,
    "finger child events use unique indexes and Finger transducer identity": "kHLXFingerIndexes[kHLXMaxTouches] = { 2, 3, 4, 5, 1 }" in touch and "kHLXFingerIndexes[i], kHLXFingerIdentity, childMask" in touch,
    "each parent event contains appended finger child events": "pAppend(parent, finger, 0)" in touch and "CFRelease(finger)" in touch,
    "display-integrated marker setter is required before HID send": "return pCreateDigitizer && pCreateFinger && pAppend && pSetInt;" in touch,
    "stale delayed gesture events are invalidated on stop or new gesture": "gTouchGeneration" in touch and "gTouchGeneration != generation" in touch,
    "SpringBoard system-client path is selected before app-local enqueue": touch.index("if (sbCanFallback)") < touch.index("} else if (appCanEnqueue)"),
    "ordinary injected-app path attaches the window context before enqueue": "pSetDigitizerInfo(parent, contextID, 0, 0, NULL, 0, 0)" in touch and "objc_msgSend)(app, enqueue, parent)" in touch,
    "touch event timestamps use mach_absolute_time": "uint64_t timestamp = mach_absolute_time();" in touch,
    "coordinates are validated against the active window": "HLXNormalizePoint" in touch and "window.bounds.size" in touch,
    "multi-touch is capped at five fingers": "kHLXMaxTouches 5u" in touch and "points.count > kHLXMaxTouches" in touch,
    "touch cancellation releases all active fingers": "+ (void)cancelAll" in touch and "HLXEmit(NO, NO)" in touch,
    "multi-touch APIs are exposed through the native bridge": all(x in bridge for x in ('@"multiTap"', '@"multiDown"', '@"multiMove"', '@"multiUp"', '@"cancelTouch"')),
    "multi-touch JSON points are validated before dispatch": "HLXPointArray" in bridge and "多点触摸参数无效" in bridge,
    "Lua compatibility API exposes native multiTap": "multiTap:function(points,holdMs){return nativeTouch('multiTap'" in ui,
    "independent clicker panel exposes click, multi-touch, draggable-point swipe and stop": all(x in ui for x in ('id="clickerRunner"', "host.multiTap(clickerPoints.map", "host.swipe(startPoint.x, startPoint.y, endPoint.x, endPoint.y, duration)", "host.cancelTouch()")) and "clickerSX" not in ui and "clickerEX" not in ui,
    "JavaScript API exposes native multiTap": "rt.multiTap  = function(points, holdMs)" in ui,
    "HTML iframe receives native multi-touch methods": "w.multiTap   = rt.multiTap" in ui and "w.multiDown  = rt.multiDown" in ui,
    "legacy helper no longer falls back to DOM touch synthesis": "不会伪造 DOM 触摸" in ui and "[DOM] swipe(" not in ui and "[DOM] click(" not in ui,
    "getTouchStatus remains exposed with permission caveat": '@"getTouchStatus"' in bridge and '[HLXTouch status]' in bridge and 'dispatchNote' in touch,
    "iOS 13 windowScene is dynamically queried for old SDK compatibility": 'NSSelectorFromString(@"windowScene")' in overlay and "newWindow.windowScene" not in overlay,
    "iOS 11 content inset API is runtime-guarded": 'NSSelectorFromString(@"setContentInsetAdjustmentBehavior:")' in overlay and "UIScrollViewContentInsetAdjustmentNever" not in overlay,
    "workflow is labeled Stage 5W": "Stage 5W Daemon Theos clean fix" in workflow,
    "workflow prefers Stage 5W then 5V then 5U before historical archives": workflow.index("Huluxia_1.0.0_阶段5W_Daemon清理阶段Theos变量修复.zip") < workflow.index("Huluxia_1.0.0_阶段5V_真实应用图标与巨魔进程权限尝试.zip") < workflow.index("Huluxia_1.0.0_阶段5U_内存搜索文字修复与100倍变速.zip") < workflow.index("Huluxia_1.0.0_阶段5T_独立辅助服务与触摸派发修复.zip") < workflow.index("Huluxia_1.0.0_阶段5S_原生悬浮连点器重构.zip"),
    "workflow runs the native touch regression validator": "python3 verify_stage5j_source.py" in workflow,
}

speed_hash = hashlib.sha256((root / "Sources/HLXSpeed.m").read_bytes().replace(b'100.0', b'10.0').replace(b'100x', b'10x')).hexdigest()
checks["HLXSpeed.m preserves Stage 5Q algorithm except 100x limit"] = speed_hash == "5a53100c841f15929d485883623734e3ca74525dc567dbe25627dee8cd9e08c3"

for label, ok in checks.items():
    print(("PASS: " if ok else "FAIL: ") + label)
sys.exit(0 if all(checks.values()) else 1)
