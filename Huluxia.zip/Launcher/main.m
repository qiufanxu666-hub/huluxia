// 桌面启动器：启动后显示 GamePlayer 风格悬浮球，并保留控制页。
// 越狱版由 SpringBoard 中的 tweak 响应通知；TrollStore IPA 由内嵌 dylib 在本进程内响应。
#import <UIKit/UIKit.h>
#import <notify.h>
#import <dlfcn.h>
#import <objc/message.h>

static NSString *const kBallToggle = @"com.huluxia.ball.toggle";
static NSString *const kBallShow = @"com.huluxia.ball.show";
static NSString *const kHostProbe = @"com.huluxia.springboard.probe";
static NSString *const kHostReady = @"com.huluxia.springboard.ready";

static void HLXLoadEmbeddedDylib(void) {
    NSString *path = [NSBundle.mainBundle.bundlePath stringByAppendingPathComponent:@"Frameworks/Huluxia.dylib"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) return;
    static void *handle = NULL;
    if (!handle) {
        handle = dlopen(path.fileSystemRepresentation, RTLD_NOW | RTLD_GLOBAL);
        if (!handle) NSLog(@"[Huluxia] embedded dylib load failed: %s", dlerror());
    }
}

@interface HLXLauncherDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation HLXLauncherDelegate

- (void)toggleBall {
    notify_post(kBallToggle.UTF8String);
}

- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = [UIColor colorWithRed:0.08 green:0.10 blue:0.14 alpha:1.0];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(24, 100, vc.view.bounds.size.width - 48, 42)];
    title.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    title.text = @"葫芦侠";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:28];
    [vc.view addSubview:title];

    UILabel *info = [[UILabel alloc] initWithFrame:CGRectMake(24, 158, vc.view.bounds.size.width - 48, 150)];
    info.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    info.numberOfLines = 0;
    info.textColor = [UIColor colorWithWhite:1 alpha:0.78];
    info.font = [UIFont systemFontOfSize:15];
    info.text = @"启动葫芦侠后会自动显示悬浮球。点击悬浮球打开功能面板，在进程选择器中选择要扫描的游戏/App。\n\n越狱版由 SpringBoard 承载全局悬浮球，确认宿主响应后会自动返回桌面；TrollStore 版保持在本 App 内显示悬浮球。跨进程读写取决于系统是否授予 task_for_pid 权限。";
    [vc.view addSubview:info];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(24, 340, vc.view.bounds.size.width - 48, 52);
    button.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    button.backgroundColor = [UIColor colorWithRed:0.18 green:0.48 blue:0.88 alpha:1.0];
    button.layer.cornerRadius = 14;
    [button setTitle:@"显示 / 隐藏悬浮球" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    [button addTarget:self action:@selector(toggleBall) forControlEvents:UIControlEventTouchUpInside];
    [vc.view addSubview:button];

    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    // GamePlayer 式启动流程：先探测 SpringBoard，再显示全局球；只有收到 SpringBoard 应答才自动挂起启动器。
    // TrollStore 没有 SpringBoard Tweak 应答时，启动器保持前台，避免把本地悬浮球一起结束。
    int readyToken = 0;
    BOOL readyTokenValid = (notify_register_check(kHostReady.UTF8String, &readyToken) == NOTIFY_STATUS_OK);
    if (readyTokenValid) notify_set_state(readyToken, 0);
    notify_post(kHostProbe.UTF8String);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.55 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        uint64_t ready = 0;
        if (readyTokenValid) notify_get_state(readyToken, &ready);
        notify_post(kBallShow.UTF8String);
        if (readyTokenValid) notify_cancel(readyToken);
        if (ready == 1) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.85 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                UIApplication *application = UIApplication.sharedApplication;
                SEL suspendSelector = NSSelectorFromString(@"suspend");
                if ([application respondsToSelector:suspendSelector]) {
                    ((void (*)(id, SEL))objc_msgSend)(application, suspendSelector);
                }
            });
        }
    });
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        // 若 IPA 中含 Frameworks/Huluxia.dylib，启动时加载；越狱 DEB 中没有该文件，不受影响。
        HLXLoadEmbeddedDylib();
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(HLXLauncherDelegate.class));
    }
}
