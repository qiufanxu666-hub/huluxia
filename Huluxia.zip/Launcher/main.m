// 桌面图标：点击 → 通知 SpringBoard 呼出/收起悬浮窗；同时保留说明页
#import <UIKit/UIKit.h>
#import <notify.h>

static NSString *const kToggle = @"com.huluxia.toggle";

@interface HLXLauncherDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation HLXLauncherDelegate

- (void)postToggle {
    notify_post(kToggle.UTF8String);
}

- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    // 点击图标立即通知 SpringBoard 切换悬浮窗
    [self postToggle];

    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = [UIColor colorWithRed:0.1 green:0.5 blue:0.25 alpha:1];

    UILabel *l = [[UILabel alloc] initWithFrame:CGRectInset(vc.view.bounds, 24, 80)];
    l.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    l.numberOfLines = 0; l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:16];
    l.text = @"葫芦侠\n\n悬浮球已在桌面常驻。\n\n如未看到悬浮窗，请在被注入的游戏里呼出，或：\n\n1. 用 Filza 打开 Huluxia.plist\n2. 把游戏的 Bundle ID 加进去\n3. 重新打开游戏，约 2 秒后出现悬浮球\n\n（再次点击桌面图标可呼出/收起悬浮窗）";
    [vc.view addSubview:l];

    // 加一个"打开悬浮窗"按钮（手动重试）
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(0, 0, 220, 44);
    btn.center = CGPointMake(CGRectGetMidX(vc.view.bounds), CGRectGetMaxY(vc.view.bounds) - 100);
    btn.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    btn.backgroundColor = [UIColor whiteColor];
    [btn setTitle:@"打开/收起悬浮窗" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithRed:0.1 green:0.5 blue:0.25 alpha:1] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    btn.layer.cornerRadius = 22;
    [btn addTarget:self action:@selector(postToggle) forControlEvents:UIControlEventTouchUpInside];
    [vc.view addSubview:btn];

    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];

    // 3 秒后自动退出（悬浮窗已呼出）
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [app performSelector:@selector(suspend)];
    });
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(HLXLauncherDelegate.class)); }
}
