// 模拟原生宿主（仅用于测试 JS/Lua 兼容层，不是真机内存引擎）。
// 返回格式、表达式语义（= / >x / <x / a~b / a;b）尽量与 Sources/HLXMemory.m 保持一致。
(function () {
  const BASE = 0x100000000n;
  const dv = new DataView(new ArrayBuffer(0x10000));
  const SZ = { I8: 1, U8: 1, I16: 2, U16: 2, I32: 4, U32: 4, I64: 8, U64: 8, F32: 4, F64: 8 };
  const calls = [];
  let results = [], rtype = 'I32', paused = false, attached = false;
  const off = (a) => Number(BigInt(a) - BASE);
  const hex = (n) => '0x' + n.toString(16);
  function rd(addr, t) {
    const o = off(addr); if (o < 0 || o + SZ[t] > dv.byteLength) return null;
    switch (t) {
      case 'I8': return dv.getInt8(o); case 'U8': return dv.getUint8(o);
      case 'I16': return dv.getInt16(o, true); case 'U16': return dv.getUint16(o, true);
      case 'I32': return dv.getInt32(o, true); case 'U32': return dv.getUint32(o, true);
      case 'I64': return dv.getBigInt64(o, true); case 'U64': return dv.getBigUint64(o, true);
      case 'F32': return dv.getFloat32(o, true); case 'F64': return dv.getFloat64(o, true);
    }
  }
  function wr(addr, t, v) {
    const o = off(addr); if (o < 0 || o + SZ[t] > dv.byteLength) return false;
    switch (t) {
      case 'I8': dv.setInt8(o, Number(v)); break; case 'U8': dv.setUint8(o, Number(v)); break;
      case 'I16': dv.setInt16(o, Number(v), true); break; case 'U16': dv.setUint16(o, Number(v), true); break;
      case 'I32': dv.setInt32(o, Number(v), true); break; case 'U32': dv.setUint32(o, Number(v), true); break;
      case 'I64': dv.setBigInt64(o, BigInt(v), true); break; case 'U64': dv.setBigUint64(o, BigInt(v), true); break;
      case 'F32': dv.setFloat32(o, Number(v), true); break; case 'F64': dv.setFloat64(o, Number(v), true); break;
    }
    return true;
  }
  function fmt(v, t) {
    if (t === 'F32') { for (let p = 1; p <= 9; p++) { const s = Number(v).toPrecision(p); if (Math.fround(parseFloat(s)) === v) return String(parseFloat(s)); } }
    if (t === 'F64') return String(v);
    return String(v);
  }
  function num(s, t) {
    s = String(s).trim();
    if (t[0] === 'F') return s === 'inf' ? Infinity : s === '-inf' ? -Infinity : parseFloat(s);
    if (t === 'I64' || t === 'U64') return BigInt(s);
    return /^[-+]?0x/i.test(s) ? parseInt(s, 16) : Math.trunc(parseFloat(s));
  }
  function matcher(expr, t) {
    expr = String(expr).trim();
    if (expr.includes(';')) { const p = expr.split(';')[0]; const n = num(p, t); return (v) => v == n; }
    if (expr[0] === '>') { const n = num(expr.slice(1), t); return (v) => v > n; }
    if (expr[0] === '<') { const n = num(expr.slice(1), t); return (v) => v < n; }
    const ti = expr.indexOf('~', 1);
    if (ti > 0) { const a = num(expr.slice(0, ti), t), b = num(expr.slice(ti + 1), t); return (v) => v >= a && v <= b; }
    const n = num(expr, t); return (v) => (t === 'F32' ? Math.fround(n) === v : v == n);
  }
  function scan(expr, t, pool) {
    const m = matcher(expr, t), step = SZ[t], out = [];
    const addrs = pool || (() => { const a = []; for (let o = 0; o + step <= dv.byteLength; o += step) a.push(BASE + BigInt(o)); return a; })();
    for (const a of addrs) { const v = rd(a, t); if (v !== null && m(v)) out.push(a); }
    return out;
  }
  const rec = (name, fn) => function () { calls.push({ m: name, a: Array.prototype.slice.call(arguments) }); return fn.apply(null, arguments); };
  const H = {
    require: () => true,
    getProcList: () => [{ pid: 1234, name: 'MockGame', bundle: 'com.mock.game' }],
    setTargetProc: (pid) => { attached = true; return true; },
    getTargetInfo: () => ({ pid: 1234, name: 'MockGame', bundle: 'com.mock.game', packageName: 'com.mock.game' }),
    getRangesList: () => [{ start: hex(Number(BASE)), end: hex(Number(BASE) + 0x10000), type: 'rw-', name: 'mock' }],
    getRanges: () => [], setRanges: () => true,
    searchNumber: (expr, type, from, to) => {
      rtype = type;
      const pool = results.length ? results : null;      // 与原生一致：已有结果时再次扫描
      results = scan(expr, type, pool); return results.length;
    },
    refineNumber: (expr, type) => { rtype = type; results = scan(expr, type, results); return results.length; },
    getResultsCount: () => results.length,
    getResults: (n, skip) => results.slice(skip || 0, (skip || 0) + n).map((a) => ({ address: hex(Number(a)), value: fmt(rd(a, rtype), rtype), type: rtype })),
    clearResults: () => { results = []; return true; },
    editAll: (value, type) => { let k = 0; for (const a of results) if (wr(a, type, num(value, type))) k++; return k; },
    getValue: (addr, type) => { const v = rd(addr, type); return v === null ? null : fmt(v, type); },
    setValue: (addr, value, type) => wr(addr, type, num(value, type)),
    copyText: () => true,
    click: () => true, tap: () => true, swipe: () => true, longClick: () => true, touchDown: () => true, touchMove: () => true, touchUp: () => true,
    processPause: () => { paused = true; return true; },
    processResume: () => { paused = false; return true; },
  };
  const host = {};
  Object.keys(H).forEach((k) => { host[k] = rec(k, H[k]); });
  window.h5gg = host;
  window.__mock = {
    BASE: Number(BASE), calls, isPaused: () => paused,
    poke: (offset, type, value) => wr(BASE + BigInt(offset), type, value),
    peek: (offset, type) => { const v = rd(BASE + BigInt(offset), type); return typeof v === 'bigint' ? v.toString() : v; },
    reset: () => { results = []; calls.length = 0; paused = false; new Uint8Array(dv.buffer).fill(0); },
  };
})();
