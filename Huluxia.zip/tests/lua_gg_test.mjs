// Lua / GG 兼容层测试：在 Chromium 里加载真实的 ui.html（含 Fengari），挂模拟原生宿主 mock_host.js。
// 这是“模拟环境”测试：验证 JS/Lua 层逻辑，不覆盖 Objective-C 原生内存引擎，也不是真机测试。
// 用法: node lua_gg_test.mjs [ui.html 路径] [标签]
import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import fs from 'fs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
const uiPath = path.resolve(process.argv[2] || path.join(here, '../Resources/ui.html'));
const label = process.argv[3] || 'current';
const mockSrc = fs.readFileSync(path.join(here, 'mock_host.js'), 'utf8');

const results = [];
async function newPage(browser) {
  const page = await browser.newPage({ viewport: { width: 420, height: 860 } });
  await page.addInitScript(mockSrc);
  page.__errors = [];
  page.on('pageerror', (e) => page.__errors.push(e.message));
  await page.goto(pathToFileURL(uiPath).href);
  await page.waitForFunction(() => window.h5ok === true, null, { timeout: 20000 });
  await page.evaluate(() => {
    window.__out = [];
    const o = window.luaOutLine;
    window.luaOutLine = function (t) { window.__out.push(String(t)); return o.apply(this, arguments); };
  });
  return page;
}
const out = (page) => page.evaluate(() => window.__out.join('\n'));
async function run(page, code) {
  await page.evaluate((c) => { window.__out.length = 0; document.getElementById('luaEditor').value = c; runLuaScript(); }, code);
}
const idle = (page, ms = 8000) => page.waitForFunction(() => !window.luaRunning, null, { timeout: ms });
const clickAll = (page, sel, i) => page.evaluate(([s, n]) => { const els = document.querySelectorAll(s); els[n].click(); return els.length; }, [sel, i]);
const clickBtn = (page, text) => page.evaluate((t) => { const b = [...document.querySelectorAll('#luaScriptUI .lua-ui-btn')].find((x) => x.textContent.trim() === t); if (!b) throw new Error('no button ' + t); b.click(); }, text);
const waitUI = (page, sel) => page.waitForSelector(sel, { state: 'attached', timeout: 8000 });
const mock = (page, fn, ...a) => page.evaluate(([f, args]) => window.__mock[f](...args), [fn, a]);

function test(group, name, fn) { results.push({ group, name, fn }); }
const eq = (a, b, msg) => { if (a !== b) throw new Error(`${msg || 'assert'}: expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const has = (s, sub, msg) => { if (!s.includes(sub)) throw new Error(`${msg || 'assert'}: output lacks ${JSON.stringify(sub)}\n--- output ---\n${s}`); };

// ───────── 1. Lua 基础语法 / 函数调用 ─────────
test('Lua 基础', '语法：循环/闭包/元表/协程/整除/位运算/goto/字符串库', async (p) => {
  await run(p, `local t = {}
for i = 1, 5 do t[#t+1] = i * i end
local function fib(n) if n < 2 then return n end return fib(n-1) + fib(n-2) end
local mt = setmetatable({}, {__index = function(_, k) return k .. "!" end})
local co = coroutine.wrap(function() coroutine.yield(1); coroutine.yield(2) end)
print(table.concat(t, ","), fib(15), 7 // 2, 7 & 3, 1 << 4, mt.hi, co(), co(), string.format("%5.2f", 3.14159))
goto done
print("skipped")
::done::
print(("x"):rep(3), select("#", 1, 2, 3), math.type(1), math.type(1.0))`);
  await idle(p); const o = await out(p);
  has(o, '1,4,9,16,25\t610\t3\t3\t16\thi!\t1\t2\t 3.14'); has(o, 'xxx\t3\tinteger\tfloat'); if (o.includes('skipped')) throw new Error('goto 失效');
});
test('Lua 基础', '函数调用/pcall/error/运行时错误信息', async (p) => {
  await run(p, `local ok, err = pcall(function() error("boom") end)
print(ok, err)
print(select(2, pcall(function() local x = nil; return x.y end)))`);
  await idle(p); const o = await out(p); has(o, 'false'); has(o, 'boom'); has(o, 'attempt to index');
});
test('Lua 基础', '语法错误被捕获并显示，不会崩溃页面', async (p) => {
  await run(p, `local x = = 1`); await idle(p); has(await out(p), '语法错误'); eq(p.__errors.length, 0, '页面不应抛未捕获异常');
});

// ───────── 2. GG API 注册与常量 ─────────
test('GG 注册', '24 个要求接口全部为函数', async (p) => {
  await run(p, `local names = {"searchNumber","refineNumber","getResults","getResultsCount","clearResults","getValues","setValues","editAll","addListItems","removeListItems","alert","choice","multiChoice","prompt","toast","setVisible","isVisible","sleep","getFile","getTargetInfo","getRangesList","getSelectedElements","processPause","processResume"}
local missing = {}
for _, n in ipairs(names) do if type(gg[n]) ~= "function" then missing[#missing+1] = n end end
print("MISSING:" .. table.concat(missing, ","))`);
  await idle(p); has(await out(p), 'MISSING:\n'.slice(0, 8)); const o = await out(p); eq(o.split('MISSING:')[1].split('\n')[0], '', '缺失接口');
});
test('GG 注册', 'TYPE_* 常量与安卓 GG 数值一致 (1/2/4/8/16/32/64/127)', async (p) => {
  await run(p, `print("TYPES", gg.TYPE_BYTE, gg.TYPE_WORD, gg.TYPE_DWORD, gg.TYPE_XOR, gg.TYPE_FLOAT, gg.TYPE_QWORD, gg.TYPE_DOUBLE, gg.TYPE_AUTO)`);
  await idle(p); has(await out(p), 'TYPES\t1\t2\t4\t8\t16\t32\t64\t127');
});

// ───────── 3. 脚本 UI 交互 ─────────
test('GG 菜单', 'gg.choice：点第 2 项返回 2；退出菜单返回 nil', async (p) => {
  await run(p, `local r = gg.choice({"Alpha","Beta","Gamma"}, nil, "Pick")
print("CHOICE=" .. tostring(r))`);
  await waitUI(p, '#luaScriptUI .lua-ui-item'); eq(await clickAll(p, '#luaScriptUI .lua-ui-item', 1), 3, '菜单项数');
  await idle(p); has(await out(p), 'CHOICE=2');
  await run(p, `print("C2=" .. tostring(gg.choice({"A","B"})))`);
  await waitUI(p, '#luaScriptUI .lua-ui-item'); await clickBtn(p, '退出菜单'); await idle(p); has(await out(p), 'C2=nil');
});
test('GG 菜单', 'gg.multiChoice：勾选 1、3 返回 {1,3}', async (p) => {
  await run(p, `local r = gg.multiChoice({"A","B","C"}, nil, "Multi")
local ks = {} ; for i, v in ipairs(r or {}) do ks[#ks+1] = tostring(v) end
print("MULTI=" .. table.concat(ks, ","))`);
  await waitUI(p, '#luaScriptUI .lua-ui-item'); await clickAll(p, '#luaScriptUI .lua-ui-item', 0); await clickAll(p, '#luaScriptUI .lua-ui-item', 2);
  await clickBtn(p, '确定'); await idle(p); has(await out(p), 'MULTI=1,3');
});
test('GG 输入框', 'gg.prompt：文本+数字+复选框，数字返回为 number', async (p) => {
  await run(p, `local r = gg.prompt({"Name","Num","On"}, {[1]="bob",[2]="5",[3]=false}, {[1]="text",[2]="number",[3]="checkbox"})
print("PROMPT", r[1], math.type(r[2]), r[2] + 1, tostring(r[3]))`);
  await waitUI(p, '#luaScriptUI .lua-ui-field');
  await p.evaluate(() => { const f = document.querySelectorAll('#luaScriptUI .lua-ui-field'); f[1].querySelector('input').value = '41'; f[2].querySelector('.lua-ui-sw').click(); });
  await clickBtn(p, '确定'); await idle(p); has(await out(p), 'PROMPT\tbob\tinteger\t42\ttrue');
});
test('GG 菜单', 'gg.alert：点第二个按钮返回 2', async (p) => {
  await run(p, `print("ALERT=" .. tostring(gg.alert("hi", "Yes", "No")))`);
  await waitUI(p, '#luaScriptUI .lua-ui-btn'); await clickBtn(p, 'No'); await idle(p); has(await out(p), 'ALERT=2');
});

// ───────── 4. 内存搜索 / 读 / 写（对 mock 宿主） ─────────
const seed = async (p) => { await mock(p, 'reset'); await mock(p, 'poke', 0x100, 'I32', 1234); await mock(p, 'poke', 0x200, 'I32', 1234); await mock(p, 'poke', 0x300, 'I32', 99); await mock(p, 'poke', 0x400, 'F32', 1.5); await mock(p, 'poke', 0x500, 'I32', 1234); };
test('内存', 'searchNumber → 计数 / getResults 含 flags(number) 与 number 值', async (p) => {
  await seed(p);
  await run(p, `gg.clearResults()
gg.searchNumber("1234", gg.TYPE_DWORD)
local r = gg.getResults(10)
print("N=" .. gg.getResultsCount(), r[1].flags, math.type(r[1].value), r[1].value)`);
  await idle(p); has(await out(p), 'N=3\t4\tinteger\t1234');
});
test('内存', 'getResults(count, skip) 分页', async (p) => {
  await seed(p);
  await run(p, `gg.clearResults(); gg.searchNumber("1234", gg.TYPE_DWORD)
local a = gg.getResults(2, 2)
print("PAGE=" .. #a)`);
  await idle(p); has(await out(p), 'PAGE=1');
});
test('内存', 'getResults 分页：第 1 页与第 2 页地址不重叠、合计 3 条', async (p) => {
  await seed(p);
  await run(p, `gg.clearResults(); gg.searchNumber("1234", gg.TYPE_DWORD)
local a, b = gg.getResults(2, 0), gg.getResults(2, 2)
print("PG=" .. #a .. "," .. #b .. "," .. tostring(a[1].address ~= b[1].address))`);
  await idle(p); has(await out(p), 'PG=2,1,true');
});
test('内存', 'refineNumber 缩小结果', async (p) => {
  await seed(p); await mock(p, 'poke', 0x200, 'I32', 7);
  await run(p, `gg.clearResults(); gg.searchNumber("1234", gg.TYPE_DWORD); gg.refineNumber("1234", gg.TYPE_DWORD)
print("REF=" .. gg.getResultsCount())`);
  await idle(p); has(await out(p), 'REF=2');
});
test('内存', 'setValues 以 flags=TYPE_FLOAT 写入浮点（标准 GG 写法）', async (p) => {
  await seed(p);
  await run(p, `local base = ${0x100000000}
local ok = gg.setValues({{address = base + 0x400, flags = gg.TYPE_FLOAT, value = 3.25}})
print("SET=" .. tostring(ok))`);
  await idle(p); has(await out(p), 'SET=1'); eq(await mock(p, 'peek', 0x400, 'F32'), 3.25, '浮点应被按 F32 写入');
});
test('内存', 'getValues 读回 F32 / I32 为 number', async (p) => {
  await seed(p);
  await run(p, `local base = ${0x100000000}
local v = gg.getValues({{address = base + 0x400, flags = gg.TYPE_FLOAT}, {address = base + 0x100, flags = gg.TYPE_DWORD}})
print("GET=" .. v[1].value .. "," .. v[2].value, math.type(v[2].value))`);
  await idle(p); has(await out(p), 'GET=1.5,1234\tinteger');
});
test('内存', 'editAll 修改全部结果并回读验证', async (p) => {
  await seed(p);
  await run(p, `gg.clearResults(); gg.searchNumber("1234", gg.TYPE_DWORD)
local n = gg.editAll("777", gg.TYPE_DWORD)
print("EDIT=" .. tostring(n))`);
  await idle(p); has(await out(p), 'EDIT=3');
  for (const o of [0x100, 0x200, 0x500]) eq(await mock(p, 'peek', o, 'I32'), 777, `0x${o.toString(16)}`);
  eq(await mock(p, 'peek', 0x300, 'I32'), 99, '非结果地址不应被改');
});
test('内存', 'addListItems / removeListItems 计数', async (p) => {
  await run(p, `local base = ${0x100000000}
local n = gg.addListItems({{address = base + 16, flags = gg.TYPE_DWORD, value = 1}, {address = base + 32, flags = gg.TYPE_DWORD, value = 2}})
local m = gg.removeListItems({{address = base + 16}})
print("LIST=" .. tostring(n) .. "," .. tostring(m))`);
  await idle(p); has(await out(p), 'LIST=2,1');
});

// ───────── 5. 数据类型 / sign 处理 ─────────
test('数据类型', 'SIGN_GREATER / SIGN_LESS_OR_EQUAL / SIGN_GREATER_OR_EQUAL 被翻译成原生表达式', async (p) => {
  await seed(p); await mock(p, 'reset');
  await run(p, `gg.clearResults(); gg.searchNumber("100", gg.TYPE_DWORD, false, gg.SIGN_GREATER)
gg.clearResults(); gg.searchNumber("100", gg.TYPE_DWORD, false, gg.SIGN_LESS_OR_EQUAL)
gg.clearResults(); gg.searchNumber("100", gg.TYPE_DWORD, false, gg.SIGN_GREATER_OR_EQUAL)
print("DONE")`);
  await idle(p); has(await out(p), 'DONE');
  const ex = await p.evaluate(() => window.__mock.calls.filter((c) => c.m === 'searchNumber').map((c) => c.a[0]));
  eq(JSON.stringify(ex), JSON.stringify(['>100', '-2147483648~100', '100~2147483647']), '传给原生的表达式');
});
test('数据类型', 'SIGN_NOT_EQUAL 明确报“不支持”', async (p) => {
  await run(p, `local ok, e = pcall(gg.searchNumber, "1", gg.TYPE_DWORD, false, gg.SIGN_NOT_EQUAL) print(tostring(ok), e)`);
  await idle(p); has(await out(p), '不支持 gg.SIGN_NOT_EQUAL');
});
test('数据类型', 'TYPE_XOR / TYPE_AUTO / DWORD|FLOAT 组合 / encrypted=true 都明确报错，不会静默当 I32', async (p) => {
  await run(p, `for _, t in ipairs({gg.TYPE_XOR, gg.TYPE_AUTO, gg.TYPE_DWORD | gg.TYPE_FLOAT}) do
  local ok, e = pcall(gg.searchNumber, "1", t) print(tostring(ok), e)
end
local ok, e = pcall(gg.searchNumber, "1", gg.TYPE_DWORD, true) print(tostring(ok), e)`);
  await idle(p); const o = await out(p); has(o, '不支持 gg.TYPE_XOR'); has(o, '不支持 gg.TYPE_AUTO'); has(o, '数据类型组合'); has(o, 'encrypted=true');
  eq(await p.evaluate(() => window.__mock.calls.filter((c) => c.m === 'searchNumber').length), 0, '这些调用不应到达原生层');
});
test('数据类型', '各类型往返：BYTE/WORD/DWORD/QWORD/FLOAT/DOUBLE（有符号负数、小数）', async (p) => {
  await mock(p, 'reset');
  await run(p, `local b = ${0x100000000}
gg.setValues({{address=b+0,flags=gg.TYPE_BYTE,value=-5},{address=b+8,flags=gg.TYPE_WORD,value=-300},{address=b+16,flags=gg.TYPE_DWORD,value=-70000},{address=b+24,flags=gg.TYPE_QWORD,value=5000000000},{address=b+32,flags=gg.TYPE_FLOAT,value=0.1},{address=b+40,flags=gg.TYPE_DOUBLE,value=2.718281828}})
local g = gg.getValues({{address=b+0,flags=gg.TYPE_BYTE},{address=b+8,flags=gg.TYPE_WORD},{address=b+16,flags=gg.TYPE_DWORD},{address=b+24,flags=gg.TYPE_QWORD},{address=b+32,flags=gg.TYPE_FLOAT},{address=b+40,flags=gg.TYPE_DOUBLE}})
local s = {} ; for i, v in ipairs(g) do s[#s+1] = string.format("%.14g", v.value) end
print("RT=" .. table.concat(s, "|"))`);
  await idle(p); has(await out(p), 'RT=-5|-300|-70000|5000000000|0.1|2.718281828');
});

// ───────── 6. 进程控制 / 兼容性占位的真实性 ─────────
test('进程', 'processPause / processResume / processToggle 真正调用宿主', async (p) => {
  await mock(p, 'reset');
  await run(p, `gg.processPause() local a = true gg.processResume() gg.processToggle() print("PR")`);
  await idle(p); has(await out(p), 'PR');
  const seq = await p.evaluate(() => window.__mock.calls.filter((c) => /^process/.test(c.m)).map((c) => c.m));
  eq(JSON.stringify(seq), JSON.stringify(['processPause', 'processResume', 'processPause']), '宿主调用序列'); eq(await p.evaluate(() => window.__mock.isPaused()), true, '最终应为暂停态');
});
test('兼容', 'getFile 不再返回不存在的 /sdcard 路径；getSelectedElements 明确报不支持', async (p) => {
  await run(p, `print("FILE=[" .. tostring(gg.getFile()) .. "]")
local ok, e = pcall(gg.getSelectedElements) print(tostring(ok), e)`);
  await idle(p); const o = await out(p); has(o, 'FILE=[]'); has(o, '不支持 gg.getSelectedElements');
});
test('兼容', 'freeze=true 给出明确告警（引擎没有冻结实现）', async (p) => {
  await mock(p, 'reset');
  await p.evaluate(() => { window.__logs = []; const l = window.log; window.log = function (m) { window.__logs.push(String(m)); return l.apply(this, arguments); }; });
  await run(p, `gg.setValues({{address=${0x100000000}+8, flags=gg.TYPE_DWORD, value=1, freeze=true}}) print("OK")`);
  await idle(p); eq((await p.evaluate(() => window.__logs.filter((m) => m.includes('freeze=true 未生效')).length)) >= 1, true, '应有 freeze 告警');
});

// ───────── 7. 稳定性：停止 / 超时 / 状态隔离 / 重复运行 ─────────
test('稳定性', '停止脚本：挂起在菜单上点停止后，运行状态复位、旧协程不会再被唤醒', async (p) => {
  await run(p, `local r = gg.choice({"A","B"}) print("AFTER-STOP-SHOULD-NOT-PRINT")`);
  await waitUI(p, '#luaScriptUI .lua-ui-item'); await p.evaluate(() => stopLuaScript());
  eq(await p.evaluate(() => window.luaRunning), false, 'luaRunning'); eq(await p.evaluate(() => window.luaCoState), null, 'luaCoState');
  await p.evaluate(() => { try { luaCoResumeWith([1]); } catch (e) {} });
  if ((await out(p)).includes('AFTER-STOP-SHOULD-NOT-PRINT')) throw new Error('停止后旧协程仍被唤醒');
});
test('稳定性', '死循环被超时钩子中断，页面保持可响应', async (p) => {
  await p.evaluate(() => { const e = document.getElementById('luaTimeLimit'); if (e) e.value = '1000'; });
  const t0 = Date.now();
  await run(p, `while true do end`); await idle(p, 15000);
  const dt = Date.now() - t0; if (dt > 6000) throw new Error('超时中断太慢: ' + dt + 'ms');
  has(await out(p), '超时'); eq(await p.evaluate(() => 1 + 1), 2, '页面仍可执行脚本');
});
test('稳定性', '脚本间状态隔离：上一个脚本的全局变量不会泄漏到下一个', async (p) => {
  await run(p, `LEAKED_GLOBAL = 42 print("A")`); await idle(p);
  await run(p, `print("LEAK=" .. tostring(LEAKED_GLOBAL))`); await idle(p); has(await out(p), 'LEAK=nil');
});
test('稳定性', '连续运行 40 次均正常结束，运行状态不卡住', async (p) => {
  for (let i = 0; i < 40; i++) { await run(p, `local s = 0 for k = 1, 100 do s = s + k end print("S=" .. s)`); await idle(p, 4000); has(await out(p), 'S=5050'); }
  eq(await p.evaluate(() => window.luaRunning), false);
});

// ───────── runner ─────────
const browser = await chromium.launch();
let pass = 0, fail = 0; const report = [];
for (const t of results) {
  const page = await newPage(browser);
  let status = 'PASS', detail = '';
  try { await t.fn(page); } catch (e) { status = 'FAIL'; detail = String(e.message).split('\n')[0].slice(0, 220); }
  if (page.__errors.length && status === 'PASS') { status = 'FAIL'; detail = '页面未捕获异常: ' + page.__errors[0].slice(0, 160); }
  status === 'PASS' ? pass++ : fail++;
  report.push({ group: t.group, name: t.name, status, detail });
  console.log(`${status === 'PASS' ? '✅' : '❌'} [${t.group}] ${t.name}${detail ? '\n     → ' + detail : ''}`);
  await page.close();
}
await browser.close();
console.log(`\n[${label}] ${pass} passed, ${fail} failed, ${results.length} total`);
fs.writeFileSync(path.join(here, `results_${label}.json`), JSON.stringify({ label, uiPath, pass, fail, report }, null, 2));
process.exit(fail ? 1 : 0);
