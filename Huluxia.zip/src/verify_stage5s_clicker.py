#!/usr/bin/env python3
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
ui = (root / "Resources/ui.html").read_text()
points = (root / "Sources/HLXTouchPoints.m").read_text()
touch = (root / "Sources/HLXTouch.m").read_text()
bridge = (root / "Sources/HLXBridge.m").read_text()
plist = (root / "Huluxia.plist").read_text()
speed = (root / "Sources/HLXSpeed.m").read_bytes()
checks = {
    "removed the in-panel fake screen grid": "clickerStage" not in ui and "clickerRenderStage" not in ui,
    "native points are pulled back after direct screen dragging": "clickerPullNativePoints" in ui and "host.getTouchPoints()" in ui,
    "add button generates draggable points without requiring coordinates": "生成可拖动触摸点" in ui and "if (!xText && !yText)" in ui,
    "runner exposes native point refresh/show/hide controls": all(x in ui for x in ("clickerRefreshPoints", "clickerShowPoints", "clickerHidePoints")),
    "clicker starts using current native overlay coordinates": "clickerPullNativePoints()" in ui and "setTouchPointMode('run')" in ui,
    "overlay edit handles stay draggable": "UIPanGestureRecognizer" in points and "self.locations[handle.pointIndex] = [NSValue valueWithCGPoint:point]" in points,
    "overlay is pass-through while automated clicker is running": "== 1) return nil;" in points,
    "overlay remains limited to five points": "if (safe.count >= 5) break;" in points,
    "HID uses normalized coordinates rather than raw UIKit point values": "normalizedX" in touch and "normalizedY" in touch and "p.x / displaySize.width" in touch,
    "HID status warns that availability is not a delivery receipt": "没有系统接收回执" in touch,
    "bridge retains multiTap and native point APIs": all(x in bridge for x in ("multiTap", "setTouchPoints", "getTouchPoints", "setTouchPointMode")),
    "injection filter is SpringBoard-only": "com.apple.springboard" in plist and "com.apple.UIKit" not in plist,
    "speed engine remains byte-identical to Stage 5Q": hashlib.sha256(speed).hexdigest() == "5a53100c841f15929d485883623734e3ca74525dc567dbe25627dee8cd9e08c3",
}
for label, ok in checks.items(): print(("PASS: " if ok else "FAIL: ") + label)
raise SystemExit(0 if all(checks.values()) else 1)
