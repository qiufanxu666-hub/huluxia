#import "HLXTouch.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <mach/mach_time.h>
#import <objc/message.h>
#import <math.h>
#import <string.h>

// Private IOHID SPI is resolved at runtime to keep old SDK headers usable.
typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDEventSystemClient *IOHIDEventSystemClientRef;
typedef IOHIDEventRef (*HLXCreateDigitizerFn)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
typedef IOHIDEventRef (*HLXCreateFingerFn)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
typedef void (*HLXAppendEventFn)(IOHIDEventRef,IOHIDEventRef,uint32_t);
typedef void (*HLXSetIntegerFn)(IOHIDEventRef,uint32_t,int64_t);
typedef void (*HLXSetFloatFn)(IOHIDEventRef,uint32_t,double);
typedef void (*HLXSetSenderFn)(IOHIDEventRef,uint64_t);
typedef IOHIDEventSystemClientRef (*HLXClientCreateFn)(CFAllocatorRef);
typedef void (*HLXClientDispatchFn)(IOHIDEventSystemClientRef,IOHIDEventRef);
typedef void (*HLXSetDigitizerInfoFn)(IOHIDEventRef,uint32_t,uint8_t,uint8_t,CFStringRef,CFTimeInterval,float);

static HLXCreateDigitizerFn pCreateDigitizer;
static HLXCreateFingerFn pCreateFinger;
static HLXAppendEventFn pAppend;
static HLXSetIntegerFn pSetInt;
static HLXSetFloatFn pSetFloat;
static HLXSetSenderFn pSetSender;
static HLXClientCreateFn pClientCreate;
static HLXClientDispatchFn pClientDispatch;
static HLXSetDigitizerInfoFn pSetDigitizerInfo;
static IOHIDEventSystemClientRef gClient;
static dispatch_once_t gOnce;

// IOHIDDigitizerEventMask values from IOHIDEventTypes.h.
#define kHLXDigitizerRange    (1u << 0)
#define kHLXDigitizerTouch    (1u << 1)
#define kHLXDigitizerPosition (1u << 2)
#define kHLXDigitizerIdentity (1u << 5)
#define kHLXDigitizerAttribute (1u << 6)
#define kHLXFieldDisplayIntegrated 0x000B0019u
#define kHLXFieldMajor 0x000B0014u
#define kHLXFieldMinor 0x000B0015u
#define kHLXTransducerHand 3u
#define kHLXMaxTouches 5u
static const uint32_t kHLXFingerIdentifiers[kHLXMaxTouches] = { 2, 3, 4, 5, 1 };

typedef struct { CGPoint point; BOOL active; } HLXActiveTouch;
static HLXActiveTouch gTouches[kHLXMaxTouches];
static NSUInteger gTouchCount;
static BOOL gTouchInProgress;
static uint64_t gTouchGeneration;

static void HLXLoad(void) {
    dispatch_once(&gOnce, ^{
        void *io = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
        if (io) {
            pCreateDigitizer = (HLXCreateDigitizerFn)dlsym(io, "IOHIDEventCreateDigitizerEvent");
            pCreateFinger = (HLXCreateFingerFn)dlsym(io, "IOHIDEventCreateDigitizerFingerEvent");
            pAppend = (HLXAppendEventFn)dlsym(io, "IOHIDEventAppendEvent");
            pSetInt = (HLXSetIntegerFn)dlsym(io, "IOHIDEventSetIntegerValue");
            pSetFloat = (HLXSetFloatFn)dlsym(io, "IOHIDEventSetFloatValue");
            pSetSender = (HLXSetSenderFn)dlsym(io, "IOHIDEventSetSenderID");
            pClientCreate = (HLXClientCreateFn)dlsym(io, "IOHIDEventSystemClientCreate");
            pClientDispatch = (HLXClientDispatchFn)dlsym(io, "IOHIDEventSystemClientDispatchEvent");
        }
        void *bks = dlopen("/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices", RTLD_NOW);
        if (bks) pSetDigitizerInfo = (HLXSetDigitizerInfoFn)dlsym(bks, "BKSHIDEventSetDigitizerInfo");
        if (pClientCreate) gClient = pClientCreate(kCFAllocatorDefault);
    });
}

static UIWindow *HLXActiveWindow(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (!app) return nil;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in app.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            for (UIWindow *w in ((UIWindowScene *)scene).windows)
                if (w.isKeyWindow && !w.hidden) return w;
        }
    }
#endif
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    if (app.keyWindow && !app.keyWindow.hidden) return app.keyWindow;
#pragma clang diagnostic pop
    for (UIWindow *w in app.windows) if (w.isKeyWindow && !w.hidden) return w;
    return app.windows.firstObject;
}

static uint32_t HLXWindowContextID(UIWindow *window) {
    if (!window) return 0;
    SEL sel = NSSelectorFromString(@"_contextId");
    if (![window respondsToSelector:sel]) return 0;
    @try { return ((uint32_t(*)(id,SEL))objc_msgSend)(window, sel); }
    @catch (__unused NSException *e) { return 0; }
}

static BOOL HLXIsSpringBoard(void) {
    return [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"];
}

static BOOL HLXSymbolsReady(void) {
    HLXLoad();
    return pCreateDigitizer && pCreateFinger && pAppend && pSetInt;
}

static BOOL HLXNormalizePoint(CGPoint *point, UIWindow *window) {
    if (!point || !isfinite(point->x) || !isfinite(point->y) || point->x < 0 || point->y < 0) return NO;
    CGSize bounds = window ? window.bounds.size : UIScreen.mainScreen.bounds.size;
    if ((point->x > bounds.width || point->y > bounds.height) && UIScreen.mainScreen.scale > 1.0) {
        CGFloat scale = UIScreen.mainScreen.scale;
        CGPoint pixels = CGPointMake(point->x / scale, point->y / scale);
        CGSize native = UIScreen.mainScreen.nativeBounds.size;
        if (pixels.x <= bounds.width && pixels.y <= bounds.height &&
            point->x <= MAX(native.width, native.height) && point->y <= MAX(native.width, native.height))
            *point = pixels;
    }
    return point->x <= bounds.width && point->y <= bounds.height;
}

// Must run on main. One parent digitizer event contains every active finger.
static BOOL HLXEmit(BOOL touching, BOOL moving) {
    if (!HLXSymbolsReady() || gTouchCount == 0) return NO;
    UIApplication *app = UIApplication.sharedApplication;
    UIWindow *window = HLXActiveWindow();
    uint32_t contextID = HLXWindowContextID(window);
    SEL enqueue = NSSelectorFromString(@"_enqueueHIDEvent:");
    BOOL appCanEnqueue = app && [app respondsToSelector:enqueue] && contextID != 0 && pSetDigitizerInfo;
    BOOL sbCanFallback = HLXIsSpringBoard() && gClient && pClientDispatch;
    if (!appCanEnqueue && !sbCanFallback) return NO;

    uint32_t parentMask = moving ? (kHLXDigitizerPosition | kHLXDigitizerAttribute) : (kHLXDigitizerRange | kHLXDigitizerTouch | kHLXDigitizerIdentity);
    uint32_t childMask = moving ? (kHLXDigitizerPosition | kHLXDigitizerAttribute) : (kHLXDigitizerRange | kHLXDigitizerTouch | kHLXDigitizerIdentity);
    uint64_t timestamp = mach_absolute_time();
    IOHIDEventRef parent = pCreateDigitizer(kCFAllocatorDefault, timestamp,
        kHLXTransducerHand, 0, 0, parentMask, 0, 0, 0, 0, 0, 0, 0, touching, 0);
    if (!parent) return NO;
    if (pSetInt) pSetInt(parent, kHLXFieldDisplayIntegrated, 1);

    BOOL built = YES;
    for (NSUInteger i = 0; i < gTouchCount; i++) {
        if (!gTouches[i].active) continue;
        CGPoint p = gTouches[i].point;
        // IOHID digitizer finger coordinates are normalized to the active
        // display's 0.0-1.0 coordinate space, while the public API uses UIKit
        // points. Passing raw UIKit values (e.g. 300, 700) produces invalid
        // digitizer coordinates and is a common reason games ignore the event.
        CGSize displaySize = window ? window.bounds.size : UIScreen.mainScreen.bounds.size;
        if (displaySize.width <= 0 || displaySize.height <= 0) { built = NO; break; }
        double normalizedX = MAX(0.0, MIN(1.0, p.x / displaySize.width));
        double normalizedY = MAX(0.0, MIN(1.0, p.y / displaySize.height));
        IOHIDEventRef finger = pCreateFinger(kCFAllocatorDefault, timestamp,
            kHLXFingerIdentifiers[i], kHLXFingerIdentifiers[i], childMask,
            normalizedX, normalizedY, 0, touching ? 0.0 : 0.0, 0,
            touching, touching, 0);
        if (!finger) { built = NO; break; }
        if (pSetFloat) {
            pSetFloat(finger, kHLXFieldMajor, 5.0);
            pSetFloat(finger, kHLXFieldMinor, 5.0);
        }
        pAppend(parent, finger, 0);
        CFRelease(finger);
    }

    if (built) {
        // SpringBoard uses the system HID client to route events to the foreground app.
        // Injected target apps use their own window context and UIApplication queue.
        if (sbCanFallback) {
            // In SpringBoard the system client is used to route the synthetic
            // event into the foreground application, not back into SpringBoard.
            // This sender ID is used by established IOHIDEventSystemClient injectors;
            // ordinary target-app enqueue deliberately does not override sender ID.
            if (pSetSender) pSetSender(parent, 0xDEFACEDBEEFFECE5ULL);
            pClientDispatch(gClient, parent);
        } else if (appCanEnqueue) {
            // In an injected target app, bind the event to that app's window.
            pSetDigitizerInfo(parent, contextID, 0, 0, NULL, 0, 0);
            ((void(*)(id,SEL,IOHIDEventRef))objc_msgSend)(app, enqueue, parent);
        } else {
            built = NO;
        }
    }
    CFRelease(parent);
    return built;
}

static BOOL HLXOnMain(BOOL (^block)(void)) {
    if (NSThread.isMainThread) return block();
    __block BOOL result = NO;
    dispatch_sync(dispatch_get_main_queue(), ^{ result = block(); });
    return result;
}

static uint64_t HLXReadGeneration(void) {
    __block uint64_t generation = 0;
    HLXOnMain(^BOOL{ generation = gTouchGeneration; return YES; });
    return generation;
}

static NSArray<NSValue *> *HLXValidatedPoints(NSArray<NSValue *> *points, UIWindow *window) {
    if (![points isKindOfClass:NSArray.class] || points.count == 0 || points.count > kHLXMaxTouches) return nil;
    NSMutableArray *out = [NSMutableArray arrayWithCapacity:points.count];
    for (id item in points) {
        if (![item isKindOfClass:NSValue.class]) return nil;
        CGPoint p = [item CGPointValue];
        if (!HLXNormalizePoint(&p, window)) return nil;
        [out addObject:[NSValue valueWithCGPoint:p]];
    }
    return out;
}

@implementation HLXTouch

+ (NSDictionary *)status {
    __block NSDictionary *result;
    void (^read)(void) = ^{
        BOOL symbols = HLXSymbolsReady();
        UIApplication *app = UIApplication.sharedApplication;
        UIWindow *window = HLXActiveWindow();
        uint32_t contextID = HLXWindowContextID(window);
        BOOL enqueue = app && [app respondsToSelector:NSSelectorFromString(@"_enqueueHIDEvent:")] && contextID != 0 && pSetDigitizerInfo;
        BOOL fallback = HLXIsSpringBoard() && gClient && pClientDispatch;
        NSString *reason = @"";
        if (!symbols) reason = @"缺少 IOHID 事件创建/组合符号";
        else if (!enqueue && !fallback) reason = @"没有可用的 UIApplication HID 队列或 SpringBoard 系统客户端派发入口";
        result = @{
            @"available": @((symbols && (enqueue || fallback))),
            @"path": fallback ? @"IOHIDEventSystemClientDispatchEvent(SpringBoard)" : (enqueue ? @"UIApplication._enqueueHIDEvent" : @"none"),
            @"contextID": @(contextID),
            @"windowWidth": @(window ? window.bounds.size.width : 0),
            @"windowHeight": @(window ? window.bounds.size.height : 0),
            @"maxTouches": @(kHLXMaxTouches),
            @"activeTouches": @(gTouchCount),
            @"coordinateMode": @"UIKit points -> normalized HID 0..1",
            @"dispatchNote": @"available 仅表示符号和派发入口存在；API 为异步派发且没有系统接收回执，不能据此保证前台游戏已收到事件",
            @"reason": reason
        };
    };
    if (NSThread.isMainThread) read(); else dispatch_sync(dispatch_get_main_queue(), read);
    return result ?: @{@"available": @NO, @"path": @"none", @"contextID": @0, @"reason": @"无法读取 UIApplication 状态"};
}

+ (BOOL)available { return [self.status[@"available"] boolValue]; }

+ (BOOL)multiDown:(NSArray<NSValue *> *)points {
    return HLXOnMain(^BOOL{
        if (gTouchInProgress) return NO;
        NSArray<NSValue *> *valid = HLXValidatedPoints(points, HLXActiveWindow());
        if (!valid) return NO;
        gTouchGeneration++;
        memset(gTouches, 0, sizeof(gTouches));
        gTouchCount = valid.count;
        for (NSUInteger i = 0; i < gTouchCount; i++) {
            gTouches[i].point = [valid[i] CGPointValue];
            gTouches[i].active = YES;
        }
        gTouchInProgress = YES;
        if (!HLXEmit(YES, NO)) { memset(gTouches, 0, sizeof(gTouches)); gTouchCount = 0; gTouchInProgress = NO; return NO; }
        return YES;
    });
}

+ (BOOL)multiMove:(NSArray<NSValue *> *)points {
    return HLXOnMain(^BOOL{
        if (!gTouchInProgress || points.count != gTouchCount) return NO;
        NSArray<NSValue *> *valid = HLXValidatedPoints(points, HLXActiveWindow());
        if (!valid) return NO;
        for (NSUInteger i = 0; i < gTouchCount; i++) gTouches[i].point = [valid[i] CGPointValue];
        return HLXEmit(YES, YES);
    });
}

+ (BOOL)multiUp:(NSArray<NSValue *> *)points {
    return HLXOnMain(^BOOL{
        if (!gTouchInProgress) return NO;
        if (points && points.count == gTouchCount) {
            NSArray<NSValue *> *valid = HLXValidatedPoints(points, HLXActiveWindow());
            if (valid) for (NSUInteger i = 0; i < gTouchCount; i++) gTouches[i].point = [valid[i] CGPointValue];
        }
        BOOL ok = HLXEmit(NO, NO);
        gTouchGeneration++;
        memset(gTouches, 0, sizeof(gTouches));
        gTouchCount = 0;
        gTouchInProgress = NO;
        return ok;
    });
}

+ (void)cancelAll {
    HLXOnMain(^BOOL{
        if (gTouchInProgress) HLXEmit(NO, NO);
        gTouchGeneration++;
        memset(gTouches, 0, sizeof(gTouches));
        gTouchCount = 0;
        gTouchInProgress = NO;
        return YES;
    });
}

+ (BOOL)down:(CGPoint)p { return [self multiDown:@[[NSValue valueWithCGPoint:p]]]; }
+ (BOOL)move:(CGPoint)p { return [self multiMove:@[[NSValue valueWithCGPoint:p]]]; }
+ (BOOL)up:(CGPoint)p { return [self multiUp:@[[NSValue valueWithCGPoint:p]]]; }

+ (BOOL)tap:(CGPoint)p {
    if (![self down:p]) return NO;
    uint64_t generation = HLXReadGeneration();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 70 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        if (gTouchInProgress && gTouchGeneration == generation) [self up:p];
    });
    return YES;
}

+ (BOOL)multiTap:(NSArray<NSValue *> *)points holdMs:(int)ms {
    if (![self multiDown:points]) return NO;
    uint64_t generation = HLXReadGeneration();
    int duration = MAX(40, MIN(ms, 10000));
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)duration * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        if (gTouchInProgress && gTouchGeneration == generation) [self multiUp:points];
    });
    return YES;
}

+ (BOOL)longPress:(CGPoint)p ms:(int)ms {
    if (![self down:p]) return NO;
    uint64_t generation = HLXReadGeneration();
    int duration = MAX(100, MIN(ms, 10000));
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)duration * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        if (gTouchInProgress && gTouchGeneration == generation) [self up:p];
    });
    return YES;
}

+ (BOOL)swipe:(CGPoint)from to:(CGPoint)to ms:(int)ms {
    int duration = MAX(80, MIN(ms, 10000));
    if (![self down:from]) return NO;
    uint64_t generation = HLXReadGeneration();
    int steps = MAX(5, MIN(120, duration / 16));
    for (int i = 1; i <= steps; i++) {
        CGFloat fraction = (CGFloat)i / (CGFloat)steps;
        CGPoint point = CGPointMake(from.x + (to.x - from.x) * fraction,
                                    from.y + (to.y - from.y) * fraction);
        int64_t delay = (int64_t)duration * i / steps;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
            if (!gTouchInProgress || gTouchGeneration != generation) return;
            if (i == steps) [self up:point]; else [self move:point];
        });
    }
    return YES;
}
@end
