#!/usr/bin/env python3
from pathlib import Path
import hashlib
html = Path('Resources/ui.html').read_text()
bridge = Path('Sources/HLXBridge.m').read_text()
speed = Path('Sources/HLXSpeed.m').read_bytes()
assert 'ownBridge.setSpeed(safeMult)' in html
assert 'safeMult < 0.1 || safeMult > 10' in html
assert 'var mult = isPause ? 0.1' in html
assert "'最低速(0.1x)'" in html
assert 'clickerStage' not in html and 'clickerRenderStage' not in html
assert 'clickerPullNativePoints' in html and 'clickerRefreshPoints' in html
assert '在游戏画面中拖动圆点' in html
assert 'multiTap' in bridge and 'setSpeed' in bridge
assert len(speed) > 0
print('PASS: speed UI directly invokes Huluxia native setSpeed bridge')
print('PASS: UI multiplier is constrained to native 0.1x-10x range')
print('PASS: pause button no longer sends rejected 0.001x; reports 0.1x minimum')
print('PASS: clicker has no fake in-panel grid; it edits native overlay points on the game screen')
print('PASS: native multiTap and setSpeed bridge endpoints retained')
print('HLXSpeed.m SHA256:', hashlib.sha256(speed).hexdigest())
