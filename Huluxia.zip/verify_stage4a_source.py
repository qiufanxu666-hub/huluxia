#!/usr/bin/env python3
from pathlib import Path
import hashlib
root = Path(__file__).parent
overlay = (root / "Sources/HLXOverlay.m").read_text()
speed = (root / "Sources/HLXSpeed.m").read_bytes()
checks = {
    "SpringBoard UIWebView construction removed": "NSClassFromString(@\"UIWebView\")" not in overlay and "legacyWebView" not in overlay,
    "WKWebView path retained": "WKWebView *wk" in overlay and "engine = WKWebView" in overlay,
    "native fallback retained": "native fallback view installed" in overlay,
    "JavaScript calls are capability-checked": "if ([self.web respondsToSelector:selector])" in overlay,
    "SpringBoard Web Inspector disabled": "if (@available(iOS 16.4, *)) { if (!HLXIsSB()) wk.inspectable = YES; }" in overlay,
    "ball tap deferred off gesture callback": "dispatch_async(dispatch_get_main_queue(), ^{ [HLXOverlay.shared toggle]; });" in overlay,
    "speed implementation present": len(speed) > 1000,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()):
    raise SystemExit(1)
print("HLXSpeed.m SHA256:", hashlib.sha256(speed).hexdigest())
