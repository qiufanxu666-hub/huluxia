#import "HLXDrawOverlay.h"
#import <UIKit/UIKit.h>
#import <os/lock.h>

@interface HLXPassThroughView : UIView
@property(nonatomic,copy) NSArray *commands;
@end
@implementation HLXPassThroughView
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e { return nil; }
- (void)drawRect:(CGRect)rect {
 CGContextRef c=UIGraphicsGetCurrentContext(); if(!c)return;
 CGContextSetLineCap(c,kCGLineCapRound); CGContextSetLineJoin(c,kCGLineJoinRound);
 NSArray *items=self.commands ?: @[];
 for(NSDictionary *d in items){
  if(![d isKindOfClass:NSDictionary.class])continue;
  NSString *type=[d[@"type"] isKindOfClass:NSString.class]?d[@"type"]:@"";
  NSString *hex=[d[@"color"] isKindOfClass:NSString.class]?d[@"color"]:@"#FF3B30";
  UIColor *color=nil;
  if([hex hasPrefix:@"#"]){unsigned v=0;NSScanner *sc=[NSScanner scannerWithString:[hex substringFromIndex:1]];if([sc scanHexInt:&v]){if(hex.length==9)color=[UIColor colorWithRed:((v>>24)&255)/255.0 green:((v>>16)&255)/255.0 blue:((v>>8)&255)/255.0 alpha:(v&255)/255.0];else color=[UIColor colorWithRed:((v>>16)&255)/255.0 green:((v>>8)&255)/255.0 blue:(v&255)/255.0 alpha:1.0];}}
  if(!color)color=UIColor.redColor;
  CGFloat w=MAX(0.5,MIN(20,[d[@"width"] respondsToSelector:@selector(doubleValue)]?[d[@"width"] doubleValue]:2));
  CGContextSetStrokeColorWithColor(c,color.CGColor); CGContextSetFillColorWithColor(c,color.CGColor); CGContextSetLineWidth(c,w);
  if([type isEqualToString:@"line"]){CGPoint a=CGPointMake([d[@"x1"] doubleValue],[d[@"y1"] doubleValue]),b=CGPointMake([d[@"x2"] doubleValue],[d[@"y2"] doubleValue]);CGContextMoveToPoint(c,a.x,a.y);CGContextAddLineToPoint(c,b.x,b.y);CGContextStrokePath(c);}
  else if([type isEqualToString:@"rect"]){CGRect r=CGRectMake([d[@"x"] doubleValue],[d[@"y"] doubleValue],[d[@"w"] doubleValue],[d[@"h"] doubleValue]);if([d[@"fill"] boolValue])CGContextFillRect(c,r);else CGContextStrokeRect(c,r);}
  else if([type isEqualToString:@"circle"]){CGFloat x=[d[@"x"] doubleValue],y=[d[@"y"] doubleValue],r=MAX(0,[d[@"r"] doubleValue]);CGRect b=CGRectMake(x-r,y-r,2*r,2*r);if([d[@"fill"] boolValue])CGContextFillEllipseInRect(c,b);else CGContextStrokeEllipseInRect(c,b);}
  else if([type isEqualToString:@"text"]){NSString *s=[d[@"text"] isKindOfClass:NSString.class]?d[@"text"]:@"";CGFloat rawSize=[d[@"size"] doubleValue];CGFloat size=MAX(6,MIN(48,rawSize>0?rawSize:14));NSDictionary *a=@{NSFontAttributeName:[UIFont systemFontOfSize:size weight:UIFontWeightSemibold],NSForegroundColorAttributeName:color};[s drawAtPoint:CGPointMake([d[@"x"] doubleValue],[d[@"y"] doubleValue]) withAttributes:a];}
  else if([type isEqualToString:@"skeleton"]){NSArray *pts=[d[@"points"] isKindOfClass:NSArray.class]?d[@"points"]:@[];NSArray *bones=[d[@"bones"] isKindOfClass:NSArray.class]?d[@"bones"]:@[];for(NSArray *pair in bones){if(![pair isKindOfClass:NSArray.class]||pair.count<2)continue;NSInteger i=[pair[0] integerValue]-1,j=[pair[1] integerValue]-1;if(i<0||j<0||i>=pts.count||j>=pts.count)continue;NSDictionary *p=pts[i],*q=pts[j];CGContextMoveToPoint(c,[p[@"x"] doubleValue],[p[@"y"] doubleValue]);CGContextAddLineToPoint(c,[q[@"x"] doubleValue],[q[@"y"] doubleValue]);}CGContextStrokePath(c);}
 }
}
@end

@interface HLXDrawWindow : UIWindow @end
@implementation HLXDrawWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e { return nil; }
@end
static os_unfair_lock gDrawLock = OS_UNFAIR_LOCK_INIT;
static NSArray *gPendingDrawCommands;
static BOOL gDrawUpdateScheduled = NO;

@interface HLXDrawOverlay ()
+ (instancetype)shared;
- (void)ensure;
@property(nonatomic,strong) HLXDrawWindow *window;
@property(nonatomic,strong) HLXPassThroughView *canvas;
@end
@implementation HLXDrawOverlay
+ (instancetype)shared { static HLXDrawOverlay *o;static dispatch_once_t once;dispatch_once(&once,^{o=[HLXDrawOverlay new];});return o; }
- (void)ensure {
 if(self.window)return;
 UIWindowScene *scene=nil; if(@available(iOS 13.0,*)){for(UIScene *s in UIApplication.sharedApplication.connectedScenes)if([s isKindOfClass:UIWindowScene.class]&&s.activationState==UISceneActivationStateForegroundActive){scene=(UIWindowScene*)s;break;}}
 self.window=scene?[[HLXDrawWindow alloc]initWithWindowScene:scene]:[[HLXDrawWindow alloc]initWithFrame:UIScreen.mainScreen.bounds];
 self.window.frame=UIScreen.mainScreen.bounds;self.window.windowLevel=UIWindowLevelAlert+1;self.window.backgroundColor=UIColor.clearColor;self.window.opaque=NO;
 UIViewController *vc=[UIViewController new];vc.view.backgroundColor=UIColor.clearColor;vc.view.userInteractionEnabled=NO;self.window.rootViewController=vc;
 self.canvas=[[HLXPassThroughView alloc]initWithFrame:self.window.bounds];self.canvas.backgroundColor=UIColor.clearColor;self.canvas.opaque=NO;self.canvas.userInteractionEnabled=NO;self.canvas.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;[vc.view addSubview:self.canvas];self.window.hidden=NO;
 }
+ (void)setCommands:(NSArray*)commands {
 NSArray *safe=[commands isKindOfClass:NSArray.class]?commands:@[];
 if(safe.count>2000)safe=[safe subarrayWithRange:NSMakeRange(0,2000)];
 os_unfair_lock_lock(&gDrawLock);gPendingDrawCommands=[safe copy];BOOL schedule=!gDrawUpdateScheduled;if(schedule)gDrawUpdateScheduled=YES;os_unfair_lock_unlock(&gDrawLock);
 if(!schedule)return;
 dispatch_async(dispatch_get_main_queue(),^{
  os_unfair_lock_lock(&gDrawLock);NSArray *latest=gPendingDrawCommands?:@[];gPendingDrawCommands=nil;gDrawUpdateScheduled=NO;os_unfair_lock_unlock(&gDrawLock);
  HLXDrawOverlay *o=[self shared];[o ensure];o.canvas.commands=latest;[o.canvas setNeedsDisplay];o.window.hidden=(latest.count==0);
 });
}
+ (void)clear { [self setCommands:@[]]; }
@end
