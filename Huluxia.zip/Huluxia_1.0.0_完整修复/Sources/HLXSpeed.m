#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <os/lock.h>
#import <mach/mach_time.h>
#import <time.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach/mach.h>
#import <math.h>
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono;                // mach ticks / CLOCK_MONOTONIC ns；墙上时钟不缩放

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

// 计算必须在 gLock 内调用。使用 long double 避免长时间运行时 double 丢失低位精度；
// real 回退时保持虚拟时钟不倒退，倍率切换时不会突然跳回真实时间。
static inline uint64_t HLXScaleLocked(const HLXBase *b, uint64_t real) {
    if (real <= b->realBase) return b->virtBase;
    long double delta = (long double)(real - b->realBase) * (long double)gSpeed;
    long double value = (long double)b->virtBase + delta;
    if (!isfinite((double)value) || value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    os_unfair_lock_lock(&gLock);
    uint64_t value = HLXScaleLocked(b, real);
    os_unfair_lock_unlock(&gLock);
    return value;
}

static uint64_t h_mach_absolute_time(void) {
    return scale(&gMach, o_mach_absolute_time());
}

// 只缩放 CLOCK_MONOTONIC。RAW / UPTIME 与 MONOTONIC 的基准语义不同，不能共用 gMono。
static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts || c != CLOCK_MONOTONIC) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    ns = scale(&gMono, ns);
    ts->tv_sec = (time_t)(ns / 1000000000ULL);
    ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    return c == CLOCK_MONOTONIC ? scale(&gMono, ns) : ns;
}

// 在一个临界区内推进两个时间域的基准，再切换倍率，避免 10x -> 1x 时基准撕裂。
static BOOL rebase(double newSpeed) {
    if (!o_mach_absolute_time || !o_clock_gettime) return NO;
    // 串行化“采样 + 推进基准 + 切换倍率”整个过程，防止两个快速连发的倍率请求
    // 先后用旧采样覆盖新基准，造成虚拟时间回退。
    os_unfair_lock_lock(&gLock);
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts = {0};
    if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        os_unfair_lock_unlock(&gLock);
        return NO;
    }
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    uint64_t vm = HLXScaleLocked(&gMach, rm);
    uint64_t vn = HLXScaleLocked(&gMono, rn);
    gMach.realBase = rm;
    gMach.virtBase = vm;
    gMono.realBase = rn;
    gMono.virtBase = vn;
    gSpeed = newSpeed;
    os_unfair_lock_unlock(&gLock);
    return YES;
}


// ───────── 无 Substrate 时的后备方案：改写各镜像的符号指针表（fishhook 原理，免越狱可用）─────────
#if defined(__arm64__) && !__has_feature(ptrauth_calls)
static const char *kNames[3] = { "mach_absolute_time", "clock_gettime", "clock_gettime_nsec_np" };
static void *kRepl[3];
static uint64_t gReboundCount = 0;

static void rebind_image(const struct mach_header *mh, intptr_t slide) {
    const struct mach_header_64 *h = (const struct mach_header_64 *)mh;
    const struct segment_command_64 *linkedit = NULL;
    const struct symtab_command *symtab = NULL;
    const struct dysymtab_command *dysymtab = NULL;
    const uint8_t *cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmd == LC_SEGMENT_64) { const struct segment_command_64 *sg = (const void *)cur; if (!strcmp(sg->segname, "__LINKEDIT")) linkedit = sg; }
        else if (lc->cmd == LC_SYMTAB) symtab = (const void *)cur;
        else if (lc->cmd == LC_DYSYMTAB) dysymtab = (const void *)cur;
    }
    if (!linkedit || !symtab || !dysymtab) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const void *)(base + symtab->symoff);
    const char *strtab = (const char *)(base + symtab->stroff);
    const uint32_t *indirect = (const void *)(base + dysymtab->indirectsymoff);

    cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        if (((const struct load_command *)cur)->cmd != LC_SEGMENT_64) continue;
        const struct segment_command_64 *sg = (const void *)cur;
        if (strcmp(sg->segname, "__DATA") && strcmp(sg->segname, "__DATA_CONST")) continue;
        const struct section_64 *sec = (const void *)(sg + 1);
        for (uint32_t j = 0; j < sg->nsects; j++, sec++) {
            uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            const uint32_t *ind = indirect + sec->reserved1;
            void **ptrs = (void **)((uintptr_t)slide + sec->addr);
            for (uint64_t k = 0; k < sec->size / sizeof(void *); k++) {
                uint32_t si = ind[k];
                if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL || si == (INDIRECT_SYMBOL_LOCAL | INDIRECT_SYMBOL_ABS)) continue;
                const char *nm = strtab + syms[si].n_un.n_strx;
                if (nm[0] != '_') continue;
                for (int n = 0; n < 3; n++) {
                    if (kRepl[n] && !strcmp(nm + 1, kNames[n])) {
                        mach_vm_protect(mach_task_self(), (mach_vm_address_t)&ptrs[k], sizeof(void *), FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                        ptrs[k] = kRepl[n];
                        __sync_fetch_and_add(&gReboundCount, 1);
                    }
                }
            }
        }
    }
}
static BOOL rebindAll(void) {
    kRepl[0] = (void *)h_mach_absolute_time;
    kRepl[1] = (void *)h_clock_gettime;
    kRepl[2] = o_clock_gettime_nsec_np ? (void *)h_clock_gettime_nsec_np : NULL;
    _dyld_register_func_for_add_image(rebind_image);        // 已加载的和以后加载的镜像都会处理
    return gReboundCount > 0;
}
#else
static BOOL rebindAll(void) { return NO; }
#endif

static BOOL install(NSString **err) {
    if (gInstalled) return YES;
    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg) { if (err) *err = @"mach_absolute_time / clock_gettime 符号解析失败"; return NO; }

    // 基准先用“真实=虚拟”初始化；检查 MONOTONIC 读取成功后才安装 hook。
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts = {0};
    if (((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts) != 0) {
        if (err) *err = @"CLOCK_MONOTONIC 初始化失败";
        return NO;
    }
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    gMach = (HLXBase){ m, m };
    gMono = (HLXBase){ n, n };

    if (hook) {
        hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
        hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
        if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
    } else {
        // 无 Substrate/ElleKit 时使用符号指针表重绑定；不改写 gettimeofday / 墙上时钟。
        o_mach_absolute_time = sym_mat;
        o_clock_gettime = sym_cg;
        o_clock_gettime_nsec_np = sym_cgn;
        if (!rebindAll()) { if (err) *err = @"此环境没有 Substrate，且当前架构不支持安全的符号表改写，无法变速"; return NO; }
    }
    gInstalled = YES;
    return YES;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current {
    os_unfair_lock_lock(&gLock);
    double value = gSpeed;
    os_unfair_lock_unlock(&gLock);
    return value;
}

+ (uint64_t)realMachAbsoluteTime {
    // o_mach_absolute_time 是 MSHookFunction 返回的原函数 trampoline，或侧载重绑定前的真实符号。
    uint64_t (*realFn)(void) = o_mach_absolute_time;
    return realFn ? realFn() : mach_absolute_time();
}

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0 || mult > 100) { if (err) *err = @"无效的变速倍率（支持 0x～100x）"; return NO; }
    if (!install(err)) return NO;
    if (!rebase(mult)) { if (err) *err = @"读取系统单调时钟失败，倍率未更新"; return NO; }
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!install(&err)) return;                    // 没有 hook 框架就什么都不做
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (isfinite(m) && m >= 0 && m <= 100) rebase(m);
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0 || mult > 100) { if (err) *err = @"无效的变速倍率（支持 0x～100x）"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Huluxia 代理：把目标 App 的 Bundle ID 加进 Huluxia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
