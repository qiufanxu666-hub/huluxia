#import "HLXTouch.h"
#import "HLXSpeed.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <mach/mach_time.h>
#import <objc/message.h>

typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDEventSystemClient *IOHIDEventSystemClientRef;
static IOHIDEventRef (*pCreateDigitizer)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
static IOHIDEventRef (*pCreateFinger)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
static void (*pAppend)(IOHIDEventRef,IOHIDEventRef,uint32_t);
static void (*pSetInt)(IOHIDEventRef,uint32_t,int64_t);
static void (*pSetFloat)(IOHIDEventRef,uint32_t,double);
static void (*pSetSender)(IOHIDEventRef,uint64_t);
static IOHIDEventSystemClientRef (*pClientCreate)(CFAllocatorRef);
static void (*pClientDispatch)(IOHIDEventSystemClientRef,IOHIDEventRef);
static IOHIDEventSystemClientRef gClient;
static dispatch_once_t gOnce;
#define kFieldBuiltIn 0x00000004u
#define kFieldDisplay 0x000B0019u
#define kFieldMajor 0x000B0014u
#define kFieldMinor 0x000B0015u
#define kRange (1u<<0)
#define kTouch (1u<<1)
#define kPosition (1u<<2)
static void HLXLoad(void) {
 dispatch_once(&gOnce, ^{
  void *h=dlopen("/System/Library/Frameworks/IOKit.framework/IOKit",RTLD_NOW);
  if(!h) return;
  pCreateDigitizer=dlsym(h,"IOHIDEventCreateDigitizerEvent");
  pCreateFinger=dlsym(h,"IOHIDEventCreateDigitizerFingerEvent");
  pAppend=dlsym(h,"IOHIDEventAppendEvent"); pSetInt=dlsym(h,"IOHIDEventSetIntegerValue");
  pSetFloat=dlsym(h,"IOHIDEventSetFloatValue"); pSetSender=dlsym(h,"IOHIDEventSetSenderID");
  pClientCreate=dlsym(h,"IOHIDEventSystemClientCreate");
  pClientDispatch=dlsym(h,"IOHIDEventSystemClientDispatchEvent");
  if(pClientCreate) gClient=pClientCreate(kCFAllocatorDefault);
 });
}
static BOOL HLXIsSpringBoard(void){return [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"];}
static NSInteger HLXOrientation(void) {
 __block NSInteger o=1; void(^b)(void)=^{
  UIApplication *app=UIApplication.sharedApplication;
  if([app respondsToSelector:NSSelectorFromString(@"activeInterfaceOrientation")]) o=((NSInteger(*)(id,SEL))objc_msgSend)(app,NSSelectorFromString(@"activeInterfaceOrientation"));
  else for(UIScene *s in app.connectedScenes) if([s isKindOfClass:UIWindowScene.class]){o=((UIWindowScene*)s).interfaceOrientation;break;}
  if(o<1||o>4)o=1;
 };
 if(NSThread.isMainThread)b();else dispatch_sync(dispatch_get_main_queue(),b);
 return o;
}
static CGPoint HLXNormalize(CGPoint p){
 __block CGSize z=CGSizeMake(390,844); void(^b)(void)=^{z=UIScreen.mainScreen.fixedCoordinateSpace.bounds.size;};
 if(NSThread.isMainThread)b();else dispatch_sync(dispatch_get_main_queue(),b);
 CGFloat W=z.width,H=z.height;
 switch(HLXOrientation()){case 2:return CGPointMake(1-p.x/W,1-p.y/H);case 3:return CGPointMake(p.y/W,1-p.x/H);case 4:return CGPointMake(1-p.y/W,p.x/H);default:return CGPointMake(p.x/W,p.y/H);}
}
static BOOL HLXCanDispatch(void){
 HLXLoad(); if(!pCreateDigitizer||!pCreateFinger||!pAppend)return NO;
 if(HLXIsSpringBoard())return gClient&&pClientDispatch;
 __block BOOL supported=NO;
 void(^check)(void)=^{
  UIApplication *app=UIApplication.sharedApplication;
  supported=[app respondsToSelector:NSSelectorFromString(@"_enqueueHIDEvent:")]||[app respondsToSelector:NSSelectorFromString(@"_handleHIDEvent:")]||(gClient&&pClientDispatch);
 };
 if(NSThread.isMainThread)check();else dispatch_sync(dispatch_get_main_queue(),check);
 return supported;
}
static BOOL HLXSendNow(CGPoint p,uint32_t mask,BOOL touching){
 if(!HLXCanDispatch())return NO;
 CGPoint n=HLXNormalize(p); uint64_t t=[HLXSpeed realMachAbsoluteTime];
 IOHIDEventRef parent=pCreateDigitizer(kCFAllocatorDefault,t,3,0,0,mask,0,0,0,0,0,0,touching,touching,0);
 if(!parent)return NO;
 if(pSetInt){pSetInt(parent,kFieldBuiltIn,1);pSetInt(parent,kFieldDisplay,1);}
 IOHIDEventRef child=pCreateFinger(kCFAllocatorDefault,t,1,2,mask,n.x,n.y,0,touching?0.5:0,0,touching,touching,0);
 if(child){if(pSetFloat){pSetFloat(child,kFieldMajor,0.04);pSetFloat(child,kFieldMinor,0.04);}pAppend(parent,child,0);CFRelease(child);}
 if(pSetSender)pSetSender(parent,0xDEFACEDBEEFFECE5ULL);
 if(HLXIsSpringBoard())pClientDispatch(gClient,parent);
 else {UIApplication *app=UIApplication.sharedApplication;SEL a=NSSelectorFromString(@"_enqueueHIDEvent:"),b=NSSelectorFromString(@"_handleHIDEvent:");if([app respondsToSelector:a])((void(*)(id,SEL,void*))objc_msgSend)(app,a,parent);else if([app respondsToSelector:b])((void(*)(id,SEL,void*))objc_msgSend)(app,b,parent);else pClientDispatch(gClient,parent);}
 CFRelease(parent); return YES;
}
static BOOL HLXSend(CGPoint p,uint32_t mask,BOOL touching){
 if(!HLXCanDispatch())return NO;
 if(NSThread.isMainThread)return HLXSendNow(p,mask,touching);
 dispatch_async(dispatch_get_main_queue(),^{HLXSendNow(p,mask,touching);});
 return YES; // 已排队；系统/目标 App 是否接受无法从私有 API 得到确认
}
@implementation HLXTouch
+ (BOOL)available{return HLXCanDispatch();}
+ (BOOL)down:(CGPoint)p{return HLXSend(p,kRange|kTouch,YES);}
+ (BOOL)move:(CGPoint)p{return HLXSend(p,kPosition|kRange|kTouch,YES);}
+ (BOOL)up:(CGPoint)p{return HLXSend(p,kRange|kTouch,NO);}
+ (BOOL)tap:(CGPoint)p{if(![self down:p])return NO;dispatch_after(dispatch_time(DISPATCH_TIME_NOW,50*NSEC_PER_MSEC),dispatch_get_main_queue(),^{HLXSendNow(p,kRange|kTouch,NO);});return YES;}
+ (BOOL)longPress:(CGPoint)p ms:(int)ms{if(![self down:p])return NO;int d=MAX(50,MIN(ms,10000));dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)d*NSEC_PER_MSEC),dispatch_get_main_queue(),^{HLXSendNow(p,kRange|kTouch,NO);});return YES;}
+ (BOOL)swipe:(CGPoint)a to:(CGPoint)b ms:(int)ms{
 if(!HLXCanDispatch())return NO;int d=MAX(50,MIN(ms,10000));int steps=MAX(4,MIN(120,d/16));
 if(![self down:a])return NO;
 for(int i=1;i<=steps;i++){CGFloat k=(CGFloat)i/steps;CGPoint p=CGPointMake(a.x+(b.x-a.x)*k,a.y+(b.y-a.y)*k);dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(d*i/steps)*NSEC_PER_MSEC),dispatch_get_main_queue(),^{HLXSendNow(p,i==steps?(kRange|kTouch):(kPosition|kRange|kTouch),i!=steps);});}
 return YES;
}
@end
