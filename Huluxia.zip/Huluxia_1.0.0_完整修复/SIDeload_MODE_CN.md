# 轻松签侧载注入模式

## 本次修复

之前 `Sources/Tweak.m` 对普通目标 App 只调用 `HLXSpeed startAgent`，没有调用 `HLXOverlay showBall`，因此即使 dylib 已经被游戏进程加载，也不会出现悬浮球。

现在普通目标 App 的入口会：

1. 启动原有变速代理；
2. 监听 `UIApplicationDidFinishLaunchingNotification` 和 `UIApplicationDidBecomeActiveNotification`；
3. 等待主线程、UIApplication Active 状态以及 iOS 13+ 前台 UIWindowScene 就绪；
4. 在游戏 App 自己的进程内创建悬浮球；
5. 用一次性状态防止通知重复创建多个悬浮球。

SpringBoard 和 `com.huluxia.launcher` 的既有分支保持独立，不会因为游戏侧载模式而改变。

## 轻松签使用

将构建产物 `Huluxia.dylib` 注入目标游戏 IPA 的主 App 可执行文件，确保注入器将 dylib 放入 App 包内并写入有效的 `LC_LOAD_DYLIB` 加载命令，然后用同一签名身份重新签名整个 App，再安装。

`Huluxia.plist` 是 Theos/ElleKit 类 tweak filter，不负责静态 IPA 注入器的 load-command 注入。若使用的是直接注入 dylib 的方式，是否加载以 Mach-O load command 和签名结果为准。

## 排查

如果仍无悬浮球，先确认：
- 目标 IPA 的主可执行文件确实包含 `@executable_path/Frameworks/Huluxia.dylib`（或注入器实际使用的 install name）对应的 `LC_LOAD_DYLIB`；
- dylib 与游戏可执行文件均包含设备支持的 arm64 架构；
- 重新签名时 dylib 也被签名，且没有漏签 Frameworks 子目录；
- 注入器没有只把 dylib 复制进 IPA、却没有添加 load command。

本源码环境未提供 iOS SDK/Xcode 和设备，因此本次只能完成源码及静态检查，不能声称已在轻松签实机验证。
