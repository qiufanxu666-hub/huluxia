#!/usr/bin/env python3
from pathlib import Path
import plistlib
root = Path(__file__).resolve().parent
mem = (root / 'Sources/HLXMemory.m').read_text()
ui = (root / 'Resources/ui.html').read_text()
ipa_script = (root / 'build_trollstore_ipa.sh').read_text()
workflow = (root / '.github/workflows/build.yml').read_text()
checks = {
    'UIKit icon extraction is linked': '#import <UIKit/UIKit.h>' in mem and 'HLXAppIconDataURI' in mem,
    'LaunchServices icon data lookup for sandboxed apps': 'LSApplicationProxy' in mem and 'iconDataForVariant:' in mem,
    'bundle asset catalog icon lookup fallback': 'imageNamed:iconName inBundle:appBundle compatibleWithTraitCollection:nil' in mem,
    'legacy icon file fallback': 'imageWithContentsOfFile:full' in mem,
    'process entries carry icon data URI': '@"icon": icon ?: @""' in mem,
    'UI process-list mapping preserves native icon data': "icon: (typeof p.icon === 'string') ? p.icon : ''" in ui,
    'UI renders actual image data': "p.icon.indexOf('data:image/png;base64,') === 0" in ui and "'<img src=\"' + appIcon" in ui,
    'letter placeholder removed': "escapeHtml(initial)" not in ui,
    'TrollStore runtime identified by app container': 'HLXIsTrollStoreLauncherRuntime' in mem and '/var/containers/Bundle/Application/' in mem,
    'TrollStore picker uses install-container path rather than bundle-name heuristics': 'Do not reject com.apple.* solely by bundle ID' in mem,
    'TrollStore picker restricts app container paths': 'HLXIsUserInstalledAppPath(p, bundle)' in mem,
    'TrollStore direct task_for_pid attempt': 'taskForPID(mach_task_self(), (int)pid, &candidate)' in mem,
    'TrollStore permission failure is explicit': 'task_for_pid-allow 仍需由设备内核实际接受' in mem,
    'IPA signing uses explicit entitlement plist': '--entitlements "$ENTITLEMENTS"' in ipa_script,
    'IPA script verifies requested entitlement': "grep -q 'task_for_pid-allow'" in ipa_script,
    'workflow includes Stage 5V verifier': 'verify_stage5v_features.py' in workflow,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
with (root / 'Launcher/Resources/entitlements.plist').open('rb') as f:
    ent = plistlib.load(f)
assert ent.get('task_for_pid-allow') is True
print('PASS: TrollStore launcher entitlement plist parses')
