#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys
root = Path(__file__).resolve().parent
src = (root / "Sources/HLXOverlay.m").read_text()
speed = root / "Sources/HLXSpeed.m"
checks = {
    "restore flag declared": "BOOL _restoreBallAfterPanel;" in src,
    "ball hidden only when panel transitions from hidden": "BOOL shouldRestoreBall = panelWasHidden && self->_ball && !self->_ball.hidden;" in src and "if (shouldRestoreBall)" in src,
    "ball visibility remembered before hiding": "self->_restoreBallAfterPanel = YES;" in src and "self->_ball.hidden = YES;" in src,
    "ball restored when panel closes": "if (self->_restoreBallAfterPanel)" in src and "self->_ball.hidden = NO;" in src,
    "restore flag cleared after close": "self->_restoreBallAfterPanel = NO;" in src,
    "panel initialization failure does not proceed": "show aborted: panel initialization failed" in src,
}
for label, ok in checks.items(): print(("PASS" if ok else "FAIL") + ": " + label)
expected = "65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911"
actual = hashlib.sha256(speed.read_bytes()).hexdigest()
print("HLXSpeed.m SHA256:", actual)
checks["Stage 1 speed baseline preserved exactly"] = actual == expected
print(("PASS" if actual == expected else "FAIL") + ": Stage 1 speed baseline preserved exactly")
sys.exit(0 if all(checks.values()) else 1)
