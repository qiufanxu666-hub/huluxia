#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parent
daemon = (root / "Daemon/Makefile").read_text()
launcher = (root / "Launcher/Makefile").read_text()
root_make = (root / "Makefile").read_text()
workflow = (root / ".github/workflows/build.yml").read_text()

common = "include $(THEOS)/makefiles/common.mk"
tool_rules = "include $(THEOS_MAKE_PATH)/tool.mk"
checks = {
    "Daemon loads common.mk before declaring and loading tool rules": (
        common in daemon and tool_rules in daemon
        and daemon.index(common) < daemon.index("TOOL_NAME") < daemon.index(tool_rules)
    ),
    "Launcher and Daemon both initialize Theos common variables": all(
        common in text for text in (launcher, daemon)
    ),
    "root project still aggregates Launcher and Daemon": "SUBPROJECTS += Launcher Daemon" in root_make,
    "workflow runs the guard before the first package clean/build": (
        "python3 verify_stage5w_buildfix.py" in workflow
        and workflow.index("python3 verify_stage5w_buildfix.py") < workflow.index("- name: Build legacy iOS 8-10 DEB")
        and workflow.index("python3 verify_stage5w_buildfix.py") < workflow.index("make clean")
    ),
    "workflow prioritizes Stage 5W archive": (
        "Huluxia_1.0.0_阶段5W_Daemon清理阶段Theos变量修复.zip" in workflow
    ),
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)
