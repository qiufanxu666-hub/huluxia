#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
src=(root/'Sources/HLXOverlay.m').read_text()
start=src.index('- (void)show {', src.index('@implementation HLXOverlay'))
end=src.index('\n- (void)hide {', start)
method=src[start:end]
checks={
 'ball visibility captured before ensure': method.index('BOOL shouldRestoreBall') < method.index('[self ensure];'),
 'ball hidden before ensure': method.index('self->_ball.hidden = YES;') < method.index('[self ensure];'),
 'panel init checked after ensure': method.index('[self ensure];') < method.index('if (!self->_window || !self->_vc)'),
 'failed initialization restores ball': method.index('show aborted: panel initialization failed') < method.index('self->_ball.hidden = NO;'),
 'restore flag cleared on rollback': 'self->_restoreBallAfterPanel = NO;' in method,
 'window shown only after successful init': method.index('if (!self->_window || !self->_vc)') < method.index('self->_window.hidden = NO;'),
}
for label, ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
h=hashlib.sha256((root/'Sources/HLXSpeed.m').read_bytes().replace(b'100.0', b'10.0').replace(b'100x', b'10x')).hexdigest()
expected='5a53100c841f15929d485883623734e3ca74525dc567dbe25627dee8cd9e08c3'
print('HLXSpeed.m SHA256:',h)
checks['stage 1 speed algorithm unchanged except 100x limit']=h==expected
print(('PASS: ' if checks['stage 1 speed algorithm unchanged except 100x limit'] else 'FAIL: ')+'stage 1 speed algorithm unchanged except 100x limit')
sys.exit(0 if all(checks.values()) else 1)
