#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
src=(root/'Sources/HLXOverlay.m').read_text()
start=src.index('- (void)show {', src.index('@implementation HLXOverlay'))
end=src.index('\n- (void)hide {', start)
method=src[start:end]
checks={
 'ball visibility captured before ensure': method.index('BOOL shouldRestoreBall') < method.index('[self ensure];'),
 'ball hidden before ensure': method.index('self->_ball.hidden = YES;') < method.index('[self ensure];'),
 'panel init checked after ensure': method.index('[self ensure];') < method.index('if (!self->_window || !self->_vc)'),
 'failed initialization restores ball': method.index('show aborted: panel initialization failed') < method.index('self->_ball.hidden = NO;'),
 'restore flag cleared on rollback': 'self->_restoreBallAfterPanel = NO;' in method,
 'window shown only after successful init': method.index('if (!self->_window || !self->_vc)') < method.index('self->_window.hidden = NO;'),
}
for label, ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
h=hashlib.sha256((root/'Sources/HLXSpeed.m').read_bytes()).hexdigest()
expected='65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911'
print('HLXSpeed.m SHA256:',h)
checks['stage 1 speed baseline unchanged']=h==expected
print(('PASS: ' if checks['stage 1 speed baseline unchanged'] else 'FAIL: ')+'stage 1 speed baseline unchanged')
sys.exit(0 if all(checks.values()) else 1)
