#import "HLXTouchPoints.h"
#import "HLXTouch.h"
#import <UIKit/UIKit.h>
#import <math.h>

@class HLXTouchPointController;

@interface HLXTouchPointHandle : UIView
@property(nonatomic,assign) NSUInteger pointIndex;
@property(nonatomic,weak) HLXTouchPointController *owner;
@end

@interface HLXTouchPointWindow : UIWindow @end
@implementation HLXTouchPointWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    if (hit == self || hit == self.rootViewController.view) return nil;
    return hit;
}
@end

@interface HLXTouchPointController : UIViewController
@property(nonatomic,strong) NSMutableArray<NSValue *> *locations;
@property(nonatomic,strong) NSMutableArray<HLXTouchPointHandle *> *handles;
@property(nonatomic,strong) HLXTouchPointWindow *overlayWindow;
@property(nonatomic,assign) NSInteger mode; // 0=edit, 1=run(click), 2=swipe
@property(nonatomic,assign) BOOL swipeActive;
- (void)moveHandle:(HLXTouchPointHandle *)handle to:(CGPoint)point;
- (void)handlePan:(HLXTouchPointHandle *)handle gesture:(UIPanGestureRecognizer *)gesture;
- (void)tapHandle:(HLXTouchPointHandle *)handle;
- (void)render;
@end

@implementation HLXTouchPointHandle
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor colorWithRed:0.08 green:0.48 blue:1 alpha:0.88];
        self.layer.cornerRadius = 22;
        self.layer.borderWidth = 2;
        self.layer.borderColor = UIColor.whiteColor.CGColor;
        self.layer.shadowColor = UIColor.blackColor.CGColor;
        self.layer.shadowOpacity = 0.55;
        self.layer.shadowRadius = 5;
        self.layer.shadowOffset = CGSizeMake(0, 2);
        self.userInteractionEnabled = YES;
        UILabel *label = [[UILabel alloc] initWithFrame:self.bounds];
        label.tag = 71001; label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        label.textAlignment = NSTextAlignmentCenter; label.textColor = UIColor.whiteColor;
        label.font = [UIFont boldSystemFontOfSize:15]; label.userInteractionEnabled = NO;
        [self addSubview:label];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
        pan.maximumNumberOfTouches = 1;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTap:)];
        [tap requireGestureRecognizerToFail:pan];
        [self addGestureRecognizer:pan]; [self addGestureRecognizer:tap];
    }
    return self;
}
- (void)setPointIndex:(NSUInteger)pointIndex {
    _pointIndex = pointIndex;
    UILabel *label = [self viewWithTag:71001]; label.text = [NSString stringWithFormat:@"%lu", (unsigned long)(pointIndex + 1)];
}
- (void)onPan:(UIPanGestureRecognizer *)gesture { [self.owner handlePan:self gesture:gesture]; }
- (void)onTap:(UITapGestureRecognizer *)gesture { [self.owner tapHandle:self]; }
@end

@implementation HLXTouchPointController
- (BOOL)prefersStatusBarHidden { return YES; }
- (void)loadView {
    UIView *v = [[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    v.backgroundColor = UIColor.clearColor; v.opaque = NO; v.userInteractionEnabled = YES;
    self.view = v;
}
- (void)render {
    if (!self.isViewLoaded) (void)self.view;
    while (self.handles.count > self.locations.count) { [self.handles.lastObject removeFromSuperview]; [self.handles removeLastObject]; }
    while (self.handles.count < self.locations.count) {
        HLXTouchPointHandle *h = [[HLXTouchPointHandle alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
        h.owner = self; [self.view addSubview:h]; [self.handles addObject:h];
    }
    for (NSUInteger i = 0; i < self.locations.count; i++) {
        HLXTouchPointHandle *h = self.handles[i]; h.pointIndex = i;
        h.center = [self.locations[i] CGPointValue];
    }
}
- (void)moveHandle:(HLXTouchPointHandle *)handle to:(CGPoint)point {
    if (handle.pointIndex >= self.locations.count) return;
    CGSize size = self.view.bounds.size;
    point.x = MAX(22, MIN(point.x, size.width - 22));
    point.y = MAX(22, MIN(point.y, size.height - 22));
    handle.center = point;
    self.locations[handle.pointIndex] = [NSValue valueWithCGPoint:point];
}
- (void)handlePan:(HLXTouchPointHandle *)handle gesture:(UIPanGestureRecognizer *)gesture {
    if (handle.pointIndex >= self.locations.count) return;
    CGPoint p = [gesture locationInView:self.view];
    if (gesture.state == UIGestureRecognizerStateBegan) {
        self.swipeActive = (self.mode == 2);
        if (self.swipeActive) self.swipeActive = [HLXTouch down:[self.locations[handle.pointIndex] CGPointValue]];
    }
    [self moveHandle:handle to:p];
    if (self.swipeActive && gesture.state == UIGestureRecognizerStateChanged) [HLXTouch move:p];
    if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled || gesture.state == UIGestureRecognizerStateFailed) {
        if (self.swipeActive) {
            if (gesture.state == UIGestureRecognizerStateEnded) [HLXTouch up:p];
            else [HLXTouch cancelAll];
        }
        self.swipeActive = NO;
    }
}
- (void)tapHandle:(HLXTouchPointHandle *)handle {
    if ((self.mode != 1 && self.mode != 3) || handle.pointIndex >= self.locations.count) return;
    CGPoint p = [self.locations[handle.pointIndex] CGPointValue];
    if (self.mode == 3) [HLXTouch longPress:p ms:1000];
    else [HLXTouch tap:p];
}
@end

@interface HLXTouchPoints ()
@property(nonatomic,strong) HLXTouchPointController *controller;
+ (void)ensureController;
@end

@implementation HLXTouchPoints
+ (instancetype)shared {
    static HLXTouchPoints *manager; static dispatch_once_t once;
    dispatch_once(&once, ^{ manager = [HLXTouchPoints new]; });
    return manager;
}
+ (void)ensureController {
    HLXTouchPoints *manager = [self shared];
    if (manager.controller) return;
    HLXTouchPointController *vc = [HLXTouchPointController new];
    vc.locations = [NSMutableArray array]; vc.handles = [NSMutableArray array];
    HLXTouchPointWindow *window = nil;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = nil;
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
            if (![s isKindOfClass:UIWindowScene.class]) continue;
            UIWindowScene *candidate = (UIWindowScene *)s;
            if (candidate.activationState != UISceneActivationStateForegroundActive) continue;
            for (UIWindow *candidateWindow in candidate.windows) {
                if (candidateWindow.isKeyWindow && !candidateWindow.hidden) { scene = candidate; break; }
            }
            if (scene) break;
            if (!scene) scene = candidate;
        }
            if (scene) window = [[HLXTouchPointWindow alloc] initWithWindowScene:scene];
    }
#endif
    if (!window) window = [[HLXTouchPointWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        if (window.windowScene) window.frame = window.windowScene.coordinateSpace.bounds;
        else window.frame = UIScreen.mainScreen.bounds;
    } else
#endif
    { window.frame = UIScreen.mainScreen.bounds; }
    window.windowLevel = UIWindowLevelAlert - 1.0;
    window.backgroundColor = UIColor.clearColor; window.opaque = NO;
    window.rootViewController = vc; window.hidden = YES;
    manager.controller = vc; vc.overlayWindow = window;
}
+ (void)setPoints:(NSArray<NSValue *> *)points {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self ensureController]; HLXTouchPoints *m = [self shared];
        NSMutableArray *safe = [NSMutableArray array];
        for (id item in points) {
            if (safe.count >= 5) break;
            if (![item isKindOfClass:NSValue.class]) continue;
            CGPoint p = [item CGPointValue];
            if (!isfinite(p.x) || !isfinite(p.y) || p.x < 0 || p.y < 0) continue;
            CGSize size = m.controller.view.bounds.size;
            p.x = MIN(p.x, size.width); p.y = MIN(p.y, size.height);
            [safe addObject:[NSValue valueWithCGPoint:p]];
        }
        m.controller.locations = safe;
        [m.controller render];
        m.controller.overlayWindow.hidden = (safe.count == 0);
    });
}
+ (NSArray<NSValue *> *)points {
    __block NSArray *result = @[];
    void (^read)(void) = ^{ result = [[self shared].controller.locations copy] ?: @[]; };
    if (NSThread.isMainThread) read(); else dispatch_sync(dispatch_get_main_queue(), read);
    return result;
}
+ (void)setVisible:(BOOL)visible {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self ensureController]; HLXTouchPoints *m = [self shared];
        m.controller.overlayWindow.hidden = !visible || m.controller.locations.count == 0;
    });
}
+ (void)setRunMode:(BOOL)runMode {
    dispatch_async(dispatch_get_main_queue(), ^{ [self ensureController]; [self shared].controller.mode = runMode ? 1 : 0; });
}
+ (void)setMode:(NSString *)mode {
    NSString *value = [mode isKindOfClass:NSString.class] ? [mode lowercaseString] : @"edit";
    NSInteger state = [value isEqualToString:@"run"] || [value isEqualToString:@"click"] ? 1 : ([value isEqualToString:@"swipe"] ? 2 : ([value isEqualToString:@"long"] || [value isEqualToString:@"longpress"] ? 3 : 0));
    dispatch_async(dispatch_get_main_queue(), ^{ [self ensureController]; [self shared].controller.mode = state; });
}
+ (void)clear { [HLXTouch cancelAll]; [self setPoints:@[]]; }
@end
