// Tweak.m — 入口
// SpringBoard：只注册桌面启动器发来的通知。
// Launcher：TrollStore IPA 内嵌 dylib 时，在本 App 进程内响应按钮通知。
// 通过轻松签等工具直接注入游戏 IPA 时：等宿主 App 进入 Active 状态后，在宿主进程内显示悬浮球。
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.huluxia.toggle";
static NSString *const kBallToggle = @"com.huluxia.ball.toggle";
static NSString *const kBallShow = @"com.huluxia.ball.show";
static NSString *const kHostProbe = @"com.huluxia.springboard.probe";
static NSString *const kHostReady = @"com.huluxia.springboard.ready";
static NSString *const kLauncherBundle = @"com.huluxia.launcher";

static NSUncaughtExceptionHandler *gPrevHandler;
static BOOL gGameBallScheduled = NO;
static BOOL gGameBallShown = NO;
static id gGameLaunchObserver;
static id gGameActiveObserver;
static void HLXCrashHandler(NSException *e) {
    NSString *t = [NSString stringWithFormat:@"%@ CRASH %@: %@\n%@\n\n", [NSDate date], e.name, e.reason, [e.callStackSymbols componentsJoinedByString:@"\n"]];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/huluxia_crash.log"];
    if (!h) { [t writeToFile:@"/var/mobile/huluxia_crash.log" atomically:NO encoding:NSUTF8StringEncoding error:nil]; }
    else { [h seekToEndOfFile]; [h writeData:[t dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile]; }
    if (gPrevHandler) gPrevHandler(e);
}


// 侧载注入模式：构造函数运行时 UIKit/Scene 通常尚未完成启动，不能立即创建 UIWindow。
// 监听 App 启动及进入前台事件，并在主线程、宿主处于 Active 后再创建悬浮球。
static void HLXTryShowInjectedGameBall(NSUInteger attempt) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gGameBallShown) return;
        UIApplication *app = UIApplication.sharedApplication;
        if (app.applicationState != UIApplicationStateActive) {
            if (attempt < 20) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                HLXTryShowInjectedGameBall(attempt + 1);
            });
            return;
        }
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
        if (@available(iOS 13.0, *)) {
            BOOL hasActiveScene = NO;
            for (UIScene *scene in app.connectedScenes) {
                if ([scene isKindOfClass:UIWindowScene.class] && scene.activationState == UISceneActivationStateForegroundActive) {
                    hasActiveScene = YES; break;
                }
            }
            if (!hasActiveScene && attempt < 20) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    HLXTryShowInjectedGameBall(attempt + 1);
                });
                return;
            }
        }
#endif
        gGameBallShown = YES;
        [HLXOverlay.shared showBall];
    });
}

static void HLXRegisterInjectedGameOverlay(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gGameLaunchObserver = [[NSNotificationCenter defaultCenter]
            addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil
            queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                if (!gGameBallScheduled) { gGameBallScheduled = YES; HLXTryShowInjectedGameBall(0); }
            }];
        gGameActiveObserver = [[NSNotificationCenter defaultCenter]
            addObserverForName:UIApplicationDidBecomeActiveNotification object:nil
            queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                if (!gGameBallScheduled) { gGameBallScheduled = YES; HLXTryShowInjectedGameBall(0); }
            }];
        // 兼容 dylib 在 App 已经启动后才被 dlopen 的情况。
        dispatch_async(dispatch_get_main_queue(), ^{
            if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive && !gGameBallScheduled) {
                gGameBallScheduled = YES; HLXTryShowInjectedGameBall(0);
            }
        });
    });
}

// SpringBoard 监听 Launcher 的命令：面板开关、悬浮球开关和启动时显示。
static void HLXRegisterHostCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int panelToken = 0;
        static int ballToken = 0;
        static int ballShowToken = 0;
        static int hostProbeToken = 0;
        static int hostReadyStateToken = 0;
        notify_register_dispatch(kToggle.UTF8String, &panelToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggle];
        });
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
        notify_register_dispatch(kBallShow.UTF8String, &ballShowToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared showBall];
        });
        // Launcher 启动时探测真正的 SpringBoard 宿主；只有收到本进程响应才会自动返回桌面。
        if (notify_register_check(kHostReady.UTF8String, &hostReadyStateToken) != NOTIFY_STATUS_OK) {
            hostReadyStateToken = 0;
        }
        notify_register_dispatch(kHostProbe.UTF8String, &hostProbeToken, dispatch_get_main_queue(), ^(int t) {
            if (hostReadyStateToken != 0) notify_set_state(hostReadyStateToken, 1);
        });
    });
}

// TrollStore IPA 没有 SpringBoard 注入环境，因此只在自己的 Launcher 进程里响应按钮。
static void HLXRegisterLocalLauncherCommands(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static int ballToken = 0;
        static int ballShowToken = 0;
        notify_register_dispatch(kBallToggle.UTF8String, &ballToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared toggleBall];
        });
        notify_register_dispatch(kBallShow.UTF8String, &ballShowToken, dispatch_get_main_queue(), ^(int t) {
            [HLXOverlay.shared showBall];
        });
    });
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/huluxia_disable"]) return;
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if (bid.length == 0) return;

        gPrevHandler = NSGetUncaughtExceptionHandler();
        NSSetUncaughtExceptionHandler(&HLXCrashHandler);

        if ([bid isEqualToString:@"com.apple.springboard"]) {
            HLXRegisterHostCommands();
            return; // 关键：不在注入/安装后自动 showBall
        }

        if ([bid isEqualToString:kLauncherBundle]) {
            HLXRegisterLocalLauncherCommands();
            return;
        }

        // 目标游戏进程负责承载变速代理；越狱 Tweak 构建由 SpringBoard 统一承载全局球，
        // 避免 SpringBoard 球与每个被注入游戏里的本地球重复。独立 DYLIB 侧载时仍显示本地球。
        [HLXSpeed startAgent];
#if !defined(HLX_TWEAK_BUILD)
        HLXRegisterInjectedGameOverlay();
#endif
    }
}
