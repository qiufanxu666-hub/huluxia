#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <pthread.h>
#import <math.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach/mach.h>
#import <mach/vm_region.h>
#import <mach/vm_map.h>
#import <string.h>
#import <stdio.h>
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);
extern kern_return_t mach_vm_region(vm_map_t, mach_vm_address_t *, mach_vm_size_t *, vm_region_flavor_t, vm_region_info_t, mach_msg_type_number_t *, mach_port_t *);

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static pthread_mutex_t gLock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t gInstallLock = PTHREAD_MUTEX_INITIALIZER;
static int gInstallState = 0; // 0=未尝试，1=安装中，2=成功，3=失败（需重启进程）
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono, gWall;        // mach ticks / 单调 ns / 墙钟 ns

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

// Must be called with gLock held. Saturating arithmetic prevents wraparound on long sessions.
static inline uint64_t HLXScaleLocked(const HLXBase *b, uint64_t real) {
    if (real <= b->realBase) return b->virtBase;
    long double delta = (long double)(real - b->realBase) * (long double)gSpeed;
    long double value = (long double)b->virtBase + delta;
    if (!(value >= 0.0L) || value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    pthread_mutex_lock(&gLock);
    uint64_t value = HLXScaleLocked(b, real);
    pthread_mutex_unlock(&gLock);
    return value;
}

static uint64_t h_mach_absolute_time(void) { return scale(&gMach, o_mach_absolute_time()); }

static BOOL isMono(clockid_t c) { return c == CLOCK_MONOTONIC || c == CLOCK_MONOTONIC_RAW || c == CLOCK_UPTIME_RAW; }

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    if (isMono(c))               ns = scale(&gMono, ns);
    else if (c == CLOCK_REALTIME) ns = scale(&gWall, ns);
    else return r;
    ts->tv_sec = (time_t)(ns / 1000000000ULL); ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    if (isMono(c))               return scale(&gMono, ns);
    if (c == CLOCK_REALTIME)     return scale(&gWall, ns);
    return ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    int r = o_gettimeofday(tv, tz);
    if (r != 0 || !tv) return r;
    uint64_t ns = ((uint64_t)tv->tv_sec * 1000000ULL + (uint64_t)tv->tv_usec) * 1000ULL;
    ns = scale(&gWall, ns);
    tv->tv_sec = (time_t)(ns / 1000000000ULL); tv->tv_usec = (suseconds_t)((ns % 1000000000ULL) / 1000ULL);
    return r;
}

static BOOL rebase(double newSpeed) {
    if (!isfinite(newSpeed) || newSpeed < 0.1 || newSpeed > 10.0) return NO;
    // Serialize sampling + virtual-time advancement + multiplier change as one transaction.
    // This prevents rapid slider updates from applying stale samples over newer bases.
    pthread_mutex_lock(&gLock);
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts = {0};
    if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        pthread_mutex_unlock(&gLock);
        return NO;
    }
    struct timeval tv = {0};
    if (o_gettimeofday(&tv, NULL) != 0) {
        pthread_mutex_unlock(&gLock);
        return NO;
    }
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    uint64_t rw = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL;
    uint64_t vm = HLXScaleLocked(&gMach, rm);
    uint64_t vn = HLXScaleLocked(&gMono, rn);
    uint64_t vw = HLXScaleLocked(&gWall, rw);
    gMach.realBase = rm; gMach.virtBase = vm;
    gMono.realBase = rn; gMono.virtBase = vn;
    gWall.realBase = rw; gWall.virtBase = vw;
    gSpeed = newSpeed;
    pthread_mutex_unlock(&gLock);
    return YES;
}


// ───────── 无 Substrate 时的后备方案：安全改写 Mach-O 导入指针 ─────────
static uint32_t gRebindCounts[4];
static uint32_t gRebindFailures;
#if defined(__arm64__) && !__has_feature(ptrauth_calls)
static const char *kNames[4] = { "mach_absolute_time", "clock_gettime", "gettimeofday", "clock_gettime_nsec_np" };
static void *kRepl[4];

static BOOL HLXWriteImportPointer(void **slot, void *replacement) {
    if (!slot || !replacement) return NO;
    if (*slot == replacement) return YES;
    mach_vm_address_t regionAddress = (mach_vm_address_t)slot;
    mach_vm_size_t regionSize = 0;
    mach_port_t objectName = MACH_PORT_NULL;
    vm_region_basic_info_data_64_t regionInfo;
    mach_msg_type_number_t infoCount = VM_REGION_BASIC_INFO_COUNT_64;
    kern_return_t kr = mach_vm_region(mach_task_self(), &regionAddress, &regionSize,
                                      VM_REGION_BASIC_INFO_64, (vm_region_info_t)&regionInfo,
                                      &infoCount, &objectName);
    if (kr != KERN_SUCCESS || regionAddress > (mach_vm_address_t)slot ||
        (mach_vm_address_t)slot >= regionAddress + regionSize) {
        if (objectName != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), objectName);
        return NO;
    }
    if (objectName != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), objectName);
    vm_prot_t oldProtection = regionInfo.protection;
    BOOL changed = (oldProtection & VM_PROT_WRITE) == 0;
    mach_vm_address_t page = ((mach_vm_address_t)slot) & ~((mach_vm_address_t)vm_page_size - 1);
    if (changed && mach_vm_protect(mach_task_self(), page, vm_page_size, FALSE,
                                   VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY) != KERN_SUCCESS) return NO;
    *slot = replacement;
    __sync_synchronize();
    if (changed) mach_vm_protect(mach_task_self(), page, vm_page_size, FALSE, oldProtection);
    return YES;
}

static void rebind_image(const struct mach_header *mh, intptr_t slide) {
    if (!mh || mh->magic != MH_MAGIC_64) return;
    const struct mach_header_64 *h = (const struct mach_header_64 *)mh;
    const struct segment_command_64 *linkedit = NULL;
    const struct symtab_command *symtab = NULL;
    const struct dysymtab_command *dysymtab = NULL;
    const uint8_t *cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmdsize < sizeof(struct load_command)) return;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *sg = (const void *)cur;
            if (!strcmp(sg->segname, "__LINKEDIT")) linkedit = sg;
        } else if (lc->cmd == LC_SYMTAB) symtab = (const void *)cur;
        else if (lc->cmd == LC_DYSYMTAB) dysymtab = (const void *)cur;
    }
    if (!linkedit || !symtab || !dysymtab) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const void *)(base + symtab->symoff);
    const char *strtab = (const char *)(base + symtab->stroff);
    const uint32_t *indirect = (const void *)(base + dysymtab->indirectsymoff);
    cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        if (((const struct load_command *)cur)->cmd != LC_SEGMENT_64) continue;
        const struct segment_command_64 *sg = (const void *)cur;
        if (strcmp(sg->segname, "__DATA") && strcmp(sg->segname, "__DATA_CONST")) continue;
        const struct section_64 *sec = (const void *)(sg + 1);
        for (uint32_t j = 0; j < sg->nsects; j++, sec++) {
            uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            if (sec->reserved1 >= dysymtab->nindirectsyms) continue;
            const uint32_t *ind = indirect + sec->reserved1;
            void **ptrs = (void **)((uintptr_t)slide + sec->addr);
            uint64_t count = sec->size / sizeof(void *);
            for (uint64_t k = 0; k < count; k++) {
                uint64_t index = (uint64_t)sec->reserved1 + k;
                if (index >= dysymtab->nindirectsyms) break;
                uint32_t si = ind[k];
                if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL ||
                    si == (INDIRECT_SYMBOL_LOCAL | INDIRECT_SYMBOL_ABS) || si >= symtab->nsyms) continue;
                uint32_t stringIndex = syms[si].n_un.n_strx;
                if (stringIndex >= symtab->strsize) continue;
                const char *nm = strtab + stringIndex;
                if (nm[0] != '_') continue;
                for (int n = 0; n < 4; n++) {
                    if (!kRepl[n] || strcmp(nm + 1, kNames[n])) continue;
                    if (HLXWriteImportPointer(&ptrs[k], kRepl[n])) __sync_fetch_and_add(&gRebindCounts[n], 1);
                    else __sync_fetch_and_add(&gRebindFailures, 1);
                }
            }
        }
    }
}
static BOOL rebindAll(void) {
    memset(gRebindCounts, 0, sizeof(gRebindCounts));
    gRebindFailures = 0;
    kRepl[0] = (void *)h_mach_absolute_time;
    kRepl[1] = (void *)h_clock_gettime;
    kRepl[2] = (void *)h_gettimeofday;
    kRepl[3] = o_clock_gettime_nsec_np ? (void *)h_clock_gettime_nsec_np : NULL;
    _dyld_register_func_for_add_image(rebind_image);
    return gRebindCounts[0] > 0 && gRebindCounts[1] > 0 && gRebindCounts[2] > 0;
}
#else
static BOOL rebindAll(void) { return NO; }
#endif

static BOOL installUnlocked(NSString **err) {
    if (gInstalled) return YES;
    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) {
        if (err) *err = @"系统时钟符号解析失败（mach_absolute_time / clock_gettime / gettimeofday）";
        return NO;
    }
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts = {0};
    if (((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts) != 0) {
        if (err) *err = @"读取 CLOCK_MONOTONIC 失败"; return NO;
    }
    struct timeval tv = {0};
    if (((int (*)(struct timeval *, void *))sym_gtd)(&tv, NULL) != 0) {
        if (err) *err = @"读取 gettimeofday 失败"; return NO;
    }
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    gMono = (HLXBase){ n, n };
    uint64_t w = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL;
    gWall = (HLXBase){ w, w };
    if (hook) {
        hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
        hook(sym_cg, (void *)h_clock_gettime, (void **)&o_clock_gettime);
        hook(sym_gtd, (void *)h_gettimeofday, (void **)&o_gettimeofday);
        if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
        if (!o_mach_absolute_time || !o_clock_gettime || !o_gettimeofday || (sym_cgn && !o_clock_gettime_nsec_np)) {
            if (err) *err = @"MSHookFunction 未返回完整原始函数指针，拒绝启用变速";
            return NO;
        }
    } else {
        o_mach_absolute_time = (uint64_t (*)(void))sym_mat;
        o_clock_gettime = (int (*)(clockid_t, struct timespec *))sym_cg;
        o_gettimeofday = (int (*)(struct timeval *, void *))sym_gtd;
        o_clock_gettime_nsec_np = (uint64_t (*)(clockid_t))sym_cgn;
        if (!rebindAll()) {
            if (err) {
#if defined(__arm64__) && __has_feature(ptrauth_calls)
                *err = @"当前 arm64e/PAC 环境没有 MSHookFunction，安全 Hook 不可用，变速未启用";
#else
                *err = [NSString stringWithFormat:@"无 Substrate 时导入指针重绑定失败（mach=%u clock=%u wall=%u protectFailures=%u）",
                        gRebindCounts[0], gRebindCounts[1], gRebindCounts[2], gRebindFailures];
#endif
            }
            return NO;
        }
    }
    gInstalled = YES;
    return YES;
}

static BOOL install(NSString **err) {
    pthread_mutex_lock(&gInstallLock);
    if (gInstallState == 2 || gInstalled) {
        pthread_mutex_unlock(&gInstallLock);
        return YES;
    }
    if (gInstallState == 3) {
        if (err) *err = @"本进程此前发生过部分/失败的时钟 Hook 安装；为避免重复打补丁导致崩溃，请完全退出并重新打开目标 App";
        pthread_mutex_unlock(&gInstallLock);
        return NO;
    }
    gInstallState = 1;
    NSString *localError = nil;
    BOOL ok = installUnlocked(&localError);
    gInstallState = ok ? 2 : 3;
    if (!ok && err) *err = localError ?: @"时钟 Hook 安装失败";
    pthread_mutex_unlock(&gInstallLock);
    return ok;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

static void publishAgentStatus(pid_t pid, uint64_t status) {
    int token = 0;
    NSString *name = agentName(pid);
    if (notify_register_check(name.UTF8String, &token) == NOTIFY_STATUS_OK) {
        notify_set_state(token, status);
        notify_post(name.UTF8String);
        notify_cancel(token);
    }
}

@implementation HLXSpeed

+ (double)current {
    pthread_mutex_lock(&gLock);
    double value = gSpeed;
    pthread_mutex_unlock(&gLock);
    return value;
}

+ (uint64_t)realMachAbsoluteTime {
    uint64_t (*realFn)(void) = o_mach_absolute_time;
    return realFn ? realFn() : mach_absolute_time();
}

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x"; return NO; }
    if (!install(err)) return NO;
    if (!rebase(mult)) { if (err) *err = @"读取原始时钟失败，倍率未更新"; return NO; }
    return YES;
}

+ (int)agentStatusForPid:(pid_t)pid {
    if (pid <= 0) return 0;
    int token = 0; uint64_t status = 0;
    if (notify_register_check(agentName(pid).UTF8String, &token) == NOTIFY_STATUS_OK) {
        notify_get_state(token, &status);
        notify_cancel(token);
    }
    return status <= 2 ? (int)status : 0;
}

+ (void)startAgent {
    static int tokSpeed = 0;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pid_t me = getpid();
        NSString *err = nil;
        if (!install(&err)) {
            // 2 表示 tweak 已注入，但时钟 Hook 不可用；内存功能仍可识别此代理。
            publishAgentStatus(me, 2);
            NSString *line = [NSString stringWithFormat:@"[%@] speed install failed: %@\n", [NSDate date], err ?: @"unknown"];
            NSLog(@"[Huluxia] %@", line);
            NSString *path = @"/var/mobile/huluxia_speed.log";
            NSData *data = [line dataUsingEncoding:NSUTF8StringEncoding];
            NSFileHandle *file = [NSFileHandle fileHandleForWritingAtPath:path];
            if (!file) [data writeToFile:path atomically:YES];
            else { [file seekToEndOfFile]; [file writeData:data]; [file closeFile]; }
            return;
        }
        notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int token) {
            uint64_t bits = 0; notify_get_state(token, &bits);
            double mult = 1.0; memcpy(&mult, &bits, sizeof(mult));
            if (isfinite(mult) && mult >= 0.1 && mult <= 10.0) rebase(mult);
        });
        publishAgentStatus(me, 1);
    });
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x"; return NO; }
    int status = [self agentStatusForPid:pid];
    if (status == 0) {
        if (err) *err = @"目标进程未加载葫芦侠代理：请将目标 App 的 Bundle ID 加入 Huluxia.plist Filter，重新构建安装，并完全退出后重开目标 App";
        return NO;
    }
    if (status == 2) {
        if (err) *err = @"目标 App 已加载葫芦侠，但时钟 Hook 安装失败；请查看 /var/mobile/huluxia_speed.log";
        return NO;
    }
    int token = 0;
    if (notify_register_check(speedName(pid).UTF8String, &token) != NOTIFY_STATUS_OK) {
        if (err) *err = @"Darwin notify 注册失败";
        return NO;
    }
    uint64_t bits = 0; memcpy(&bits, &mult, sizeof(bits));
    notify_set_state(token, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(token);
    return YES;
}
@end
