// iOS 8-9 legacy clock backend.
// The Stage-1 HLXSpeed.m is intentionally left byte-for-byte unchanged for modern builds.
// iOS 8/9 may not export clock_gettime; this backend scales mach_absolute_time and gettimeofday.
#import "HLXSpeed.h"
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <notify.h>
#import <pthread.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <math.h>
#import <string.h>

#if !defined(__arm64__) && !defined(__arm__)
#error "HLXSpeedLegacy is intended for 32-bit ARM and legacy arm64 builds only"
#endif

typedef void (*HLXMSHookFunction)(void *, void *, void **);
typedef struct { uint64_t realBase, virtualBase; } HLXLegacyBase;
static pthread_mutex_t gLegacyLock = PTHREAD_MUTEX_INITIALIZER;
static double gLegacySpeed = 1.0;
static BOOL gLegacyInstalled = NO;
static HLXLegacyBase gLegacyMach, gLegacyWall;
static uint64_t (*gOriginalMach)(void);
static int (*gOriginalGettimeofday)(struct timeval *, void *);

static NSString *HLXLegacySpeedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *HLXLegacyAgentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

static uint64_t HLXLegacyScaleLocked(HLXLegacyBase *base, uint64_t real) {
    if (real <= base->realBase) return base->virtualBase;
    long double value = (long double)base->virtualBase + (long double)(real - base->realBase) * (long double)gLegacySpeed;
    if (!(value >= 0.0L) || value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}
static uint64_t HLXLegacyScale(HLXLegacyBase *base, uint64_t real) {
    pthread_mutex_lock(&gLegacyLock);
    uint64_t value = HLXLegacyScaleLocked(base, real);
    pthread_mutex_unlock(&gLegacyLock);
    return value;
}
static uint64_t HLXLegacyMachHook(void) {
    uint64_t real = gOriginalMach ? gOriginalMach() : mach_absolute_time();
    return HLXLegacyScale(&gLegacyMach, real);
}
static int HLXLegacyGettimeofdayHook(struct timeval *tv, void *tz) {
    int result = gOriginalGettimeofday ? gOriginalGettimeofday(tv, tz) : gettimeofday(tv, tz);
    if (result != 0 || !tv) return result;
    uint64_t real = ((uint64_t)tv->tv_sec * 1000000ULL + (uint64_t)tv->tv_usec) * 1000ULL;
    uint64_t scaled = HLXLegacyScale(&gLegacyWall, real);
    tv->tv_sec = (time_t)(scaled / 1000000000ULL);
    tv->tv_usec = (suseconds_t)((scaled % 1000000000ULL) / 1000ULL);
    return result;
}
static BOOL HLXLegacyRebase(double multiplier) {
    if (!isfinite(multiplier) || multiplier < 0.1 || multiplier > 10.0) return NO;
    pthread_mutex_lock(&gLegacyLock);
    uint64_t realMach = gOriginalMach();
    struct timeval tv = {0};
    if (gOriginalGettimeofday(&tv, NULL) != 0) {
        pthread_mutex_unlock(&gLegacyLock);
        return NO;
    }
    uint64_t realWall = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL;
    uint64_t virtualMach = HLXLegacyScaleLocked(&gLegacyMach, realMach);
    uint64_t virtualWall = HLXLegacyScaleLocked(&gLegacyWall, realWall);
    gLegacyMach.realBase = realMach; gLegacyMach.virtualBase = virtualMach;
    gLegacyWall.realBase = realWall; gLegacyWall.virtualBase = virtualWall;
    gLegacySpeed = multiplier;
    pthread_mutex_unlock(&gLegacyLock);
    return YES;
}
static BOOL HLXLegacyInstall(NSString **error) {
    if (gLegacyInstalled) return YES;
    HLXMSHookFunction hook = (HLXMSHookFunction)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *machSymbol = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *wallSymbol = dlsym(RTLD_DEFAULT, "gettimeofday");
    if (!hook || !machSymbol || !wallSymbol) {
        if (error) *error = @"旧系统变速需要可用的 Substrate MSHookFunction、mach_absolute_time 和 gettimeofday";
        return NO;
    }
    gOriginalMach = (uint64_t (*)(void))machSymbol;
    gOriginalGettimeofday = (int (*)(struct timeval *, void *))wallSymbol;
    uint64_t m = gOriginalMach();
    struct timeval tv = {0};
    if (gOriginalGettimeofday(&tv, NULL) != 0) {
        if (error) *error = @"读取旧系统原始时钟失败";
        return NO;
    }
    uint64_t w = ((uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec) * 1000ULL;
    gLegacyMach = (HLXLegacyBase){m, m};
    gLegacyWall = (HLXLegacyBase){w, w};
    hook(machSymbol, (void *)HLXLegacyMachHook, (void **)&gOriginalMach);
    hook(wallSymbol, (void *)HLXLegacyGettimeofdayHook, (void **)&gOriginalGettimeofday);
    gLegacyInstalled = (gOriginalMach != NULL && gOriginalGettimeofday != NULL);
    if (!gLegacyInstalled && error) *error = @"旧系统时钟 Hook 安装失败";
    return gLegacyInstalled;
}

@implementation HLXSpeed
+ (double)current {
    pthread_mutex_lock(&gLegacyLock); double value = gLegacySpeed; pthread_mutex_unlock(&gLegacyLock); return value;
}
+ (uint64_t)realMachAbsoluteTime {
    uint64_t (*fn)(void) = gOriginalMach;
    return fn ? fn() : mach_absolute_time();
}
+ (BOOL)applyLocal:(double)mult error:(NSString **)error {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (error) *error = @"变速范围为 0.1x～10x"; return NO; }
    if (!HLXLegacyInstall(error)) return NO;
    if (!HLXLegacyRebase(mult)) { if (error) *error = @"旧系统时钟重定位失败，倍率未更新"; return NO; }
    return YES;
}
+ (int)agentStatusForPid:(pid_t)pid {
    if (pid <= 0) return 0;
    int token = 0; uint64_t status = 0;
    if (notify_register_check(HLXLegacyAgentName(pid).UTF8String, &token) == NOTIFY_STATUS_OK) {
        notify_get_state(token, &status);
        notify_cancel(token);
    }
    return status <= 2 ? (int)status : 0;
}
+ (void)startAgent {
    static int speedToken = 0;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pid_t pid = getpid(); NSString *error = nil;
        int aliveToken = 0;
        if (!HLXLegacyInstall(&error)) {
            if (notify_register_check(HLXLegacyAgentName(pid).UTF8String, &aliveToken) == NOTIFY_STATUS_OK) {
                notify_set_state(aliveToken, 2); notify_post(HLXLegacyAgentName(pid).UTF8String); notify_cancel(aliveToken);
            }
            NSLog(@"[Huluxia] legacy speed hook failed: %@", error ?: @"unknown");
            return;
        }
        notify_register_dispatch(HLXLegacySpeedName(pid).UTF8String, &speedToken, dispatch_get_main_queue(), ^(int token) {
            uint64_t bits = 0; notify_get_state(token, &bits); double multiplier = 1.0; memcpy(&multiplier, &bits, sizeof(multiplier));
            if (isfinite(multiplier) && multiplier >= 0.1 && multiplier <= 10.0) HLXLegacyRebase(multiplier);
        });
        if (notify_register_check(HLXLegacyAgentName(pid).UTF8String, &aliveToken) == NOTIFY_STATUS_OK) {
            notify_set_state(aliveToken, 1); notify_post(HLXLegacyAgentName(pid).UTF8String); notify_cancel(aliveToken);
        }
    });
}
+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)error {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (error) *error = @"变速范围为 0.1x～10x"; return NO; }
    int status = [self agentStatusForPid:pid];
    if (status == 0) { if (error) *error = @"目标进程没有加载旧系统葫芦侠代理，请检查 Huluxia.plist Filter 后重新打开目标 App"; return NO; }
    if (status == 2) { if (error) *error = @"目标进程已加载旧系统代理，但 MSHookFunction 安装失败，变速不可用"; return NO; }
    int speedToken = 0;
    if (notify_register_check(HLXLegacySpeedName(pid).UTF8String, &speedToken) != NOTIFY_STATUS_OK) { if (error) *error = @"notify 注册失败"; return NO; }
    uint64_t bits = 0; memcpy(&bits, &mult, sizeof(bits)); notify_set_state(speedToken, bits); notify_post(HLXLegacySpeedName(pid).UTF8String); notify_cancel(speedToken);
    return YES;
}
@end
