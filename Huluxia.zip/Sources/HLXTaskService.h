#import <mach/mach.h>
#import <sys/types.h>

NS_ASSUME_NONNULL_BEGIN

// Obtain a task send right from the dedicated privileged LaunchDaemon.
// The target process does not need to load the Huluxia tweak.
kern_return_t HLXTaskServiceCopyTaskPort(pid_t pid, mach_port_t * _Nullable taskPort);

NS_ASSUME_NONNULL_END
