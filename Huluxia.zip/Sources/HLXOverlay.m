#import "HLXOverlay.h"
#import "HLXBridge.h"
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <dlfcn.h>
#import <mach-o/getsect.h>
#import <mach-o/dyld.h>
#import <objc/message.h>

static void HLXLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1,2);
static void HLXLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *m = [[NSString alloc] initWithFormat:fmt arguments:ap]; va_end(ap);
    NSLog(@"[Huluxia] %@", m);
    NSString *line = [NSString stringWithFormat:@"%@ %@\n", [NSDate date], m];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/huluxia.log"];
    if (!h) { [line writeToFile:@"/var/mobile/huluxia.log" atomically:NO encoding:NSUTF8StringEncoding error:nil]; return; }
    [h seekToEndOfFile]; [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
}

static NSString *const kMark = @"\x01HLX\x01";
static const CGSize kBallWindow = { 66, 72 };     // 悬浮球：48 + right:18 / bottom:24

// ───────── 加载 UI（优先读 dylib 内嵌段，其次读磁盘）─────────
static void HLXAnchor(void) {}
static NSData *HLXSection(const char *name) {
    Dl_info info;
    if (dladdr((void *)&HLXAnchor, &info) && info.dli_fbase) {
        unsigned long sz = 0;
#ifdef __LP64__
        uint8_t *p = getsectiondata((const struct mach_header_64 *)info.dli_fbase, "__DATA", name, &sz);
#else
        uint8_t *p = getsectiondata((const struct mach_header *)info.dli_fbase, "__DATA", name, &sz);
#endif
        if (p && sz) return [NSData dataWithBytes:p length:sz];
    }
    return nil;
}
static NSString *HLXLoadUI(void) {
    NSData *d = HLXSection("__hlxui");
    NSString *e = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : nil;
    if (e) return e;
    for (NSString *path in @[ @"/var/jb/Library/Application Support/Huluxia/ui.html", @"/Library/Application Support/Huluxia/ui.html" ]) {
        NSString *s = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        if (s) return s;
    }
    return @"<html><body style='background:#222;color:#fff;font:16px sans-serif;padding:20px'>未找到内嵌界面（__hlxui 段）</body></html>";
}


static NSString *const kMarkP = @"\x01HLXP\x01";      // 页面→原生 的异步消息（窗口位置等），UIWebView 没有 messageHandlers，也走 prompt
static BOOL HLXIsSB(void) { return [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]; }

@class HLXRootVC;
static __weak HLXRootVC *gRoot;

// 同步等待异步结果。UIWebView 的 JS 对话框回调是在 WebThread 上调用的，不是主线程：
//  - 在主线程：嵌套 runloop（UI 不卡）
//  - 在其他线程：信号量等待（主线程照常工作）
static NSString *HLXBridgeSync(NSString *payload) {
    __block NSString *res = nil;
    if (NSThread.isMainThread) {
        __block BOOL done = NO;
        [HLXBridge handlePayload:payload completion:^(NSString *j) { res = j; done = YES; }];
        while (!done) CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.01, true);
    } else {
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        [HLXBridge handlePayload:payload completion:^(NSString *j) { res = j; dispatch_semaphore_signal(sem); }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    }
    return res ?: @"";
}
static void HLXOnMain(void (^blk)(void)) { if (NSThread.isMainThread) blk(); else dispatch_async(dispatch_get_main_queue(), blk); }

// ───────── 窗口 / 控制器 ─────────
@interface HLXRootVC : UIViewController <WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler, UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIView *web;        // WKWebView（App 内）或 UIWebView（SpringBoard 内，和 H5GG 一样）
@property (nonatomic, strong) UILabel *status;
@property (nonatomic, copy) NSString *htmlSource;
@property (nonatomic, assign) BOOL didRetryBaseURL;
@property (nonatomic, assign) BOOL didRetryAfterWebContentTermination;
@property (nonatomic, weak) UIWindow *hostWindow;
@property (nonatomic, assign) CGRect expanded;
@property (nonatomic, assign) CGRect dragRect;
@property (nonatomic, assign) BOOL collapsed;
@property (nonatomic, assign) CGPoint panStart;
@property (nonatomic, assign) CGRect panFrame;
- (void)applyFrame;
- (void)callLayout;
- (void)handleMessage:(NSDictionary *)d;
- (void)pageDidFinish;
- (void)pageDidFail:(NSString *)why;
- (void)js:(NSString *)code;
@end

@implementation HLXRootVC

- (void)js:(NSString *)code {
    if ([self.web isKindOfClass:WKWebView.class]) {
        [(WKWebView *)self.web evaluateJavaScript:code completionHandler:nil];
        return;
    }
    // 原生 fallback 只是 UIView，不具备 JavaScript 执行接口；不能向它发送 UIWebView 私有/旧接口。
    SEL selector = NSSelectorFromString(@"stringByEvaluatingJavaScriptFromString:");
    if ([self.web respondsToSelector:selector])
        ((id (*)(id, SEL, id))objc_msgSend)(self.web, selector, code);
}

// SpringBoard 使用 UIWebView，避免依赖独立的 WebContent 进程。
// 注意：JS prompt 的回调必须由真正的 delegate（HLXRootVC）实现，不能加在 UIWebView 子类上。

- (void)webViewDidFinishLoad:(id)w { [self pageDidFinish]; }
- (void)webView:(id)w didFailLoadWithError:(NSError *)e { [self pageDidFail:[NSString stringWithFormat:@"%@", e]]; }

// UIWebView 的 JS 桥接回调必须放在 delegate 对象（HLXRootVC）上。
- (NSString *)webView:(id)webView
runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt
          defaultText:(NSString *)defaultText
     initiatedByFrame:(id)frame {
    if ([prompt hasPrefix:kMark]) {
        return HLXBridgeSync([prompt substringFromIndex:kMark.length]);
    }
    if ([prompt hasPrefix:kMarkP]) {
        NSData *data = [[prompt substringFromIndex:kMarkP.length] dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *message = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
        if ([message isKindOfClass:NSDictionary.class]) HLXOnMain(^{ [gRoot handleMessage:message]; });
        return @"";
    }
    return defaultText ?: @"";
}

- (void)webView:(id)webView
runJavaScriptAlertPanelWithMessage:(NSString *)message
     initiatedByFrame:(id)frame {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    HLXOnMain(^{ if (gRoot.presentedViewController == nil) [gRoot presentViewController:alert animated:YES completion:nil]; });
}

- (BOOL)webView:(id)webView
runJavaScriptConfirmPanelWithMessage:(NSString *)message
     initiatedByFrame:(id)frame {
    __block BOOL finished = NO;
    __block BOOL confirmed = NO;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { finished = YES; }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { confirmed = YES; finished = YES; }]];
    HLXOnMain(^{ if (gRoot.presentedViewController == nil) [gRoot presentViewController:alert animated:YES completion:nil]; else finished = YES; });
    while (!finished) {
        if (NSThread.isMainThread) CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.01, true);
        else usleep(10000);
    }
    return confirmed;
}

- (void)dismissNativeDiagnosticPanel {
    [HLXOverlay.shared hide];
}

- (void)loadView {
#if defined(HLX_NATIVE_DIAGNOSTIC)
    // Stage 4E diagnostic mode: intentionally avoid WebKit entirely.
    // This branch is opt-in at build time; normal builds retain the complete HTML/Lua UI.
    gRoot = self;
    CGSize screen = UIScreen.mainScreen.bounds.size;
    CGFloat width = MIN(390.0, screen.width);
    CGFloat height = MIN(580.0, screen.height);
    self.expanded = CGRectMake((screen.width - width) / 2.0,
                               (screen.height - height) / 2.0,
                               width, height);

    UIView *native = [[UIView alloc] initWithFrame:CGRectZero];
    native.backgroundColor = [UIColor colorWithWhite:0.07 alpha:0.97];
    native.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.web = native;
    self.view = native;

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 24, width - 36, 34)];
    title.text = @"葫芦侠 · 原生窗口诊断";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:20];
    [native addSubview:title];

    UILabel *detail = [[UILabel alloc] initWithFrame:CGRectMake(18, 72, width - 36, 150)];
    detail.numberOfLines = 0;
    detail.textColor = [UIColor colorWithWhite:0.88 alpha:1.0];
    detail.font = [UIFont systemFontOfSize:14];
    detail.text = @"当前为纯 UIKit 诊断模式。\n\n此模式不创建 WKWebView、不加载 HTML，也不启动 Lua 页面。\n\n如果点击悬浮球后此面板能够稳定显示，可帮助缩小窗口宿主与 WebKit 初始化之间的故障范围；这不是最终功能版本。";
    [native addSubview:detail];

    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(18, 244, width - 36, 46);
    close.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    close.backgroundColor = [UIColor colorWithRed:0.18 green:0.48 blue:0.92 alpha:1.0];
    close.layer.cornerRadius = 10;
    [close setTitle:@"关闭诊断面板" forState:UIControlStateNormal];
    [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [close addTarget:self action:@selector(dismissNativeDiagnosticPanel) forControlEvents:UIControlEventTouchUpInside];
    [native addSubview:close];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    pan.delegate = self;
    pan.cancelsTouchesInView = NO;
    pan.maximumNumberOfTouches = 1;
    [native addGestureRecognizer:pan];
    HLXLog(@"stage4e native diagnostic panel loaded; WebKit bypassed");
    return;
#else
    gRoot = self;
    HLXLog(@"panel loadView begin; bundle=%@; system=%@; appState=%ld; mainThread=%@",
           NSBundle.mainBundle.bundleIdentifier ?: @"(unknown)",
           UIDevice.currentDevice.systemVersion ?: @"(unknown)",
           (long)UIApplication.sharedApplication.applicationState,
           NSThread.isMainThread ? @"YES" : @"NO");
    NSString *html = HLXLoadUI();
#if defined(HLX_WEBKIT_SMOKE_DIAGNOSTIC)
    // Stage 5F: minimal local document. It exercises the same overlay UIWindow,
    // WKWebView construction and navigation callbacks without loading the large
    // production HTML bundle or installing the JS bridge.
    html = @"<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>body{margin:0;background:#151923;color:#fff;font:16px -apple-system;padding:24px} .ok{color:#72e6a2;font-weight:700}</style></head><body><h2>葫芦侠 · WebKit 诊断</h2><p class=\"ok\">WKWebView 已完成本地 HTML 渲染</p><p>如果你能看到这段文字，说明窗口与 WebKit 基础加载链路正常。完整面板仍需单独检查资源和 JS 桥接。</p><p id=\"js\"></p><script>document.getElementById('js').textContent='JavaScript 执行正常';</script></body></html>";
    HLXLog(@"stage5f WebKit smoke diagnostic enabled; production HTML bypassed");
#endif
    self.htmlSource = html;
    HLXLog(@"ui source bytes=%lu", (unsigned long)[html lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
    // Stage 4A: SpringBoard 不再实例化已废弃的 UIWebView。
    // SpringBoard 与普通 App 统一走 WKWebView 路径；若 WebKit 初始化失败，
    // 下方原生 fallback 会保留可见错误面板，避免继续向空 web 对象发送消息。
    HLXLog(@"step: create WKWebView (UIWebView disabled)");
    if (!self.web) {
        @try {
            WKWebViewConfiguration *cfg = [WKWebViewConfiguration new];
            WKUserContentController *ucc = [WKUserContentController new];
#if !defined(HLX_WEBKIT_SMOKE_DIAGNOSTIC)
            [ucc addScriptMessageHandler:self name:@"hlx"];
            [ucc addUserScript:[[WKUserScript alloc] initWithSource:HLXBridge.bootstrapScript injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO]];
#endif
            cfg.userContentController = ucc;
            cfg.allowsInlineMediaPlayback = YES;
            WKWebView *wk = [[WKWebView alloc] initWithFrame:CGRectZero configuration:cfg];
            wk.UIDelegate = self;
            wk.navigationDelegate = self;
            wk.opaque = NO;
            wk.backgroundColor = UIColor.clearColor;
            wk.scrollView.backgroundColor = UIColor.clearColor;
            wk.scrollView.scrollEnabled = NO;
            wk.scrollView.bounces = NO;
            // 这里用 respondsToSelector 做运行时判断：旧 SDK 下写可用性检查会引用 __availability_version_check，导致链接失败。
            SEL insetSetter = NSSelectorFromString(@"setContentInsetAdjustmentBehavior:");
            if ([wk.scrollView respondsToSelector:insetSetter]) {
                /* The iOS 11 'never adjust' enum value is 2.
                   Use the runtime setter so iOS 8-10 SDK headers need not
                   declare the iOS 11 API or its availability annotation. */
                ((void(*)(id, SEL, NSInteger))objc_msgSend)(wk.scrollView, insetSetter, 2);
            }
            // SpringBoard 中关闭 Web Inspector，避免启用不必要的调试入口。
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 160400
            if (@available(iOS 16.4, *)) { if (!HLXIsSB()) wk.inspectable = YES; }
#endif
            self.web = wk;
            HLXLog(@"engine = WKWebView");
        } @catch (NSException *exception) {
            HLXLog(@"WKWebView init exception: %@ %@", exception.name, exception.reason);
            self.web = nil;
        }
    }
    if (!self.web) {
        // 引擎创建失败时显示原生错误视图，避免空指针继续向下执行。
        UIView *fallback = [[UIView alloc] initWithFrame:CGRectZero];
        fallback.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.96];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectInset(UIScreen.mainScreen.bounds, 16, 16)];
        label.numberOfLines = 0;
        label.textColor = UIColor.whiteColor;
        label.text = @"网页引擎初始化失败。请查看 /var/mobile/huluxia.log";
        [fallback addSubview:label];
        self.web = fallback;
        HLXLog(@"no web engine; native fallback view installed");
    }
    self.view = self.web;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    pan.delegate = self; pan.cancelsTouchesInView = NO; pan.maximumNumberOfTouches = 1;
    [self.web addGestureRecognizer:pan];

    { CGSize sc = UIScreen.mainScreen.bounds.size; CGFloat w = MIN(390, sc.width), h = MIN(580, sc.height); self.expanded = CGRectMake((sc.width - w) / 2, (sc.height - h) / 2, w, h); }
    // 原生状态条：页面没加载出来时，至少能看到原因
    self.status = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 390, 580)];
    self.status.numberOfLines = 0; self.status.textAlignment = NSTextAlignmentLeft;
    self.status.lineBreakMode = NSLineBreakByCharWrapping;
    self.status.adjustsFontSizeToFitWidth = YES; self.status.minimumScaleFactor = 0.6;
    self.status.userInteractionEnabled = YES;
    [self.status addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(copyStatus)]];
    self.status.textColor = UIColor.whiteColor; self.status.font = [UIFont systemFontOfSize:12];
    self.status.backgroundColor = [UIColor colorWithWhite:0.1 alpha:0.92];
    self.status.text = @"葫芦侠正在加载…\n（若长时间停留，请查看 /var/mobile/huluxia.log）";
    [self.web addSubview:self.status];
    HLXLog(@"loadView, ui bytes=%lu", (unsigned long)html.length);
    __weak HLXRootVC *ws = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if (ws.status.superview) { ws.status.text = @"加载超时：网页引擎没有返回页面。\n请查看 /var/mobile/huluxia.log"; HLXLog(@"load timeout"); [ws reveal]; }
    });
    // 用固定的 https 源，localStorage（收藏/脚本/主题）才能跨次保存
    @try {
        if ([self.web isKindOfClass:WKWebView.class]) {
            HLXLog(@"step: loadHTMLString begin; engine=WKWebView; bytes=%lu",
                   (unsigned long)[html lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
            [(WKWebView *)self.web loadHTMLString:html baseURL:[NSURL URLWithString:@"https://huluxia.local/"]];
            HLXLog(@"step: loadHTMLString returned navigation");
        } else {
            SEL loadSel = NSSelectorFromString(@"loadHTMLString:baseURL:");
            if ([self.web respondsToSelector:loadSel]) {
                HLXLog(@"step: legacy web loader begin");
                ((void (*)(id, SEL, id, id))objc_msgSend)(self.web, loadSel, html, [NSURL URLWithString:@"https://huluxia.local/"]);
                HLXLog(@"step: legacy web loader returned");
            } else {
                self.status.text = @"网页引擎不可用：当前视图不支持 HTML 加载。请复制诊断信息。";
                HLXLog(@"load aborted: fallback view has no HTML loader");
                [self reveal];
            }
        }
    } @catch (NSException *exception) {
        NSString *detail = [NSString stringWithFormat:@"name=%@ reason=%@",
                            exception.name ?: @"(unknown)",
                            exception.reason ?: @"(no reason)"];
        HLXLog(@"HTML loader exception: %@", detail);
        self.status.text = [NSString stringWithFormat:@"网页加载调用发生异常：\\n%@\\n请复制此信息并查看 /var/mobile/huluxia.log", detail];
        [self reveal];
    }
#endif
}

// 作为 key window 时别去改宿主 App 的方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UIInterfaceOrientation o = UIInterfaceOrientationPortrait;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        // 必须优先读取本悬浮窗所属 scene，不能随意取 connectedScenes 中的第一个窗口方向。
        UIWindowScene *scene = self.hostWindow.windowScene;
        if (scene) o = scene.interfaceOrientation;
        else {
            for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
                if (![s isKindOfClass:UIWindowScene.class]) continue;
                UIWindowScene *candidate = (UIWindowScene *)s;
                if (candidate.activationState == UISceneActivationStateForegroundActive) { o = candidate.interfaceOrientation; break; }
            }
        }
    }
#endif
    if (o < UIInterfaceOrientationPortrait || o > UIInterfaceOrientationLandscapeRight) o = UIInterfaceOrientationPortrait;
    return (UIInterfaceOrientationMask)(1 << o);
}
- (BOOL)prefersStatusBarHidden { return YES; }

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.status.frame = CGRectInset(self.web.bounds, 8, 8);     // 始终贴合窗口，文字不会被裁到屏幕外
}
- (void)copyStatus { UIPasteboard.generalPasteboard.string = self.status.text; self.status.text = [self.status.text stringByAppendingString:@"\n\n（已复制）"]; }
- (void)reveal { self.hostWindow.alpha = 1; }

#pragma mark 窗口几何

- (CGSize)screenSize {
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = self.hostWindow.windowScene;
        if (scene) return scene.coordinateSpace.bounds.size;
    }
#endif
    return UIScreen.mainScreen.bounds.size;
}

- (CGRect)clamp:(CGRect)r {
    CGSize s = [self screenSize];
    r.size.width = MIN(r.size.width, s.width); r.size.height = MIN(r.size.height, s.height);
    r.origin.x = MAX(0, MIN(r.origin.x, s.width - r.size.width));
    r.origin.y = MAX(0, MIN(r.origin.y, s.height - r.size.height));
    return r;
}

- (void)applyFrame {
    if (!self.hostWindow) return;
    CGRect f = self.collapsed
        ? CGRectMake(CGRectGetMaxX(self.expanded) - kBallWindow.width, CGRectGetMaxY(self.expanded) - kBallWindow.height, kBallWindow.width, kBallWindow.height)
        : self.expanded;
    self.hostWindow.frame = [self clamp:f];
}

- (void)callLayout {
    CGSize s = [self screenSize];
    NSString *js = [NSString stringWithFormat:@"window.__hlxLayout && window.__hlxLayout(%g,%g)", s.width, s.height];
    [self js:js];
}

#pragma mark JS → 原生消息

- (void)userContentController:(WKUserContentController *)c didReceiveScriptMessage:(WKScriptMessage *)msg {
    if ([msg.body isKindOfClass:NSDictionary.class]) [self handleMessage:msg.body];
}

- (void)handleMessage:(NSDictionary *)d {
    HLXLog(@"msg %@", d[@"t"]);
    NSString *t = d[@"t"];
    NSArray *r = d[@"r"];
    if ([t isEqualToString:@"rect"] && r.count == 4) {
        self.expanded = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
        [self applyFrame];
        [self reveal];                                // 页面把窗口摆好位置后再显示，避免先出现在左上角再跳到中间
    } else if ([t isEqualToString:@"drag"] && r.count == 4) {
        self.dragRect = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
    } else if ([t isEqualToString:@"visible"]) {
        if (![d[@"v"] boolValue]) [HLXOverlay.shared hide]; else [HLXOverlay.shared show];
    } else if ([t isEqualToString:@"layout"]) {
        [self callLayout];
    } else if ([t isEqualToString:@"collapsed"]) {
        BOOL c2 = [d[@"v"] boolValue];
        if (c2) {   // 页面自带的小球不用，改由原生悬浮球负责：还原页面并收起窗口
            [self js:@"var a=document.getElementById('app'),f=document.getElementById('float');if(a)a.style.display='flex';if(f)f.style.display='none';"];
            [HLXOverlay.shared hide];
            return;
        }
        if (c2 == self.collapsed) return;
        if (!c2) {                                    // 展开：让展开窗口的右下角对齐当前悬浮球
            CGRect ball = self.hostWindow.frame;
            CGRect e = self.expanded;
            e.origin = CGPointMake(CGRectGetMaxX(ball) - e.size.width, CGRectGetMaxY(ball) - e.size.height);
            self.expanded = [self clamp:e];
        }
        self.collapsed = c2;
        [self applyFrame];
    }
}

#pragma mark 拖动

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)g {
    if (![g isKindOfClass:UIPanGestureRecognizer.class]) return YES;
    if (self.collapsed) return YES;                                       // 悬浮球整块可拖
    CGPoint p = [g locationInView:self.web];
    return CGRectContainsPoint(self.dragRect, p);                         // 展开时只有拖拽栏可拖
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)a shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)b { return YES; }

- (void)onPan:(UIPanGestureRecognizer *)g {
    UIView *v = self.web;
    CGPoint p = [v convertPoint:[g locationInView:v] toCoordinateSpace:UIScreen.mainScreen.coordinateSpace];
    if (g.state == UIGestureRecognizerStateBegan) { self.panStart = p; self.panFrame = self.hostWindow.frame; }
    else if (g.state == UIGestureRecognizerStateChanged) {
        CGRect f = self.panFrame;
        f.origin.x += p.x - self.panStart.x; f.origin.y += p.y - self.panStart.y;
        f = [self clamp:f];
        self.hostWindow.frame = f;
        if (!self.collapsed) self.expanded = f;
    }
}

#pragma mark 加载状态

- (void)pageDidFinish { HLXLog(@"didFinish"); self.didRetryBaseURL = NO; [self.status removeFromSuperview]; [self callLayout]; [self reveal]; }
- (void)pageDidFail:(NSString *)why { HLXLog(@"didFail %@", why); self.status.text = [NSString stringWithFormat:@"加载失败（点一下复制）：\n%@", why]; [self reveal]; }
- (NSString *)diagnosticForError:(NSError *)e {
    return [NSString stringWithFormat:@"domain=%@ code=%ld description=%@ userInfo=%@", e.domain ?: @"?", (long)e.code, e.localizedDescription ?: @"?", e.userInfo ?: @{}];
}
- (void)webView:(WKWebView *)w didFinishNavigation:(WKNavigation *)n { [self pageDidFinish]; }
- (void)webView:(WKWebView *)w didFailNavigation:(WKNavigation *)n withError:(NSError *)e {
    NSString *detail = [self diagnosticForError:e];
    HLXLog(@"didFailNavigation %@", detail);
    self.status.text = [NSString stringWithFormat:@"页面导航失败：\n%@", detail]; [self reveal]; }
- (void)webView:(WKWebView *)w didFailProvisionalNavigation:(WKNavigation *)n withError:(NSError *)e {
    NSString *detail = [self diagnosticForError:e];
    HLXLog(@"didFailProvisionalNavigation %@", detail);
    // First retry the exact same embedded HTML without the synthetic HTTPS origin.
    // This isolates failures caused by origin/base-URL handling without changing the UI bundle.
    if (!self.didRetryBaseURL && self.htmlSource.length) {
        self.didRetryBaseURL = YES;
        self.status.text = [NSString stringWithFormat:@"首次加载失败，正在尝试兼容加载…\n%@", detail];
        HLXLog(@"retry embedded HTML with nil baseURL");
        [w loadHTMLString:self.htmlSource baseURL:nil];
        return;
    }
    self.status.text = [NSString stringWithFormat:@"网页加载失败：\n%@", detail]; [self reveal]; }
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)w {
    HLXLog(@"web content process terminated");
    if (!self.didRetryAfterWebContentTermination && self.htmlSource.length) {
        self.didRetryAfterWebContentTermination = YES;
        self.status.text = @"网页内容进程已退出，正在尝试重新载入…";
        [w reload];
        return;
    }
    self.status.text = @"网页内容进程再次退出，无法继续加载。请复制诊断信息。"; [self reveal]; }

#pragma mark 同步桥 + 原生对话框

- (void)webView:(WKWebView *)w runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)def
initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(NSString *))done {
    if ([prompt hasPrefix:kMark]) {
        [HLXBridge handlePayload:[prompt substringFromIndex:kMark.length] completion:done];
        return;
    }
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:prompt preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.text = def; }];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(nil); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(ac.textFields.firstObject.text ?: @""); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptAlertPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(void))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptConfirmPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(BOOL))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(NO); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(YES); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
@end


// ───────── 原生悬浮球（像 iGG / H5GG）─────────
@interface HLXBallVC : UIViewController @end
@implementation HLXBallVC
- (BOOL)prefersStatusBarHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }
@end

@interface HLXBallHandler : NSObject
@property (nonatomic, weak) UIWindow *win;
@end
@implementation HLXBallHandler
- (void)tap {
    // 让手势识别回调先退出，再创建面板 UIWindow / WKWebView，避免在触摸分发栈内
    // 同步启动一整套 UIKit + WebKit 初始化。
    dispatch_async(dispatch_get_main_queue(), ^{ [HLXOverlay.shared toggle]; });
}
- (void)pan:(UIPanGestureRecognizer *)g {
    UIWindow *w = self.win; if (!w) return;
    CGPoint t = [g translationInView:w.rootViewController.view];
    [g setTranslation:CGPointZero inView:w.rootViewController.view];
    CGSize sc = UIScreen.mainScreen.bounds.size;
    SEL sceneSel = NSSelectorFromString(@"windowScene");
    if ([w respondsToSelector:sceneSel]) {
        id scene = ((id(*)(id,SEL))objc_msgSend)(w, sceneSel);
        SEL spaceSel = NSSelectorFromString(@"coordinateSpace");
        if ([scene respondsToSelector:spaceSel]) {
            id space = ((id(*)(id,SEL))objc_msgSend)(scene, spaceSel);
            SEL boundsSel = NSSelectorFromString(@"bounds");
            if ([space respondsToSelector:boundsSel]) { CGRect b = ((CGRect(*)(id,SEL))objc_msgSend)(space, boundsSel); sc = b.size; }
        }
    }
    CGRect f = w.frame;
    f.origin.x = MAX(0, MIN(f.origin.x + t.x, sc.width - f.size.width));
    f.origin.y = MAX(0, MIN(f.origin.y + t.y, sc.height - f.size.height));
    w.frame = f;
    if (g.state == UIGestureRecognizerStateEnded) {      // 松手吸附到左右边缘
        f.origin.x = (CGRectGetMidX(f) < sc.width / 2) ? 4 : sc.width - f.size.width - 4;
        [UIView animateWithDuration:0.2 animations:^{ w.frame = f; }];
    }
}
@end

// ───────── 管理器 ─────────
@implementation HLXOverlay {
    UIWindow *_window; HLXRootVC *_vc; __weak UIWindow *_prevKey; UIWindow *_ball; id _ballHandler;
    // 记录打开面板前悬浮球是否可见；关闭面板时只恢复原本可见的球。
    BOOL _restoreBallAfterPanel;
}

+ (instancetype)shared {
    static HLXOverlay *o; static dispatch_once_t once;
    dispatch_once(&once, ^{ o = [HLXOverlay new]; });
    return o;
}

- (UIWindow *)makeWindowForScene:(id)preferredScene {
    UIWindow *w = nil;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        // 若已有悬浮球窗口，面板必须复用它所属的 scene，避免多 scene 环境串窗。
        UIWindowScene *scene = [preferredScene isKindOfClass:UIWindowScene.class] ? (UIWindowScene *)preferredScene : nil;
        if (!scene) {
            for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
                if (![s isKindOfClass:UIWindowScene.class]) continue;
                if (!scene || s.activationState == UISceneActivationStateForegroundActive) scene = (UIWindowScene *)s;
                if (s.activationState == UISceneActivationStateForegroundActive) break;
            }
        }
        w = scene ? [[UIWindow alloc] initWithWindowScene:scene] : [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    } else
#endif
    {
        w = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    }
    w.windowLevel = UIWindowLevelAlert + 2.0;
    w.backgroundColor = UIColor.clearColor;
    return w;
}

- (UIWindow *)makeWindow {
    return [self makeWindowForScene:nil];
}

- (void)showBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->_ball) { self->_ball.hidden = NO; return; }
        CGFloat D = 56; CGSize sc = UIScreen.mainScreen.bounds.size;
        UIWindow *w = [self makeWindow];
        w.windowLevel = UIWindowLevelAlert + 3.0;
        w.frame = CGRectMake(sc.width - D - 6, sc.height * 0.35, D, D);
        w.rootViewController = [HLXBallVC new];
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, D, D)];
        NSData *d = HLXSection("__hlxball");
        iv.image = d ? [UIImage imageWithData:d] : nil;
        iv.backgroundColor = iv.image ? UIColor.clearColor : [UIColor colorWithRed:0.18 green:0.49 blue:0.2 alpha:1];
        iv.contentMode = UIViewContentModeScaleAspectFill;
        iv.layer.cornerRadius = D / 2; iv.clipsToBounds = YES; iv.alpha = 0.92;
        iv.userInteractionEnabled = YES;
        HLXBallHandler *h = [HLXBallHandler new]; h.win = w; self->_ballHandler = h;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:h action:@selector(tap)];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:h action:@selector(pan:)];
        [tap requireGestureRecognizerToFail:pan];
        [iv addGestureRecognizer:tap];
        [iv addGestureRecognizer:pan];
        [w.rootViewController.view addSubview:iv];
        w.hidden = NO; self->_ball = w;
    });
}

- (void)hideBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        self->_ball.hidden = YES;
    });
}

- (void)toggleBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->_ball && !self->_ball.hidden) {
            self->_ball.hidden = YES;
        } else {
            [self showBall];
        }
    });
}

- (void)ensure {
    NSAssert(NSThread.isMainThread, @"HLXOverlay UI must be created on main thread");
    if (_window || _vc) return;

    UIWindow *newWindow = nil;
    HLXRootVC *newVC = nil;
    @try {
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
        newWindow = [self makeWindowForScene:self->_ball.windowScene];
#else
        newWindow = [self makeWindowForScene:nil];
#endif
        if (!newWindow) { HLXLog(@"ensure failed: makeWindow returned nil"); return; }
        /* UIWindow.windowScene is iOS 13+ and is absent from the iOS 11.4
           SDK used for legacy builds. Query it dynamically when available. */
        SEL windowSceneGetter = NSSelectorFromString(@"windowScene");
        BOOL hasWindowScene = NO;
        if ([newWindow respondsToSelector:windowSceneGetter]) {
            id scene = ((id(*)(id, SEL))objc_msgSend)(newWindow, windowSceneGetter);
            hasWindowScene = (scene != nil);
        }
        HLXLog(@"panel window created; scene=%@; frame=%@; level=%.1f",
               hasWindowScene ? @"attached" : @"none",
               NSStringFromCGRect(newWindow.frame),
               newWindow.windowLevel);
        newWindow.hidden = YES;
        newVC = [HLXRootVC new];
        newVC.hostWindow = newWindow;
        _window = newWindow;
        _vc = newVC;
        newWindow.rootViewController = newVC;
        // 在窗口显示前主动完成 loadView；初始化失败时回滚整个窗口状态。
        (void)newVC.view;
        [newVC applyFrame];
    } @catch (NSException *exception) {
        HLXLog(@"panel window creation exception: %@ %@", exception.name, exception.reason);
        newWindow.rootViewController = nil;
        newWindow.hidden = YES;
        _window = nil;
        _vc = nil;
        return;
    }

    [[NSNotificationCenter defaultCenter] addObserverForName:UIDeviceOrientationDidChangeNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
        __strong typeof(self) strongSelf = self;
        if (!strongSelf || !strongSelf->_vc) return;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (strongSelf->_vc) [strongSelf->_vc callLayout];
        });
    }];
}

- (void)show {
    HLXOnMain(^{
        HLXLog(@"show");

        // 必须在 ensure 之前记录并隐藏悬浮球：ensure 会创建 UIWindow、加载控制器，
        // 并同步触发 WKWebView 初始化。若等 ensure 返回再隐藏，生命周期顺序就反了。
        BOOL panelWasHidden = (self->_window == nil || self->_window.hidden);
        BOOL shouldRestoreBall = panelWasHidden && self->_ball && !self->_ball.hidden;
        if (shouldRestoreBall) {
            self->_restoreBallAfterPanel = YES;
            self->_ball.hidden = YES;
        }

        [self ensure];
        if (!self->_window || !self->_vc) {
            HLXLog(@"show aborted: panel initialization failed");
            // 初始化失败时回滚悬浮球状态，避免球被永久隐藏。
            if (self->_restoreBallAfterPanel) {
                self->_restoreBallAfterPanel = NO;
                if (self->_ball) self->_ball.hidden = NO;
            }
            return;
        }

        self->_window.hidden = NO;
        [self->_vc applyFrame];
        [self->_vc callLayout];
    });
}
- (void)hide {
    HLXOnMain(^{
        if (!self->_window) return;
        self->_window.hidden = YES;
        // 只恢复打开面板前本来就显示的球；若用户此前手动隐藏了球，不擅自显示。
        if (self->_restoreBallAfterPanel) {
            self->_restoreBallAfterPanel = NO;
            if (self->_ball) self->_ball.hidden = NO;
        }
    });
}
- (void)toggle {
    HLXOnMain(^{
        if (self->_window && !self->_window.hidden) [self hide];
        else [self show];
    });
}

@end
