#ifndef HLX_BOOTSTRAP_SHIM_H
#define HLX_BOOTSTRAP_SHIM_H

// Minimal iOS SDK declarations for the bootstrap APIs used by Huluxia.
// These declarations avoid depending on <servers/bootstrap.h>, which is not
// shipped as a public header in every iPhoneOS SDK despite the symbols being
// available to system daemons.
#include <mach/mach.h>
#include <mach/message.h>
#include <sys/types.h>

#define HLX_BOOTSTRAP_MAX_NAME_LEN 128
typedef char hlx_bootstrap_name_t[HLX_BOOTSTRAP_MAX_NAME_LEN];

#ifdef __cplusplus
extern "C" {
#endif
extern mach_port_t bootstrap_port;
kern_return_t bootstrap_check_in(mach_port_t bp,
                                 const hlx_bootstrap_name_t service_name,
                                 mach_port_t *sp);
kern_return_t bootstrap_look_up(mach_port_t bp,
                                const hlx_bootstrap_name_t service_name,
                                mach_port_t *sp);
#ifdef __cplusplus
}
#endif

// audit_token_t is defined by Mach. XNU's BSM audit-token ABI stores the
// sending PID in slot 5; keep this accessor local so the iOS build does not
// need the macOS-only <bsm/libbsm.h> public header.
static inline pid_t HLXAuditTokenPID(audit_token_t token) {
    return (pid_t)token.val[5];
}

#endif /* HLX_BOOTSTRAP_SHIM_H */
