#import <Foundation/Foundation.h>
@interface HLXDrawOverlay : NSObject
+ (void)setCommands:(NSArray *)commands;
+ (void)clear;
@end
