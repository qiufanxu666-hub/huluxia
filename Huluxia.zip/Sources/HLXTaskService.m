#import "HLXTaskService.h"
#import "HLXBootstrapShim.h"
#import <mach/mach_error.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

static const char *kHLXMemoryServiceName = "com.huluxia.memoryd";
static const mach_msg_id_t kHLXMemoryRequestID = 0x484C5801;
static const mach_msg_id_t kHLXMemoryReplyID   = 0x484C5802;
static const mach_msg_timeout_t kHLXServiceTimeoutMS = 2500;

typedef struct {
    mach_msg_header_t header;
    int32_t pid;
    uint32_t version;
} HLXMemoryRequest;

typedef struct {
    mach_msg_header_t header;
    mach_msg_body_t body;
    mach_msg_port_descriptor_t taskPort;
    int32_t result;
    uint32_t version;
} HLXMemoryReply;

// mach_msg() uses the same buffer for send and receive when SEND|RCV are
// combined. The receive buffer must be at least as large as the reply. A union
// avoids overwriting a smaller request stack object with the larger reply.
typedef struct {
    union {
        HLXMemoryRequest request;
        HLXMemoryReply reply;
    } payload;
    // Reserve space for the default Mach receive trailer as well as the reply.
    uint8_t trailerSpace[256];
} HLXMemoryMessageBuffer;

kern_return_t HLXTaskServiceCopyTaskPort(pid_t pid, mach_port_t *taskPort) {
    if (taskPort) *taskPort = MACH_PORT_NULL;
    if (!taskPort || pid <= 1) return KERN_INVALID_ARGUMENT;

    mach_port_t servicePort = MACH_PORT_NULL;
    kern_return_t kr = bootstrap_look_up(bootstrap_port, kHLXMemoryServiceName, &servicePort);
    if (kr != KERN_SUCCESS || servicePort == MACH_PORT_NULL)
        return kr == KERN_SUCCESS ? KERN_NOT_FOUND : kr;

    mach_port_t replyPort = MACH_PORT_NULL;
    kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &replyPort);
    if (kr != KERN_SUCCESS) {
        mach_port_deallocate(mach_task_self(), servicePort);
        return kr;
    }

    HLXMemoryMessageBuffer buffer;
    memset(&buffer, 0, sizeof(buffer));
    HLXMemoryRequest *request = &buffer.payload.request;
    request->header.msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, MACH_MSG_TYPE_MAKE_SEND_ONCE);
    request->header.msgh_size = sizeof(*request);
    request->header.msgh_remote_port = servicePort;
    request->header.msgh_local_port = replyPort;
    request->header.msgh_id = kHLXMemoryRequestID;
    request->pid = (int32_t)pid;
    request->version = 1;

    // One bounded round trip. If the daemon is absent or unresponsive, leave
    // the current memory target untouched and surface the concrete Mach error.
    kr = mach_msg(&request->header,
                  MACH_SEND_MSG | MACH_RCV_MSG | MACH_SEND_TIMEOUT | MACH_RCV_TIMEOUT,
                  request->header.msgh_size,
                  (mach_msg_size_t)sizeof(buffer),
                  replyPort,
                  kHLXServiceTimeoutMS,
                  MACH_PORT_NULL);

    mach_port_deallocate(mach_task_self(), servicePort);
    if (kr != MACH_MSG_SUCCESS) {
        mach_port_destroy(mach_task_self(), replyPort);
        return kr;
    }

    HLXMemoryReply *reply = &buffer.payload.reply;
    if (reply->header.msgh_id != kHLXMemoryReplyID ||
        reply->header.msgh_size < offsetof(HLXMemoryReply, version) + sizeof(reply->version) ||
        reply->header.msgh_size > sizeof(buffer) || reply->version != 1) {
        mach_port_destroy(mach_task_self(), replyPort);
        return KERN_FAILURE;
    }

    if (reply->result != KERN_SUCCESS) {
        kern_return_t result = (kern_return_t)reply->result;
        mach_port_destroy(mach_task_self(), replyPort);
        return result;
    }

    if (reply->header.msgh_size < sizeof(HLXMemoryReply) ||
        !(reply->header.msgh_bits & MACH_MSGH_BITS_COMPLEX) ||
        reply->body.msgh_descriptor_count != 1 ||
        reply->taskPort.type != MACH_MSG_PORT_DESCRIPTOR ||
        reply->taskPort.name == MACH_PORT_NULL) {
        // A malformed response may still have delivered a port descriptor.
        // Release it if its fields are safely covered by msgh_size.
        if ((reply->header.msgh_bits & MACH_MSGH_BITS_COMPLEX) &&
            reply->header.msgh_size >= sizeof(HLXMemoryReply) &&
            reply->body.msgh_descriptor_count > 0 &&
            reply->taskPort.type == MACH_MSG_PORT_DESCRIPTOR &&
            reply->taskPort.name != MACH_PORT_NULL)
            mach_port_deallocate(mach_task_self(), reply->taskPort.name);
        mach_port_destroy(mach_task_self(), replyPort);
        return KERN_FAILURE;
    }

    mach_port_type_t type = 0;
    kr = mach_port_type(mach_task_self(), reply->taskPort.name, &type);
    if (kr != KERN_SUCCESS || !(type & MACH_PORT_TYPE_SEND)) {
        if (reply->taskPort.name != MACH_PORT_NULL)
            mach_port_deallocate(mach_task_self(), reply->taskPort.name);
        mach_port_destroy(mach_task_self(), replyPort);
        return kr == KERN_SUCCESS ? KERN_INVALID_RIGHT : kr;
    }

    *taskPort = reply->taskPort.name;
    mach_port_destroy(mach_task_self(), replyPort);
    return KERN_SUCCESS;
}
