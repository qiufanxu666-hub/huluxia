#import "HLXTouch.h"
#import "HLXSpeed.h"
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <mach/mach_time.h>
#import <objc/message.h>
#import <math.h>

typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDEventSystemClient *IOHIDEventSystemClientRef;

typedef IOHIDEventRef (*HLXCreateDigitizerFn)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
typedef IOHIDEventRef (*HLXCreateFingerFn)(CFAllocatorRef,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t,double,double,double,double,double,Boolean,Boolean,uint32_t);
typedef void (*HLXAppendEventFn)(IOHIDEventRef,IOHIDEventRef,uint32_t);
typedef void (*HLXSetIntegerFn)(IOHIDEventRef,uint32_t,int64_t);
typedef void (*HLXSetFloatFn)(IOHIDEventRef,uint32_t,double);
typedef void (*HLXSetSenderFn)(IOHIDEventRef,uint64_t);
typedef IOHIDEventSystemClientRef (*HLXClientCreateFn)(CFAllocatorRef);
typedef void (*HLXClientDispatchFn)(IOHIDEventSystemClientRef,IOHIDEventRef);
/* BackBoardServices private SPI. The final argument types are significant. */
typedef void (*HLXSetDigitizerInfoFn)(IOHIDEventRef,uint32_t,uint8_t,uint8_t,CFStringRef,CFTimeInterval,float);

static HLXCreateDigitizerFn pCreateDigitizer;
static HLXCreateFingerFn pCreateFinger;
static HLXAppendEventFn pAppend;
static HLXSetIntegerFn pSetInt;
static HLXSetFloatFn pSetFloat;
static HLXSetSenderFn pSetSender;
static HLXClientCreateFn pClientCreate;
static HLXClientDispatchFn pClientDispatch;
static HLXSetDigitizerInfoFn pSetDigitizerInfo;
static IOHIDEventSystemClientRef gClient;
static dispatch_once_t gOnce;

#define kFieldDisplayIntegrated 0x000B0019u
#define kFieldMajor 0x000B0014u
#define kFieldMinor 0x000B0015u
#define kDigitizerRange (1u << 0)
#define kDigitizerTouch (1u << 1)
#define kDigitizerPosition (1u << 2)
#define kTransducerFinger 2u
#define kTouchIdentity 1u

static void HLXLoad(void) {
    dispatch_once(&gOnce, ^{
        void *io = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
        if (io) {
            pCreateDigitizer = (HLXCreateDigitizerFn)dlsym(io, "IOHIDEventCreateDigitizerEvent");
            pCreateFinger = (HLXCreateFingerFn)dlsym(io, "IOHIDEventCreateDigitizerFingerEvent");
            pAppend = (HLXAppendEventFn)dlsym(io, "IOHIDEventAppendEvent");
            pSetInt = (HLXSetIntegerFn)dlsym(io, "IOHIDEventSetIntegerValue");
            pSetFloat = (HLXSetFloatFn)dlsym(io, "IOHIDEventSetFloatValue");
            pSetSender = (HLXSetSenderFn)dlsym(io, "IOHIDEventSetSenderID");
            pClientCreate = (HLXClientCreateFn)dlsym(io, "IOHIDEventSystemClientCreate");
            pClientDispatch = (HLXClientDispatchFn)dlsym(io, "IOHIDEventSystemClientDispatchEvent");
        }
        void *bks = dlopen("/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices", RTLD_NOW);
        if (bks) pSetDigitizerInfo = (HLXSetDigitizerInfoFn)dlsym(bks, "BKSHIDEventSetDigitizerInfo");
        if (pClientCreate) gClient = pClientCreate(kCFAllocatorDefault);
    });
}

static UIWindow *HLXActiveWindow(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (!app) return nil;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in app.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) if (w.isKeyWindow && !w.hidden) return w;
        }
    }
#endif
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    if (app.keyWindow && !app.keyWindow.hidden) return app.keyWindow;
#pragma clang diagnostic pop
    for (UIWindow *w in app.windows) if (w.isKeyWindow && !w.hidden) return w;
    return app.windows.firstObject;
}

static uint32_t HLXWindowContextID(UIWindow *window) {
    if (!window) return 0;
    SEL sel = NSSelectorFromString(@"_contextId");
    if (![window respondsToSelector:sel]) return 0;
    @try {
        return (uint32_t)((NSUInteger(*)(id,SEL))objc_msgSend)(window, sel);
    } @catch (__unused NSException *e) {
        return 0;
    }
}

static BOOL HLXIsSpringBoard(void) {
    return [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"];
}

static BOOL HLXSymbolsReady(void) {
    HLXLoad();
    return pCreateDigitizer && pCreateFinger && pAppend;
}

/* Call only on the main thread. Coordinates are UIKit logical points in the
   active window's coordinate space, not normalized 0..1 HID coordinates. */
static BOOL HLXSendNow(CGPoint point, uint32_t eventMask, BOOL touching) {
    if (!HLXSymbolsReady()) return NO;
    UIApplication *app = UIApplication.sharedApplication;
    UIWindow *window = HLXActiveWindow();
    uint32_t contextID = HLXWindowContextID(window);
    SEL enqueue = NSSelectorFromString(@"_enqueueHIDEvent:");

    BOOL appCanEnqueue = app && [app respondsToSelector:enqueue] && contextID != 0 && pSetDigitizerInfo;
    BOOL springBoardCanDispatch = HLXIsSpringBoard() && gClient && pClientDispatch;
    if (!appCanEnqueue && !springBoardCanDispatch) return NO;

    CGSize bounds = window ? window.bounds.size : UIScreen.mainScreen.bounds.size;
    if (!isfinite(point.x) || !isfinite(point.y) || point.x < 0 || point.y < 0) return NO;
    /* Accept either documented UIKit points or physical-pixel coordinates
       commonly supplied by older GameGuardian-style scripts. */
    if ((point.x > bounds.width || point.y > bounds.height) && UIScreen.mainScreen.scale > 1.0) {
        CGSize native = UIScreen.mainScreen.nativeBounds.size;
        CGFloat scale = UIScreen.mainScreen.scale;
        CGPoint pixelPoint = CGPointMake(point.x / scale, point.y / scale);
        if (pixelPoint.x <= bounds.width && pixelPoint.y <= bounds.height &&
            point.x <= MAX(native.width, native.height) &&
            point.y <= MAX(native.width, native.height)) point = pixelPoint;
    }
    if (point.x > bounds.width || point.y > bounds.height) return NO;

    uint64_t timestamp = [HLXSpeed realMachAbsoluteTime];
    IOHIDEventRef parent = pCreateDigitizer(kCFAllocatorDefault, timestamp,
        3, 0, 0, eventMask, 0, 0, 0, 0, 0, 0, touching, touching, 0);
    if (!parent) return NO;

    /* Mark as an integrated display digitizer, then attach a single finger. */
    if (pSetInt) pSetInt(parent, kFieldDisplayIntegrated, 1);
    IOHIDEventRef finger = pCreateFinger(kCFAllocatorDefault, timestamp,
        3, kTouchIdentity, kTouchIdentity, eventMask,
        point.x, point.y, 0, touching ? 0.5 : 0, 0,
        touching, touching, 0);
    BOOL built = finger != NULL;
    if (finger) {
        if (pSetFloat) {
            pSetFloat(finger, kFieldMajor, 4.0);
            pSetFloat(finger, kFieldMinor, 4.0);
        }
        pAppend(parent, finger, 0);
        CFRelease(finger);
    }

    if (built) {
        if (pSetSender) pSetSender(parent, 0xDEFACEDBEEFFECE5ULL);
        if (springBoardCanDispatch) {
            /* SpringBoard is the injector: system-client dispatch lets BackBoard
               deliver to the frontmost app instead of SpringBoard's own window. */
            pClientDispatch(gClient, parent);
        } else if (appCanEnqueue) {
            /* In an injected target app, bind to that app's active window. */
            pSetDigitizerInfo(parent, contextID, 0, 0, NULL, 0, 0);
            ((void(*)(id,SEL,IOHIDEventRef))objc_msgSend)(app, enqueue, parent);
        }
    }
    CFRelease(parent);
    return built;
}

static BOOL HLXOnMainSend(CGPoint point, uint32_t mask, BOOL touching) {
    if (NSThread.isMainThread) return HLXSendNow(point, mask, touching);
    __block BOOL sent = NO;
    dispatch_sync(dispatch_get_main_queue(), ^{ sent = HLXSendNow(point, mask, touching); });
    return sent;
}

@implementation HLXTouch

+ (NSDictionary *)status {
    __block NSDictionary *result;
    void (^read)(void) = ^{
        BOOL symbols = HLXSymbolsReady();
        UIApplication *app = UIApplication.sharedApplication;
        UIWindow *window = HLXActiveWindow();
        uint32_t contextID = HLXWindowContextID(window);
        BOOL enqueue = app && [app respondsToSelector:NSSelectorFromString(@"_enqueueHIDEvent:")] && pSetDigitizerInfo;
        BOOL sb = HLXIsSpringBoard() && gClient && pClientDispatch;
        NSString *reason = @"";
        if (!symbols) reason = @"缺少 IOHID 事件创建/组合符号";
        else if (!enqueue && !sb) reason = @"当前进程缺少可用的 HID 派发入口或 BKSHIDEventSetDigitizerInfo";
        else if (app && [app respondsToSelector:NSSelectorFromString(@"_enqueueHIDEvent:")] && contextID == 0 && !sb) reason = @"当前 KeyWindow 没有有效 _contextId";
        result = @{
            @"available": @((symbols && ((enqueue && contextID != 0) || sb))),
            @"path": sb ? @"IOHIDEventSystemClientDispatchEvent" : (enqueue ? @"UIApplication._enqueueHIDEvent" : @"none"),
            @"contextID": @(contextID),
            @"windowWidth": @(window ? window.bounds.size.width : 0),
            @"windowHeight": @(window ? window.bounds.size.height : 0),
            @"reason": reason
        };
    };
    if (NSThread.isMainThread) read(); else dispatch_sync(dispatch_get_main_queue(), read);
    return result ?: @{@"available": @NO, @"path": @"none", @"contextID": @0, @"reason": @"无法读取 UIApplication 状态"};
}

+ (BOOL)available { return [self.status[@"available"] boolValue]; }
+ (BOOL)down:(CGPoint)p { return HLXOnMainSend(p, kDigitizerRange | kDigitizerTouch, YES); }
+ (BOOL)move:(CGPoint)p { return HLXOnMainSend(p, kDigitizerPosition | kDigitizerRange | kDigitizerTouch, YES); }
+ (BOOL)up:(CGPoint)p { return HLXOnMainSend(p, kDigitizerRange | kDigitizerTouch, NO); }

+ (BOOL)tap:(CGPoint)p {
    if (![self down:p]) return NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 60 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        HLXSendNow(p, kDigitizerRange | kDigitizerTouch, NO);
    });
    return YES;
}

+ (BOOL)longPress:(CGPoint)p ms:(int)ms {
    if (![self down:p]) return NO;
    int duration = MAX(100, MIN(ms, 10000));
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)duration * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
        HLXSendNow(p, kDigitizerRange | kDigitizerTouch, NO);
    });
    return YES;
}

+ (BOOL)swipe:(CGPoint)from to:(CGPoint)to ms:(int)ms {
    int duration = MAX(80, MIN(ms, 10000));
    if (![self down:from]) return NO;
    int steps = MAX(5, MIN(120, duration / 16));
    for (int i = 1; i <= steps; i++) {
        CGFloat fraction = (CGFloat)i / (CGFloat)steps;
        CGPoint point = CGPointMake(from.x + (to.x - from.x) * fraction,
                                    from.y + (to.y - from.y) * fraction);
        BOOL final = (i == steps);
        int64_t delay = (int64_t)duration * i / steps;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
            HLXSendNow(point,
                final ? (kDigitizerRange | kDigitizerTouch)
                      : (kDigitizerPosition | kDigitizerRange | kDigitizerTouch),
                !final);
        });
    }
    return YES;
}
@end
