#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface HLXTouchPoints : NSObject
+ (void)setPoints:(NSArray<NSValue *> *)points;
+ (NSArray<NSValue *> *)points;
+ (void)setVisible:(BOOL)visible;
+ (void)setRunMode:(BOOL)runMode;
+ (void)setMode:(NSString *)mode;
+ (void)clear;
@end
