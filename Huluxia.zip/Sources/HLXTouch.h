// HLXTouch.h — 统一的原生 HID 触摸入口。私有 SPI 的可用性取决于系统版本、进程权限和目标 App。
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface HLXTouch : NSObject
+ (BOOL)available;
+ (NSDictionary *)status;
+ (BOOL)tap:(CGPoint)p;
+ (BOOL)longPress:(CGPoint)p ms:(int)ms;
+ (BOOL)swipe:(CGPoint)a to:(CGPoint)b ms:(int)ms;
+ (BOOL)down:(CGPoint)p;
+ (BOOL)move:(CGPoint)p;
+ (BOOL)up:(CGPoint)p;
// NSValue(valueWithCGPoint:) 数组，最多 5 个触点；multiTap 会在同一 HID 事件中同时按下。
+ (BOOL)multiTap:(NSArray<NSValue *> *)points holdMs:(int)ms;
+ (BOOL)multiDown:(NSArray<NSValue *> *)points;
+ (BOOL)multiMove:(NSArray<NSValue *> *)points;
+ (BOOL)multiUp:(NSArray<NSValue *> *)points;
+ (void)cancelAll;
@end
