// HLXTouch.h — 通过系统可用的 HID 派发路径排队触摸事件；不保证第三方 App 接受私有事件。
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface HLXTouch : NSObject
+ (BOOL)available;
+ (NSDictionary *)status;
+ (BOOL)tap:(CGPoint)p;
+ (BOOL)longPress:(CGPoint)p ms:(int)ms;
+ (BOOL)swipe:(CGPoint)a to:(CGPoint)b ms:(int)ms;
+ (BOOL)down:(CGPoint)p;
+ (BOOL)move:(CGPoint)p;
+ (BOOL)up:(CGPoint)p;
@end
