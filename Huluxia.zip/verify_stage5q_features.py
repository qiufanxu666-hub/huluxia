#!/usr/bin/env python3
from pathlib import Path
import re

root = Path(__file__).resolve().parent
memory = (root / 'Sources/HLXMemory.m').read_text()
speed = (root / 'Sources/HLXSpeed.m').read_text()
speed_h = (root / 'Sources/HLXSpeed.h').read_text()
legacy_speed = (root / 'Sources/HLXSpeedLegacy.m').read_text()
tweak = (root / 'Sources/Tweak.m').read_text()
control = (root / 'control').read_text()
launcher = (root / 'Launcher/main.m').read_text()
readme = (root / 'README.md').read_text()
verify = (root / 'verify_build.sh').read_text()
workflow = (root / '.github/workflows/build.yml').read_text()

checks = {
    'Debian package identifier is com.huluxia.stz-fish': 'Package: com.huluxia.stz-fish' in control,
    'Sileo display name is 葫芦侠': re.search(r'^Name: 葫芦侠$', control, re.M) is not None,
    'Sileo description matches the requested author copy': 'Description: 时天尊-fish制作，可修改各种软件游戏，让你重温当年的葫芦侠。' in control,
    'Sileo author and maintainer are 时天尊-fish': 'Author: 时天尊-fish' in control and 'Maintainer: 时天尊-fish' in control,
    'Sileo description no longer contains 原生版 or TrollStore': '原生版' not in control and 'TrollStore' not in control,
    'Launcher user-facing description no longer mentions TrollStore': 'TrollStore' not in launcher,
    'Project title no longer says 原生版': not readme.splitlines()[0].find('原生版') >= 0,
    'DEB verifier checks the new package identifier': 'com.huluxia.stz-fish' in verify,
    'Memory process selection requires an injected agent before task_for_pid': memory.index('agentStatusForPid:pid') < memory.index('tfp(mach_task_self(), pid, &candidate)'),
    'Uninjected target is rejected with a clear non-crashing explanation': '当前不会对未注入进程调用 task_for_pid' in memory,
    'Task port is validated using task_info before replacing current target': 'task_info(candidate, TASK_BASIC_INFO' in memory,
    'PID reuse is checked after acquiring the task port': '目标进程 PID %d 在附加期间发生变化' in memory,
    'Process table allocation retries on ENOMEM': 'attempt < 4' in memory and 'savedErrno != ENOMEM' in memory,
    'Agent status distinguishes not-injected, active and hook-failed': 'agentStatusForPid' in speed_h and 'publishAgentStatus(me, 2)' in speed and 'publishAgentStatus(me, 1)' in speed,
    'Failed injected speed hook writes a diagnostic log': '/var/mobile/huluxia_speed.log' in speed,
    'Side-loaded injection has a checked no-Substrate rebinding path': 'HLXWriteImportPointer' in speed and 'gRebindCounts[0] > 0' in speed and 'gRebindCounts[1] > 0' in speed and 'gRebindCounts[2] > 0' in speed,
    'MSHookFunction path verifies original function pointers': '!o_mach_absolute_time || !o_clock_gettime || !o_gettimeofday' in speed,
    'Clock Hook installation is serialized and failed partial installs are terminal': 'gInstallLock' in speed and 'gInstallState = ok ? 2 : 3' in speed and '此前发生过部分/失败的时钟 Hook 安装' in speed,
    'Injected app initializes its local agent': '[HLXSpeed startAgent]' in tweak,
    'Legacy speed backend implements the process-agent status API': '+ (int)agentStatusForPid:(pid_t)pid' in legacy_speed,
    'Workflow selects Stage 5Q before Stage 5P': workflow.index('Huluxia_1.0.0_阶段5Q_iOS15进程安全与注入变速修复.zip') < workflow.index('Huluxia_1.0.0_阶段5P_原生悬浮触摸点与HTML桥接修复.zip'),
    'Workflow runs Stage 5Q validation': 'python3 verify_stage5q_features.py' in workflow,
}

for label, ok in checks.items():
    print(('PASS: ' if ok else 'FAIL: ') + label)
raise SystemExit(0 if all(checks.values()) else 1)
