#!/usr/bin/env bash
# Add a game/app bundle identifier to the jailbreak tweak injection filter.
set -euo pipefail
cd "$(dirname "$0")"
if [[ $# -ne 1 ]]; then
  echo "用法: $0 <目标App的Bundle ID>" >&2
  echo "示例: $0 com.example.game" >&2
  exit 2
fi
BUNDLE_ID="$1"
if [[ ! "$BUNDLE_ID" =~ ^[A-Za-z0-9][A-Za-z0-9.-]*$ || "$BUNDLE_ID" != *.* ]]; then
  echo "无效的 Bundle ID: $BUNDLE_ID" >&2
  exit 2
fi
python3 - "$BUNDLE_ID" <<'PY'
import plistlib, sys
from pathlib import Path
path = Path('Huluxia.plist')
bundle = sys.argv[1]
with path.open('rb') as f:
    data = plistlib.load(f)
filters = data.setdefault('Filter', {})
bundles = filters.setdefault('Bundles', [])
if 'com.apple.springboard' not in bundles:
    bundles.insert(0, 'com.apple.springboard')
if bundle not in bundles:
    bundles.append(bundle)
with path.open('wb') as f:
    plistlib.dump(data, f, fmt=plistlib.FMT_XML, sort_keys=False)
print('已配置注入目标：')
for item in bundles:
    print(' -', item)
PY
plutil -lint Huluxia.plist >/dev/null 2>&1 || python3 - <<'PY'
import plistlib
with open('Huluxia.plist','rb') as f: plistlib.load(f)
PY
