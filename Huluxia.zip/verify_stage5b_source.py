#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(__file__).resolve().parent
s = (root/'Sources/HLXOverlay.m').read_text()
mk = (root/'Makefile').read_text()
b = (root/'build_dylib.sh').read_text()
w = (root/'.github/workflows/build.yml').read_text()
checks = {
    'embedded HTML retained for retry': 'self.htmlSource = html;' in s,
    'provisional navigation error logs domain/code/userInfo': 'diagnosticForError:' in s and 'didFailProvisionalNavigation %@' in s,
    'one-time nil-baseURL compatibility retry': 'retry embedded HTML with nil baseURL' in s and 'if (!self.didRetryBaseURL' in s,
    'one-time WebContent process reload': 'didRetryAfterWebContentTermination' in s and '[w reload];' in s,
    'rootful modern build has arm64 and arm64e': 'ARCHS := arm64 arm64e' in mk,
    'standalone dylib builds both modern slices': 'for ARCH in arm64 arm64e;' in b and 'lipo -create' in b,
    'release folder includes legacy 32-bit package': 'cp out/*_legacy_armv7_arm64.deb out/Huluxia_Release/越狱版/' in w,
}
for k,v in checks.items(): print(('PASS: ' if v else 'FAIL: ')+k)
sys.exit(0 if all(checks.values()) else 1)
