#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root = Path(__file__).resolve().parent
s = (root / 'Sources/HLXOverlay.m').read_text()
mk = (root / 'Makefile').read_text()
build = (root / 'build_dylib.sh').read_text()
checks = {
    'native diagnostic branch is opt-in': '#if defined(HLX_NATIVE_DIAGNOSTIC)' in s,
    'diagnostic branch avoids WKWebView creation': 'stage4e native diagnostic panel loaded; WebKit bypassed' in s and s.index('stage4e native diagnostic panel loaded; WebKit bypassed') < s.index('#else\n    gRoot = self;', s.index('- (void)loadView')),
    'diagnostic panel has explicit close action': 'dismissNativeDiagnosticPanel' in s and '关闭诊断面板' in s,
    'normal HTML/WebKit implementation remains in else branch': '#else\n    gRoot = self;' in s and 'loadHTMLString:html' in s,
    'Theos build flag is optional': 'HLX_NATIVE_DIAGNOSTIC' in mk and '-DHLX_NATIVE_DIAGNOSTIC=1' in mk,
    'standalone dylib builds universal slices and keeps diagnostic switch optional': 'HLX_NATIVE_DIAGNOSTIC' in build and 'COMMON_ARGS' in build and 'for ARCH in arm64 arm64e;' in build and 'lipo -create' in build and 'DIAG_FLAGS' not in build,
    'GitHub Actions exposes diagnostic build switch': 'native_diagnostic:' in (root/'.github/workflows/build.yml').read_text(),
    'WebKit smoke branch uses minimal local HTML': 'HLX_WEBKIT_SMOKE_DIAGNOSTIC' in s and 'WKWebView 已完成本地 HTML 渲染' in s,
    'WebKit smoke branch excludes production JS bridge': '#if !defined(HLX_WEBKIT_SMOKE_DIAGNOSTIC)' in s,
    'Theos exposes WebKit smoke macro': 'HLX_WEBKIT_SMOKE_DIAGNOSTIC' in mk,
    'standalone dylib forwards WebKit smoke macro': 'HLX_WEBKIT_SMOKE_DIAGNOSTIC' in build,
    'Actions exposes B-layer diagnostic input': 'webkit_smoke_diagnostic:' in (root/'.github/workflows/build.yml').read_text(),
    'GitHub Actions prioritizes Stage 5H archive over legacy archives': (
        'Huluxia_1.0.0_阶段5H_构建检查断言修复.zip' in (root/'.github/workflows/build.yml').read_text()
        and (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5H_构建检查断言修复.zip')
            < (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5F_WebKit最小页面诊断与构建分层.zip')
        and (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5H_构建检查断言修复.zip')
            < (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5G_WebKit加载异常保护.zip')
        and (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5G_WebKit加载异常保护.zip')
            < (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5F_WebKit最小页面诊断与构建分层.zip')
        and (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5F_WebKit最小页面诊断与构建分层.zip')
            < (root/'.github/workflows/build.yml').read_text().index('Huluxia_1.0.0_阶段5E_工作流选源修复与iOS16诊断.zip')
    ),
}
for label, ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ') + label)
h = hashlib.sha256((root/'Sources/HLXSpeed.m').read_bytes()).hexdigest()
expected = '65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911'
checks['stage 1 speed baseline unchanged'] = h == expected
print(('PASS: ' if h == expected else 'FAIL: ') + 'stage 1 speed baseline unchanged (' + h + ')')
sys.exit(0 if all(checks.values()) else 1)
