# 葫芦侠 1.0.0 — Stage 5W

本阶段以 Stage 5Q 为底稿，保留 SpringBoard-only 注入范围；不向所有 UIKit App 自动注入葫芦侠 DYLIB，也不要求逐个填写目标 App Bundle ID。

## 本阶段改动

- 新增 `HuluxiaD` LaunchDaemon 和 `com.huluxia.memoryd` Mach IPC 服务。跨进程 task port 请求由服务进程执行；SpringBoard 只提交 PID 请求并接收 task port。
- 服务端从 Mach audit trailer 取得请求方 PID，并验证请求来源路径为 SpringBoard；校验目标进程路径在获取 task port 前后没有变化。
- 进程列表仍直接枚举系统可见 PID，点击后尝试通过服务附加。不能获得 task port 的进程会给出具体错误，保留原有目标，不会把失败当成功。
- 原生屏幕悬浮点改为同步主线程更新；运行模式窗口穿透，只有编辑/滑动模式接收点位手势。
- 连点器新增“到游戏画面拖动定位”流程：收起当前面板、显示原生悬浮球和屏幕点位；点悬浮球返回同一个连点器运行面板。删除要求手工输入初始 X/Y 的步骤。
- HID 手指子事件掩码按 DOWN/MOVE/UP 分相构造；窗口逻辑坐标直接传递给 Finger 事件，并在状态接口显示掩码和异步派发限制。
- `HLXSpeed.m` 保持 Stage 5Q 原样。

## 安装和限制

这是越狱 DEB 的辅助服务实现。当前服务仅提供 task port；实际附加仍受 iOS 版本、Dopamine/ElleKit 权限状态、目标进程保护和 task_for_pid 策略限制。`task_for_pid-allow` entitlement 不保证能访问所有进程，也不会绕过受保护进程的系统限制。若返回权限错误，列表仍可显示该进程，但内存读写不会生效。

TrollStore IPA / standalone DYLIB 构建没有安装此 LaunchDaemon，因此不提供此阶段的跨进程服务能力；自身进程功能仍按原方式运行。

HID 私有接口是异步入口，没有系统向本插件提供“前台游戏已收到触摸”的回执。代码返回只表示本地事件构造和提交路径已执行，不能代替 iOS 15 真机验证。

## 构建

唯一 GitHub Actions 工作流位于 `.github/workflows/build.yml`。GitHub Actions 编译结果和 ZIP 静态检查不能代替 iOS 15 Dopamine 设备验证。请先用测试 App 测试，不要在生产游戏/主设备上直接假定所有 PID 都可附加。


## Stage 5U

本阶段增加 DWORD/WORD/BYTE/FLOAT 快捷类型、UTF-8 字符串 NUL 终止写入、修改后回读确认、I64/U64 精确字符串比较，以及 100x 变速上限。真实应用图标读取和 TrollStore 跨进程权限仍需后续实现/真机验证，不能视为已完成。详见 `PATCH_NOTES_STAGE5U.txt`。


## Stage 5V

进程列表原生图标读取结果通过 JS bridge 传递到网页列表；TrollStore 运行时按普通 App 安装容器过滤进程，并尝试直接申请 task port。此权限受系统签名/内核策略限制，不保证所有目标可访问。

## Stage 5W

修复 `Daemon/Makefile` 漏掉 Theos `common.mk` 的构建问题。该缺失会令子工程 `clean` 阶段的 `THEOS_OBJ_DIR` 未初始化，导致 GitHub Actions 出现 `rm: : No such file or directory`。新增 `verify_stage5w_buildfix.py`，在 Theos build 前检查 Daemon 和 Launcher 的 common.mk 初始化。
