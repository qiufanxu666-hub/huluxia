# 葫芦侠 1.0.0
当前源码阶段：Stage 5R（全 UIKit 应用注入与直接进程选择）。

本工程输出越狱 DEB、独立 `Huluxia.dylib`，以及一个内嵌 DYLIB 的配套 IPA。

## 阶段 5Q：iOS 15 进程切换保护与注入变速修复

- Sileo 包名：`com.huluxia.stz-fish`；显示名称：`葫芦侠`；作者：`时天尊-fish`。
- Sileo 描述：时天尊-fish制作，可修改各种软件游戏，让你重温当年的葫芦侠。
- 进程选择先检查目标 App 是否实际加载葫芦侠代理；未注入时明确提示配置 Bundle ID，不再从 SpringBoard 对未注入进程直接调用 `task_for_pid`。
- 获得 task port 后增加 `mach_port_type`、`task_info` 和 PID 路径复核；进程列表在系统进程表变化时会重试分配。
- 注入版变速增加 Hook 安装结果校验、无 Substrate 导入指针重绑定检查和 `/var/mobile/huluxia_speed.log` 诊断日志。
- 注意：越狱插件默认仍只注入 SpringBoard。要对某个游戏使用内存/变速功能，必须将该游戏 Bundle ID 加入 `Huluxia.plist` Filter 并重新构建；不会默认注入所有系统进程。

## 本次修复

- 安装或重启 SpringBoard 后不再自动显示悬浮球。
- 桌面图标打开的是控制页；只有点击“显示 / 隐藏悬浮球”按钮才发送悬浮球切换通知。
- 悬浮球和功能面板使用不同通知，悬浮球点击后再打开/关闭面板。
- 删除启动器启动时自动发送切换通知和 3 秒后调用私有 `UIApplication suspend` 的逻辑。
- 修复 SpringBoard 的 `UIWebView` JS prompt 回调：回调处理现在由真正的 delegate（`HLXRootVC`）实现，而不是错误地放在 `UIWebView` 子类上。
- 移除非必要的私有 `_setSecure:` 调用，并把窗口层级改为较小的增量值，减少与系统窗口层级冲突的风险。
- 非 SpringBoard 的被注入进程启动变速代理；它们不会擅自显示悬浮球。
- rootless 构建最低部署版本调整为 iOS 15.0（Theos rootless 方案面向 iOS 15+）。

## GitHub 上传时特别注意（本次 IPA 缺失问题的关键）

GitHub Actions 在任务启动时会先读取仓库里真实存在的 `.github/workflows/build.yml`。如果只把本工程 ZIP 上传到仓库根目录，ZIP 内的 workflow 虽然会在构建任务运行时解压出来，但**不能替换本次已经启动的 workflow 定义**。因此必须另外把本 ZIP 内的 `.github/workflows/build.yml` 更新到 GitHub 仓库对应路径，并单独提交一次；然后再运行 Actions。新版 workflow 会出现 `Build TrollStore IPA (必须生成 out/Huluxia_TrollStore.ipa)` 步骤。

## 编译产物

GitHub Actions 成功后会上传名为 `Huluxia_Release` 的 artifact。GitHub 下载的 artifact 本身就是 ZIP，解压一次即可看到以下结构：

```text
Huluxia_Release/
├── 越狱版/
│   ├── Huluxia_rootful.deb
│   └── Huluxia_rootless.deb
├── TrollStore版/
│   ├── Huluxia_TrollStore.ipa
│   ├── Huluxia.dylib
│   └── Huluxia_TrollStore.plist
└── 使用说明.txt
```

本地需要 macOS + Xcode 命令行工具 + Theos：

```sh
make package FINALPACKAGE=1
make clean
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
./build_dylib.sh
./build_trollstore_ipa.sh out out/*rootful.deb
```

## 越狱版

- `Huluxia_rootful.deb`：rootful 越狱环境。
- `Huluxia_rootless.deb`：rootless 越狱环境（iOS 15+）。
- 安装后悬浮球不会自动出现。
- 点击桌面“葫芦侠”图标，再点击控制页里的“显示 / 隐藏悬浮球”按钮。悬浮球出现后，点它打开/关闭功能面板。
- SpringBoard 作为宿主显示跨 App 悬浮窗。跨进程内存访问仍取决于设备越狱环境是否授予相应 task port 权限；若 `task_for_pid` 被系统或越狱环境拒绝，进程读取/修改功能会返回权限错误，不保证所有目标进程都可附加。
- 变速代理只会加载到显式加入 `Huluxia.plist` Filter 的进程。先查到目标游戏的 Bundle ID，再在工程目录执行 `./configure_target.sh com.example.game`，之后重新构建并安装 DEB，完全退出后重新打开游戏。该脚本保留 SpringBoard 条目并追加目标 App，不会把所有进程都设为注入目标。
- 安装阶段不再强制终止或重启 SpringBoard；需要重新加载 tweak 时，请在确认设备状态后自行注销/重启相关目标进程。

## 注入目标配置

越狱版的 `Huluxia.plist` 默认只匹配 SpringBoard（用于显示桌面控制界面），不会猜测你的游戏 Bundle ID。必须先执行：

```sh
./configure_target.sh <游戏Bundle ID>
make clean && make package FINALPACKAGE=1
```

若构建 rootless 包，则追加 `THEOS_PACKAGE_SCHEME=rootless`。不要把 `*` 或所有系统进程作为注入目标；只添加你明确要测试的游戏 App。

## TrollStore / IPA 版

- `Huluxia_TrollStore.ipa` 是一个配套启动器 IPA，`Huluxia.dylib` 已嵌入 `Payload/Huluxia.app/Frameworks/`，启动器启动时会加载它。
- `Huluxia.dylib` 是单独提供的动态库；`Huluxia_TrollStore.plist` 是对应的 Bundle Filter 示例。当前独立 DYLIB 脚本仅编译 arm64 slice；不代表 arm64e/PAC 侧载变速已支持。
- TrollStore 版只能在这个 IPA 自身进程内显示面板/悬浮控件。它不能把 Tweak 注入 SpringBoard，也不能因此获得越狱 DEB 的系统级悬浮窗或对其他 App 的通用跨进程内存修改权限。
- TrollStore 官方项目公布的支持范围为 iOS 14.0 beta 2 至 iOS 16.6.1、iOS 16.7 RC（20H18）和 iOS 17.0；iOS 17.0.1 及以后版本不受支持。因此 iOS 18.x 设备不能通过 TrollStore 安装这个 IPA。请先核对目标设备系统版本，不要把“IPA 构建成功”误认为“TrollStore 一定能安装”。

## 验证说明

当前开发容器没有 Apple Xcode/iOS SDK，不能在这里真正编译或在设备上复现 SpringBoard 安全模式。本次对源码、通知流程、打包脚本和工作流做了静态修改与检查；最终是否消除安全模式，仍需在目标越狱环境上安装测试。若仍崩溃，需要设备生成的完整 SpringBoard `Jetsam/Crash` 日志或 `/var/mobile/huluxia.log`，仅有 `didFinish` 片段不足以定位异常指令。


## Lua 绘制 API（本次新增）

绘制指令由脚本提供坐标，原生全屏透明层负责渲染；坐标单位为屏幕点（pt）。示例：

```lua
gg.draw.clear()
gg.draw.rect(100, 120, 80, 180, "#FF3333", 2, false)
gg.draw.text(100, 105, "Target", "#FFFFFF", 14)
gg.draw.line(140, 120, 180, 220, "#00FF66", 2)

local points = {
  {x=140, y=120}, {x=140, y=155}, {x=115, y=190},
  {x=165, y=190}, {x=125, y=250}, {x=155, y=250}
}
local bones = {{1,2},{2,3},{2,4},{3,5},{4,6}}
gg.draw.skeleton(points, bones, "#00FF66", 2)
gg.draw.commit()
```

`gg.draw` 仅负责绘制，不包含人物识别、坐标读取或自动透视。脚本必须自行获得合法且准确的屏幕坐标。每次 `commit()` 替换上一帧，最多接受 2000 条指令；绘制层触摸穿透，不应遮挡游戏操作。


## 自动匹配搜索

修改器数据类型区新增“自动匹配”，可对 I8/U8、I16/U16、I32/U32、I64/U64、F32/F64 逐类扫描。结果按地址与类型分别保留；再次筛选、单条修改、批量修改和锁定均沿用结果自己的类型。变化比较模式仍应选择固定数据类型。详见 `AUTO_MATCH_CN.md`。

## 轻松签侧载游戏注入（自动显示悬浮球）

若将 `Huluxia.dylib` 直接注入游戏 IPA，普通游戏进程会在 UIKit 启动并进入 Active 状态、前台 UIWindowScene 就绪后自动创建悬浮球。详见 `SIDeload_MODE_CN.md`。该流程要求注入器确实添加 Mach-O `LC_LOAD_DYLIB` 并对包含的 dylib 重新签名；仅复制 dylib 文件不会加载它。

## 变速基线与旧系统兼容性（重要）
本次 `Sources/HLXSpeed.m` 回退到 2026-11-06 原始变速实现作为基线，并仅针对倍率切换的采样/基准推进原子性、时间回退和溢出保护进行修复。倍率范围为 0.1x–10x。详细兼容性限制见 `兼容性与变速修复说明.txt`。本工程当前尚未实现 iOS 8–9 的 armv7 完整构建，也不能宣称 arm64e 侧载 fishhook 已可用；请勿将静态检查当作真机验证。


## 阶段 5A：iOS 8–26 兼容构建

请同时阅读 `COMPATIBILITY_IOS8_26.md`。本阶段增加 legacy（iOS 8–10，armv7+arm64）与 modern（iOS 11–26，arm64）构建分支，并提供 iOS 8/9 的独立时钟后端。构建结果尚未在真机验证。


## 阶段 5F：iOS 16 面板分层诊断

GitHub Actions 手动运行时有两个互斥诊断开关：
- `native_diagnostic=true`：A层纯 UIKit 面板，不创建 WKWebView。
- `webkit_smoke_diagnostic=true` 且 A层关闭：B层创建 WKWebView，但只加载最小本地 HTML，不加载完整 UI 和 JS 桥。
- 两项都关闭：C层完整 HTML/Lua 面板。

若两个开关同时打开，A层优先。Dopamine Rootless 设备只安装 `modern_rootless` 对应 DEB。


## 阶段 5G：WebKit 加载异常保护与上下文日志

阶段 5G 在 5F 的 A/B/C 分层诊断基础上，增加面板创建环境、UIWindow scene/frame、HTML 加载调用前后日志，并将 `loadHTMLString` 调用纳入异常捕获。这样即使加载调用同步抛出 Objective-C 异常，也会在面板状态区域显示可复制的错误，而不是只由外层窗口初始化回滚吞掉现场。

这属于诊断可观测性和异常保护，不代表 iOS 16+ 的 WebKit 根因已经被实机确认或彻底修复。仍需按 A → B → C 顺序在目标设备验证。


## 阶段 5L（原生 HID 多点触摸与连点器）

新增最多五指的原生 HID 触摸事件组合、Lua/JS/HTML 多点触摸 API，以及独立连点器面板。连点器支持自定义坐标点、同时/顺序点击、滑动路径、间隔、按下时长、次数、暂停和停止。具体 API 与权限边界见 `LUA_DRAW_TOUCH_API_CN.md` 和 `PATCH_NOTES_STAGE5L.txt`。
