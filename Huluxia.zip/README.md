# Huluxia（葫芦侠 原生版）

把原来的 `葫芦侠.html`（H5GG 风格内存修改器界面）做成原生 Objective-C 源码。界面 HTML 原样内嵌进 dylib，
原来依赖 H5GG 的宿主接口全部由原生实现：

| 功能 | 实现 |
|---|---|
| 搜索/再次搜索/范围/大于小于/联合/文本/模糊/附近/指针 | `mach_vm_region` + `mach_vm_read_overwrite` |
| 改值/全部修改/十六进制读写 | `mach_vm_write` + `mach_vm_protect` |
| 进程列表/选择目标 | `sysctl` + `proc_pidpath` + `task_for_pid`（dlsym） |
| 内存区域/模块 | `proc_regionfilename` |
| 点击/滑动/长按 | `IOHIDEvent*`（IOKit 私有，dlsym） |
| 变速 | hook `mach_absolute_time/clock_gettime/gettimeofday`（需要 Substrate/ElleKit） |
| 悬浮窗 | `UIWindow` + `UIWebView`（SpringBoard）/`WKWebView`（App 内），悬浮球常驻桌面 |
| 桌面图标 | `Launcher`：点击 → post `com.huluxia.toggle` 通知 → SpringBoard 呼出/收起悬浮窗 |

## 编译（GitHub）
推送到 GitHub，Actions 会产出：rootful deb、rootless deb、单文件 `Huluxia.dylib`。
本地：装好 Theos 后 `make package FINALPACKAGE=1`（rootless 加 `THEOS_PACKAGE_SCHEME=rootless`）；
单文件 dylib：`./build_dylib.sh`。

## 使用
- **deb（越狱）**：装好后桌面出现图标，悬浮球在桌面常驻（约 3 秒后出现）。点悬浮球展开面板，在"选择进程"里选游戏。点桌面图标可呼出/收起悬浮窗。
- **变速**：把游戏 Bundle ID 加到 `Huluxia.plist` 的 Filter，重启游戏（代理在游戏进程里 hook 时间函数）。
- **dylib 注入 IPA**：直接改自己，无需 task_for_pid；变速在无 Substrate 时不可用（页面会自动降级为内存锚点变速）。

## 2.1.0 变更摘要（详见 CHANGES.md / TEST_REPORT.md）
- 桌面图标 / 悬浮球换为指定新图；`Huluxia.plist` 的 Filter 补上 `com.apple.springboard`（此前 deb 装上后根本不会注入 SpringBoard）。
- Lua/GG 兼容层：TYPE_* 与安卓 GG 数值一致、`flags` 字段、`sign` 比较符、真实的 `processPause/Resume`、每次运行独立 Lua 状态；不支持的接口（TYPE_AUTO / TYPE_XOR / SIGN_NOT_EQUAL / freeze / getSelectedElements）一律明确报错。
- 构建：`verify_build.sh` 校验 deb 与 dylib 内嵌/打包的是同一份 ui.html、ball.png、图标；GitHub Actions 增加 Lua/GG 测试任务。
- 本地测试 Lua/GG 层：`cd tests && npm i playwright && npx playwright install chromium && node lua_gg_test.mjs ../Resources/ui.html`（模拟宿主，非真机）。
