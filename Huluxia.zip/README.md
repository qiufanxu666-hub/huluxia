# 葫芦侠原生版 1.0.0

本工程输出越狱 DEB、独立 `Huluxia.dylib`，以及一个内嵌 DYLIB 的配套 IPA。

## 本次修复

- 启动桌面控制器后会探测 SpringBoard：越狱 Tweak 应答后显示全局悬浮球，并在确认显示后挂起控制器返回桌面；TrollStore 独立环境没有 SpringBoard 应答时会保持控制器运行。
- 悬浮球和功能面板使用不同通知，悬浮球点击后再打开/关闭面板；悬浮球可拖动并贴边。
- 修复 SpringBoard 的 WebKit JS 桥接回调、窗口生命周期与异常处理；减少非必要私有 API 和窗口层级冲突。
- 非 SpringBoard 的被注入目标进程启动变速代理；控制器本身不把 SpringBoard 当作内存扫描目标。
- rootless 构建最低部署版本调整为 iOS 15.0（Theos rootless 方案面向 iOS 15+）。

## GitHub 上传时特别注意（本次 IPA 缺失问题的关键）

GitHub Actions 在任务启动时会先读取仓库里真实存在的 `.github/workflows/build.yml`。如果只把本工程 ZIP 上传到仓库根目录，ZIP 内的 workflow 虽然会在构建任务运行时解压出来，但**不能替换本次已经启动的 workflow 定义**。因此必须另外把本 ZIP 内的 `.github/workflows/build.yml` 更新到 GitHub 仓库对应路径，并单独提交一次；然后再运行 Actions。新版 workflow 会出现 `Build TrollStore IPA (必须生成 out/Huluxia_TrollStore.ipa)` 步骤。

## 编译产物

GitHub Actions 成功后会上传名为 `Huluxia_Release` 的 artifact。GitHub 下载的 artifact 本身就是 ZIP，解压一次即可看到以下结构：

```text
Huluxia_Release/
├── 越狱版/
│   ├── Huluxia_rootful.deb
│   └── Huluxia_rootless.deb
├── TrollStore版/
│   ├── Huluxia_TrollStore.ipa
│   ├── Huluxia.dylib
│   └── Huluxia_TrollStore.plist
└── 使用说明.txt
```

本地需要 macOS + Xcode 命令行工具 + Theos：

```sh
make package FINALPACKAGE=1
make clean
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
./build_dylib.sh
./build_trollstore_ipa.sh out out/*rootful.deb
```

## GamePlayer 风格悬浮球与跨进程选择（本次修改）

- 打开桌面启动器后先探测 SpringBoard；收到越狱 Tweak 应答后，自动显示全局悬浮球并调用系统挂起入口返回桌面，点球打开功能面板。未收到应答（如 TrollStore 独立环境）则保持启动器前台，避免本地球随进程结束。
- SpringBoard 只是全局悬浮球宿主，不是扫描目标。进程选择器会排除 SpringBoard 和当前宿主，只列出 App 进程；选中后必须先通过 `task_for_pid`，成功才切换 UI 目标，失败时保留旧目标并显示原生错误。
- 原生扫描器新增无符号 `DWORD`（32 位）、`WORD`（16 位）、`BYTE`（8 位）。输入别名 `ORD` 会按 `WORD` 处理，`BY TE` 会按 `BYTE` 处理。GameGuardian Lua/JS 的 `TYPE_DWORD/TYPE_WORD/TYPE_BYTE` 也映射到相同宽度的无符号类型。
- 这些改动位于 `Sources/HLXMemory.m`、`Sources/HLXBridge.m` 和统一嵌入的 `Resources/ui.html`，因此 legacy/modern rootful、rootless、独立 DYLIB 和 IPA 由同一套类型及进程选择逻辑构建，不是仅给 DEB 增加按钮。
- 进程列表可见不等于一定有权限附加。越狱环境拒绝 `task_for_pid` 时，跨进程扫描/读写无法靠 UI 绕过。Launcher entitlements 参考你提供的 GamePlayer 二进制，只签给 Launcher 进程；它不会把权限转授给 SpringBoard 或其他 App。
- 变速需要目标游戏进程里实际加载 `HLXSpeed` 代理；仅附加 task port 不会自动把变速 hook 注入目标。请按下文 `configure_target.sh` 添加游戏 Bundle ID 后重编译，并重新启动游戏。

## 越狱版

- `Huluxia_rootful.deb`：rootful 越狱环境。
- `Huluxia_rootless.deb`：rootless 越狱环境（iOS 15+）。
- 打开桌面“葫芦侠”图标后会自动显示悬浮球；越狱版收到 SpringBoard 确认后自动返回桌面，TrollStore 版保持控制器运行。悬浮球出现后，点它打开/关闭功能面板。
- SpringBoard 只作为宿主显示跨 App 悬浮窗；真正的目标进程要在面板的“跨进程选择”列表中选择。内存访问仍取决于设备越狱环境是否授予相应 task port 权限；若 `task_for_pid` 被拒绝，读取/修改功能会返回权限错误，不会假装附加成功。
- 变速代理只会加载到显式加入 `Huluxia.plist` Filter 的进程。先查到目标游戏的 Bundle ID，再在工程目录执行 `./configure_target.sh com.example.game`，之后重新构建并安装 DEB，完全退出后重新打开游戏。该脚本保留 SpringBoard 条目并追加目标 App，不会把所有进程都设为注入目标。
- 安装阶段不再强制终止或重启 SpringBoard；需要重新加载 tweak 时，请在确认设备状态后自行注销/重启相关目标进程。

## 注入目标配置

越狱版的 `Huluxia.plist` 默认只匹配 SpringBoard（用于显示桌面控制界面），不会猜测你的游戏 Bundle ID。必须先执行：

```sh
./configure_target.sh <游戏Bundle ID>
make clean && make package FINALPACKAGE=1
```

若构建 rootless 包，则追加 `THEOS_PACKAGE_SCHEME=rootless`。不要把 `*` 或所有系统进程作为注入目标；只添加你明确要测试的游戏 App。

## TrollStore / IPA 版

- `Huluxia_TrollStore.ipa` 是一个配套启动器 IPA，`Huluxia.dylib` 已嵌入 `Payload/Huluxia.app/Frameworks/`，启动器启动时会加载它。IPA 主程序签名包含从你提供的 GamePlayer 二进制中核对的 `task_for_pid-allow`、`get-task-allow`、`com.apple.springboard.debugapplications`、`run-unsigned-code` 权限项。
- `Huluxia.dylib` 是单独提供的动态库；`Huluxia_TrollStore.plist` 是对应的 Bundle Filter 示例。当前独立 DYLIB 脚本仅编译 arm64 slice；不代表 arm64e/PAC 侧载变速已支持。
- TrollStore IPA 同样包含进程列表、跨进程选择及内存读写代码，不再把扫描目标固定为启动器自身；但实际 `task_for_pid` 是否成功仍由目标系统、签名和 TrollStore 环境决定，失败会明确报错。与越狱版不同，IPA 没有把 Tweak 注入 SpringBoard，因此悬浮球只能由 IPA 自身窗口承载，不能保证离开该 App 后仍覆盖其他 App。
- 变速代理仍需在目标 App 进程里运行。越狱版通过 `configure_target.sh` 将目标 Bundle ID 加入注入过滤器；侧载环境则需要实际把 `Huluxia.dylib` 注入目标 App，单独启动控制器 IPA 不会自动向其他 App 注入代码。

## 验证说明

当前开发容器没有 Apple Xcode/iOS SDK，不能在这里真正编译或在设备上复现 SpringBoard 安全模式。本次对源码、通知流程、打包脚本和工作流做了静态修改与检查；最终是否消除安全模式，仍需在目标越狱环境上安装测试。若仍崩溃，需要设备生成的完整 SpringBoard `Jetsam/Crash` 日志或 `/var/mobile/huluxia.log`，仅有 `didFinish` 片段不足以定位异常指令。


## Lua 绘制 API（本次新增）

绘制指令由脚本提供坐标，原生全屏透明层负责渲染；坐标单位为屏幕点（pt）。示例：

```lua
gg.draw.clear()
gg.draw.rect(100, 120, 80, 180, "#FF3333", 2, false)
gg.draw.text(100, 105, "Target", "#FFFFFF", 14)
gg.draw.line(140, 120, 180, 220, "#00FF66", 2)

local points = {
  {x=140, y=120}, {x=140, y=155}, {x=115, y=190},
  {x=165, y=190}, {x=125, y=250}, {x=155, y=250}
}
local bones = {{1,2},{2,3},{2,4},{3,5},{4,6}}
gg.draw.skeleton(points, bones, "#00FF66", 2)
gg.draw.commit()
```

`gg.draw` 仅负责绘制，不包含人物识别、坐标读取或自动透视。脚本必须自行获得合法且准确的屏幕坐标。每次 `commit()` 替换上一帧，最多接受 2000 条指令；绘制层触摸穿透，不应遮挡游戏操作。


## 自动匹配搜索

修改器数据类型区新增“自动匹配”，可对 I8/U8、I16/U16、I32/U32、I64/U64、F32/F64 逐类扫描。结果按地址与类型分别保留；再次筛选、单条修改、批量修改和锁定均沿用结果自己的类型。变化比较模式仍应选择固定数据类型。详见 `AUTO_MATCH_CN.md`。

## 轻松签侧载游戏注入（自动显示悬浮球）

若将 `Huluxia.dylib` 直接注入游戏 IPA，普通游戏进程会在 UIKit 启动并进入 Active 状态、前台 UIWindowScene 就绪后自动创建悬浮球。详见 `SIDeload_MODE_CN.md`。该流程要求注入器确实添加 Mach-O `LC_LOAD_DYLIB` 并对包含的 dylib 重新签名；仅复制 dylib 文件不会加载它。

## 变速基线与旧系统兼容性（重要）
本次 `Sources/HLXSpeed.m` 回退到 2026-11-06 原始变速实现作为基线，并仅针对倍率切换的采样/基准推进原子性、时间回退和溢出保护进行修复。倍率范围为 0.1x–10x。详细兼容性限制见 `兼容性与变速修复说明.txt`。本工程当前尚未实现 iOS 8–9 的 armv7 完整构建，也不能宣称 arm64e 侧载 fishhook 已可用；请勿将静态检查当作真机验证。


## 阶段 5A：iOS 8–26 兼容构建

请同时阅读 `COMPATIBILITY_IOS8_26.md`。本阶段增加 legacy（iOS 8–10，armv7+arm64）与 modern（iOS 11–26，arm64）构建分支，并提供 iOS 8/9 的独立时钟后端。构建结果尚未在真机验证。
