#include <mach/mach.h>
#include <mach/message.h>
#include <mach/mach_error.h>
#include <mach/task_info.h>
#include "../Sources/HLXBootstrapShim.h"
#include <dlfcn.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

extern int proc_pidpath(int pid, void *buffer, uint32_t buffersize);

static const char *kServiceName = "com.huluxia.memoryd";
static const mach_msg_id_t kRequestID = 0x484C5801;
static const mach_msg_id_t kReplyID = 0x484C5802;
static const uint32_t kProtocolVersion = 1;
static const size_t kPathMax = 4096;

typedef struct {
    mach_msg_header_t header;
    int32_t pid;
    uint32_t version;
} HLXMemoryRequest;

typedef struct {
    mach_msg_header_t header;
    mach_msg_body_t body;
    mach_msg_port_descriptor_t taskPort;
    int32_t result;
    uint32_t version;
} HLXMemoryReply;

typedef kern_return_t (*HLXTaskForPIDFn)(mach_port_t, int, mach_port_t *);

static int HLXIsSpringBoardClient(pid_t pid) {
    char path[kPathMax];
    memset(path, 0, sizeof(path));
    if (pid <= 1 || proc_pidpath(pid, path, (uint32_t)sizeof(path)) <= 0) return 0;
    // The PID is taken from the kernel audit trailer, never from message data.
    return strstr(path, "/SpringBoard.app/SpringBoard") != NULL;
}

static int HLXSameTargetPath(pid_t pid, const char *before) {
    char after[kPathMax];
    memset(after, 0, sizeof(after));
    return proc_pidpath(pid, after, (uint32_t)sizeof(after)) > 0 && strcmp(before, after) == 0;
}

static kern_return_t HLXAcquireTask(pid_t pid, mach_port_t *outTask) {
    if (outTask) *outTask = MACH_PORT_NULL;
    if (!outTask || pid <= 1 || pid == getpid()) return KERN_INVALID_ARGUMENT;

    char before[kPathMax];
    memset(before, 0, sizeof(before));
    if (proc_pidpath(pid, before, (uint32_t)sizeof(before)) <= 0) return KERN_FAILURE;
    // This service serves app targets only; reject launch daemons and other
    // non-application processes even if a caller supplies their PID directly.
    if (!strstr(before, ".app/")) return KERN_INVALID_ARGUMENT;

    HLXTaskForPIDFn taskForPID = (HLXTaskForPIDFn)dlsym(RTLD_DEFAULT, "task_for_pid");
    if (!taskForPID) return KERN_NOT_SUPPORTED;

    mach_port_t candidate = MACH_PORT_NULL;
    kern_return_t kr = taskForPID(mach_task_self(), (int)pid, &candidate);
    if (kr != KERN_SUCCESS || candidate == MACH_PORT_NULL) {
        if (candidate != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), candidate);
        return kr == KERN_SUCCESS ? KERN_FAILURE : kr;
    }

    task_basic_info_data_t info;
    mach_msg_type_number_t count = TASK_BASIC_INFO_COUNT;
    kr = task_info(candidate, TASK_BASIC_INFO, (task_info_t)&info, &count);
    if (kr != KERN_SUCCESS || !HLXSameTargetPath(pid, before)) {
        mach_port_deallocate(mach_task_self(), candidate);
        return kr == KERN_SUCCESS ? KERN_ABORTED : kr;
    }

    *outTask = candidate;
    return KERN_SUCCESS;
}

static void HLXSendReply(mach_port_t replyPort, kern_return_t result, mach_port_t task) {
    if (replyPort == MACH_PORT_NULL) {
        if (task != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), task);
        return;
    }

    HLXMemoryReply reply;
    memset(&reply, 0, sizeof(reply));
    reply.header.msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_MOVE_SEND_ONCE, 0);
    if (result == KERN_SUCCESS && task != MACH_PORT_NULL) {
        reply.header.msgh_bits |= MACH_MSGH_BITS_COMPLEX;
        reply.body.msgh_descriptor_count = 1;
        reply.taskPort.name = task;
        reply.taskPort.disposition = MACH_MSG_TYPE_COPY_SEND;
        reply.taskPort.type = MACH_MSG_PORT_DESCRIPTOR;
    } else if (result == KERN_SUCCESS) {
        result = KERN_FAILURE;
    }
    reply.header.msgh_size = sizeof(reply);
    reply.header.msgh_remote_port = replyPort;
    reply.header.msgh_local_port = MACH_PORT_NULL;
    reply.header.msgh_id = kReplyID;
    reply.result = (int32_t)result;
    reply.version = kProtocolVersion;

    kern_return_t sendKR = mach_msg(&reply.header, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
                                    reply.header.msgh_size, 0, MACH_PORT_NULL, 1500, MACH_PORT_NULL);
    if (task != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), task);
    if (sendKR != MACH_MSG_SUCCESS)
        fprintf(stderr, "HuluxiaD: reply send failed: %s\n", mach_error_string(sendKR));
}

static void HLXServe(mach_port_t servicePort) {
    for (;;) {
        union {
            mach_msg_header_t align;
            uint8_t bytes[4096];
        } storage;
        memset(&storage, 0, sizeof(storage));

        mach_msg_header_t *header = &storage.align;
        mach_msg_option_t options = MACH_RCV_MSG |
            MACH_RCV_TRAILER_TYPE(MACH_MSG_TRAILER_FORMAT_0) |
            MACH_RCV_TRAILER_ELEMENTS(MACH_RCV_TRAILER_AUDIT);
        kern_return_t kr = mach_msg(header, options, 0, sizeof(storage.bytes), servicePort,
                                    MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
        if (kr != MACH_MSG_SUCCESS) {
            fprintf(stderr, "HuluxiaD: receive failed: %s\n", mach_error_string(kr));
            continue;
        }

        mach_port_t replyPort = header->msgh_remote_port;
        kern_return_t result = KERN_INVALID_ARGUMENT;
        mach_port_t task = MACH_PORT_NULL;

        if (header->msgh_id == kRequestID && header->msgh_size == sizeof(HLXMemoryRequest)) {
            HLXMemoryRequest *request = (HLXMemoryRequest *)header;
            mach_msg_size_t trailerOffset = (mach_msg_size_t)((header->msgh_size + sizeof(natural_t) - 1) & ~(sizeof(natural_t) - 1));
            if (trailerOffset + sizeof(mach_msg_audit_trailer_t) <= sizeof(storage.bytes)) {
                mach_msg_audit_trailer_t *trailer = (mach_msg_audit_trailer_t *)(storage.bytes + trailerOffset);
                if (trailer->msgh_trailer_size >= sizeof(*trailer) &&
                    trailer->msgh_trailer_type == MACH_MSG_TRAILER_FORMAT_0) {
                    pid_t clientPID = HLXAuditTokenPID(trailer->msgh_audit);
                    if (HLXIsSpringBoardClient(clientPID) && request->version == kProtocolVersion)
                        result = HLXAcquireTask((pid_t)request->pid, &task);
                    else
                        result = KERN_NO_ACCESS;
                } else {
                    result = KERN_NO_ACCESS;
                }
            } else {
                result = KERN_NO_ACCESS;
            }
        }
        HLXSendReply(replyPort, result, task);
    }
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    mach_port_t servicePort = MACH_PORT_NULL;
    kern_return_t kr = bootstrap_check_in(bootstrap_port, kServiceName, &servicePort);
    if (kr != KERN_SUCCESS || servicePort == MACH_PORT_NULL) {
        fprintf(stderr, "HuluxiaD: bootstrap_check_in(%s) failed: %s\n", kServiceName, mach_error_string(kr));
        return 1;
    }
    fprintf(stderr, "HuluxiaD: listening on %s\n", kServiceName);
    HLXServe(servicePort);
    return 0;
}
