# Huluxia 2.1.0 修改报告

> 重要前提：本次工作环境没有 Xcode / iOS SDK / Theos / clang，也没有网络，**无法编译 DYLIB 与 DEB，本包不含二进制产物**。
> 原生 Objective-C 改动只做了括号平衡的静态检查，**未编译、未在真机运行**。产物由 GitHub Actions（`.github/workflows/build.yml`）从本源码构建。

## 1. UI 保护
- `Resources/ui.html`：7 个 `<style>` 块与原版逐字相同；`<script>` 之外的 HTML 仅在“Lua 说明”区按原有 span 样式新增 1 行文字（不支持项清单）。布局、配色、按钮、菜单未改。
- 原始工程备份：`Huluxia_ORIGINAL_BACKUP/`（工作目录内），补丁见 `huluxia_2.1.0.patch`。

## 2. 图标 / 悬浮球
| 文件 | 规格 | 说明 |
|---|---|---|
| Launcher/Resources/Icon@2x.png | 120×120 RGB | 来自 IMG_0359.jpeg |
| Launcher/Resources/Icon@3x.png | 180×180 RGB | 同上 |
| Resources/ball.png | 256×256 RGB | 同上；圆形裁切由 HLXOverlay 的 cornerRadius 完成 |
- 原图 361×362：只裁掉底部多出的 1 行近白像素得到正方形，无拉伸，未加文字/边框；JPEG 无透明通道，输出为不透明 PNG（iOS 图标本应不透明）。
- 实际引用检查：Launcher `Info.plist` 用 `CFBundleIconFiles=Icon` → `Icon@2x/@3x.png`；已删除指向不存在 asset catalog 的 `CFBundleIconName`。悬浮球图片不是运行时读文件，而是编译期 `-sectcreate __DATA,__hlxball` 嵌入 dylib，**必须重新构建才生效**。
- **提醒**：该图片看起来像一张大图的局部截取（绿色弧形 + 左上白色圆角块 + 左下黑色笔画），没有完整图案。已按要求原样使用，若不是你想要的，请重新上传完整图。
- 未做：iPad 专用尺寸（152/167）；iPad 上会由系统缩放 120px 图。

## 3. 修复的问题
| # | 问题 | 位置 | 修复 |
|---|---|---|---|
| 1 | Filter 只有占位 Bundle，deb 装上后 dylib 不会注入 SpringBoard，悬浮球不出现 | Huluxia.plist | 加入 `com.apple.springboard` |
| 2 | `TYPE_XOR` 被映射成 I32；`TYPE_AUTO`/未知类型经 `\|\| 'I32'` 静默变 I32 | ui.html `ggTypeToH5` | 明确报错 |
| 3 | 标准 GG 写法 `flags=gg.TYPE_FLOAT` 被忽略，浮点按 I32 写入（实测写 3.25 得 4.2e-45） | ui.html | 认 `flags`；getResults/getValues 返回 `flags`，数值返回 number |
| 4 | TYPE_* 常量是字符串，无法 `TYPE_DWORD\|TYPE_FLOAT`、与 GG 脚本比较 | ui.html | 改为 GG 数值 1/2/4/8/16/32/64/127 |
| 5 | `searchNumber/refineNumber` 的 `sign` 被丢弃，`encrypted` 被忽略 | ui.html | `>`/`<`/`>=`/`<=` 翻译为原生表达式；`!=` 与 `encrypted=true` 明确报不支持 |
| 6 | `gg.getResults(count, skip)` 分页错误（先取前 count 条再切片，skip≥count 恒为空） | ui.html | skip 直接交给原生 |
| 7 | `processPause/Resume/Toggle` 是 `return true` 空实现 | ui.html + HLXMemory + HLXBridge | 原生 `task_suspend/task_resume`（dlsym），目标为本进程时拒绝 |
| 8 | `getFile` 返回不存在的 `/sdcard/...` | ui.html | 返回空串 |
| 9 | `freeze=true` 被存下却从不生效 | ui.html | 一次性明确告警（未实现冻结） |
| 10 | 每次运行复用同一 Lua 状态：全局变量串到下个脚本，协程压栈累积 | ui.html `runLuaFengari`/`stopLuaScript` | 每次运行新建状态；停止时释放主状态引用 |
| 11 | `attachPid` 切换目标时泄漏旧 task port；旧进程若被暂停会一直冻着 | HLXMemory.m | 切换后 resume + `mach_port_deallocate` |
| 12 | 工作流把上一阶段残留的 rootful deb 复制并改名 `_rootless.deb`；`\|\| true` 吞掉构建失败；无产物也显示成功 | build.yml | 阶段间清 packages、严格检查、`if-no-files-found: error` |
| 13 | deb / Launcher / ui.html 版本不一致风险 | control, Info.plist, ui.html | 统一 2.1.0，verify_build.sh 校验 |

## 4. GG API 状态（24 个要求接口）
- **可用**：searchNumber, refineNumber, getResults, getResultsCount, clearResults, getValues, setValues, editAll, addListItems, removeListItems, alert, choice, multiChoice, prompt, toast, setVisible, isVisible, sleep, getTargetInfo, getRangesList。
- **可用但有差异**：`getFile`（无脚本文件→空串）；`processPause/Resume`（需原生新代码，未编译）；`addListItems/removeListItems` 是页面内的列表，不是 GG 的存档列表。
- **不支持（明确报错）**：`getSelectedElements`、`TYPE_AUTO`、`TYPE_XOR`、类型组合、`SIGN_NOT_EQUAL`、`encrypted=true`；`freeze` 仅告警。
- 其他已知差异：`searchNumber` 的 `limit` 参数未实现；Fengari 整数为 32 位，大于 2^31 的值/地址在 Lua 里是 float；REGION_* 常量数值与安卓 GG 不同（按位或可用，但脚本里写死数字会不对）。
- 注意：行为变更——`getResults/getValues` 的 `value` 由字符串改为 number（64 位超 2^53 仍为字符串）；JS 页签里的 `gg.TYPE_*` 同样变为数值。

## 5. 原本就已具备（本次未重写）
脚本面板协程式 `gg.choice/multiChoice/prompt/alert`、`gg.ui/waitEvent`、15s 指令计数超时钩子、停止按钮、UI 回调。

## 6. 修改的文件
Huluxia.plist, control, Makefile(未改), README.md, CHANGES.md, TEST_REPORT.md, verify_build.sh(新), tests/(新), .github/workflows/build.yml, Launcher/Resources/{Icon@2x.png,Icon@3x.png,Info.plist}, Resources/{ball.png,ui.html}, Sources/{HLXMemory.h,HLXMemory.m,HLXBridge.m}。
Tweak.m / HLXOverlay / HLXSpeed / HLXTouch：已阅读 Tweak.m，并对后三者做了生命周期风险模式扫描（观察者重复注册、notify token、dispatch_sync 主线程、内存分配），未发现需修改的缺陷；**未做逐行深度审计**。
