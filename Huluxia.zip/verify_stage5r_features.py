#!/usr/bin/env python3
from pathlib import Path
import plistlib
root=Path(__file__).resolve().parent
plist=plistlib.loads((root/'Huluxia.plist').read_bytes())
bundles=plist['Filter']['Bundles']
workflow=(root/'.github/workflows/build.yml').read_text()
mem=(root/'Sources/HLXMemory.m').read_text()
speed=(root/'Sources/HLXSpeed.m').read_text()
ui=(root/'Resources/ui.html').read_text()
checks={
 'UIKit-wide injection filter is enabled':'com.apple.UIKit' in bundles,
 'SpringBoard remains included':'com.apple.springboard' in bundles,
 'manual Bundle ID workflow input is removed':'target_bundle_id' not in workflow,
 'manual Bundle ID configuration step is removed':'configure_target.sh' not in workflow,
 'workflow runs Stage 5R verifier':'python3 verify_stage5r_features.py' in workflow,
 'process picker continues to use native process list':'getProcList' in ui and 'setTargetProc' in ui,
 'process list filters out non-app daemons':'if (bundle.length) [apps addObject:d];' in mem and 'return apps;' in mem,
 'unloaded agent rejection does not request manual Bundle ID':'Bundle ID 加入 Huluxia.plist' not in mem,
 'speed sender checks target agent status before posting multiplier':'agentStatusForPid:pid' in speed and 'notify_post(speedName(pid).UTF8String)' in speed,
 'picker search is app-name oriented':'搜索应用名称...' in ui,
 'workflow prioritizes Stage 5R archive':'Huluxia_1.0.0_阶段5R_全UIKit注入与直接进程选择.zip' in workflow,
}
for label,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
raise SystemExit(0 if all(checks.values()) else 1)
