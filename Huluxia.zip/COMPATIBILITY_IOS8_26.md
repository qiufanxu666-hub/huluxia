# 葫芦侠 iOS 8–26 兼容性工程（阶段 5A）

## 目标构建族

| 构建族 | 系统目标 | 架构 | 包类型 | 说明 |
|---|---|---|---|---|
| legacy | iOS 8.0–10.x | armv7 + arm64 | rootful DEB | 使用 iOS 11.4 SDK，保留 32 位系统符号；旧系统不支持 rootless |
| modern-rootful | iOS 11.0–26.x | arm64（可运行于 arm64e 设备） | rootful DEB | 使用当前 Xcode SDK |
| modern-rootless | iOS 15.0–26.x | arm64 + arm64e | rootless DEB | 仅适用于 rootless 越狱环境 |

注意：iOS 11 起系统不再运行 32 位 App，因此 armv7 仅用于 iOS 8–10 的旧设备；不是 iOS 11–26 的架构选项。

## 本阶段已修改

- Makefile 增加 `HLX_BUILD_FAMILY=legacy|modern` 两种构建族。
- legacy 目标改为 `iphone:clang:11.4:8.0`，架构 `armv7 arm64`；禁止将 legacy 误打成 rootless。
- modern rootful 最低部署版本设为 iOS 11.0；modern rootless 最低部署版本设为 iOS 15.0。
- 对 `UIScene` / `UIWindowScene` 的引用增加 SDK 编译期条件，旧 SDK 编译时走传统 `UIWindow(frame:)` 路径。
- `HLXDrawOverlay` 的 `os_unfair_lock` 改为 iOS 8 可用的 `pthread_mutex`。
- dylib 内嵌资源段读取改用通用 `mach_header` 入口，避免在 armv7 进程中错误按 64 位 Mach-O 头解析。
- `Sources/HLXSpeed.m` 未修改，modern 构建继续使用阶段 1 原版（SHA-256 不变）。
- legacy 构建单独使用 `Sources/HLXSpeedLegacy.m`：不依赖 iOS 10 才有的 `clock_gettime`，改用 `mach_absolute_time` 与 `gettimeofday`；仍要求设备有可用的 Substrate `MSHookFunction`。

## 还不能宣称已验证

当前工作容器没有 Theos、iOS SDK 或可连接的 iPhone 真机。本阶段只完成源代码层面的兼容性改造和静态检查，不能声称已经编译、安装或在所有 iOS 版本上运行通过。

特别需要在真实旧设备上验证：

1. iOS 8/9 legacy 时钟后端的倍率连续性、回到 1x 时的时间基准，以及只使用 mach/gettimeofday 的游戏覆盖率。它是单独的旧系统后端，不能等同于 modern 阶段 1 引擎的逐字节相同实现。
2. iOS 8–10 的 Substrate 版本、私有 HID API 和触摸注入权限。
3. armv7 下资源段读取、Lua/JS 桥接、内存扫描和悬浮窗生命周期。
4. iOS 11–12 无 Scene 的窗口路径，以及 iOS 13+ 多 Scene 路径。
5. iOS 15+ rootless 路径和 iOS 26 当前 SDK 的 arm64e 签名/注入行为。

TrollStore IPA 不作为 iOS 8–26 通用交付物：TrollStore 本身只支持特定系统/安装环境，不能替代越狱注入，也不能据此访问 SpringBoard 或任意 App 进程。
