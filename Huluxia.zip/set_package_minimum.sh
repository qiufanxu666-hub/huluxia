#!/bin/bash
# Set the Debian firmware lower bound for the next Theos package build.
set -euo pipefail
MIN="${1:?usage: set_package_minimum.sh <minimum-iOS-version>}"
python3 - "$MIN" <<'PY'
from pathlib import Path
import re, sys
p=Path('control')
s=p.read_text()
s2,n=re.subn(r'^Depends: firmware \(>= [^)]+\), mobilesubstrate$', f'Depends: firmware (>= {sys.argv[1]}), mobilesubstrate', s, flags=re.M)
if n != 1: raise SystemExit('Could not update firmware dependency in control')
p.write_text(s2)
print('Package firmware minimum set to', sys.argv[1])
PY
