#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
bridge = (root / 'Sources/HLXBridge.m').read_text()
ui = (root / 'Resources/ui.html').read_text()
overlay = (root / 'Sources/HLXOverlay.m').read_text()
points = (root / 'Sources/HLXTouchPoints.m').read_text()
header = (root / 'Sources/HLXTouchPoints.h').read_text()
workflow = (root / '.github/workflows/build.yml').read_text()

checks = {
    'native transparent touch-point window is implemented': 'HLXTouchPointWindow' in points and 'UIWindowLevelAlert - 1.0' in points,
    'touch-point window passes through all non-handle touches': 'if (hit == self || hit == self.rootViewController.view) return nil;' in points,
    'touch points are draggable and persist updated coordinates': 'UIPanGestureRecognizer' in points and 'self.locations[handle.pointIndex] = [NSValue valueWithCGPoint:point]' in points,
    'swipe mode uses native down/move/up rather than DOM events': 'self.swipeActive = [HLXTouch down:' in points and '[HLXTouch move:p]' in points and '[HLXTouch up:p]' in points,
    'tap and long-press dispatch are gated by explicit run modes': 'self.mode != 1 && self.mode != 3' in points and '[HLXTouch longPress:p ms:1000]' in points,
    'native touch-point overlay is capped at five points': 'if (safe.count >= 5) break;' in points,
    'bridge exposes set/show/hide/get/clear/mode methods': all(x in bridge for x in ('@"setTouchPoints"', '@"showTouchPoints"', '@"hideTouchPoints"', '@"getTouchPoints"', '@"clearTouchPoints"', '@"setTouchPointMode"')),
    'native method names are exported to JavaScript h5gg': all(x in bridge for x in ('@"setTouchPoints"', '@"showTouchPoints"', '@"getTouchPoints"')),
    'Lua compatibility API exposes native touch-point methods': 'setTouchPoints:function(points)' in ui and 'setTouchPointMode:function(mode)' in ui,
    'JavaScript runtime exposes native touch-point methods': 'rt.setTouchPoints = function(points)' in ui and 'rt.getTouchPoints = function()' in ui,
    'HTML iframe exposes native touch-point methods': 'w.setTouchPoints = rt.setTouchPoints' in ui and 'w.setTouchPointMode = rt.setTouchPointMode' in ui,
    'HTML bridge is injected before user page scripts execute': 'prepareHtmlForHost(code)' in ui and 'source.replace(/<head' in ui and 'frame.srcdoc = prepared' in ui,
    'iframe load handler is installed before srcdoc assignment': ui.index('frame.onload = function() {', ui.index('function setFrameContent')) < ui.index('frame.srcdoc = prepared', ui.index('function setFrameContent')),
    'native h5gg, h5 and host aliases are installed at document start': 'window.h5gg = h;' in bridge and 'window.h5 = h; window.host = h;' in bridge,
    'landscape menu uses a scrollable two-column layout': '@media (orientation:landscape)' in ui and 'grid-template-columns:repeat(2,minmax(0,1fr))' in ui and 'overflow-y:auto' in ui,
    'iOS 13+ panel geometry follows its own scene coordinate space': 'return scene.coordinateSpace.bounds.size;' in overlay,
    'older SDK compatibility remains dynamically guarded': 'NSSelectorFromString(@"windowScene")' in overlay,
    'workflow copies the native touch-point source and header': 'Sources/HLXTouchPoints.m' in workflow and 'Sources/HLXTouchPoints.h' in workflow,
    'workflow runs Stage 5P validation': 'python3 verify_stage5p_features.py' in workflow,
    'workflow selects Stage 5P archive before Stage 5O': workflow.index('Huluxia_1.0.0_阶段5P_原生悬浮触摸点与HTML桥接修复.zip') < workflow.index('Huluxia_1.0.0_阶段5O_变速桥接与拖动点位编辑器.zip'),
}

speed_hash = hashlib.sha256((root / 'Sources/HLXSpeed.m').read_bytes()).hexdigest()
checks['Stage 5Q speed source is present for the new injected-agent validation'] = speed_hash == '5a53100c841f15929d485883623734e3ca74525dc567dbe25627dee8cd9e08c3'

for label, ok in checks.items():
    print(('PASS: ' if ok else 'FAIL: ') + label)
print('HLXSpeed.m SHA256:', speed_hash)
raise SystemExit(0 if all(checks.values()) else 1)
