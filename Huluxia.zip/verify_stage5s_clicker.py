#!/usr/bin/env python3
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
ui = (root / "Resources/ui.html").read_text()
points = (root / "Sources/HLXTouchPoints.m").read_text()
touch = (root / "Sources/HLXTouch.m").read_text()
bridge = (root / "Sources/HLXBridge.m").read_text()
plist = (root / "Huluxia.plist").read_text()
speed = (root / "Sources/HLXSpeed.m").read_bytes()
checks = {
    "removed the in-panel fake screen grid": "clickerStage" not in ui and "clickerRenderStage" not in ui,
    "native points are pulled back after direct screen dragging": "clickerPullNativePoints" in ui and "host.getTouchPoints()" in ui,
    "point creation is UI-driven and no manual X/Y coordinate inputs remain": "添加屏幕触摸点" in ui and all(x not in ui for x in ("clickerPointX", "clickerPointY", "clickerSX", "clickerSY", "clickerEX", "clickerEY")),
    "swipe uses two draggable on-screen native points": "滑动起点" in ui and "滑动终点" in ui and "host.swipe(startPoint.x, startPoint.y, endPoint.x, endPoint.y, duration)" in ui,
    "runner exposes native point refresh/show/hide controls": all(x in ui for x in ("clickerRefreshPoints", "clickerShowPoints", "clickerHidePoints")),
    "clicker starts using current native overlay coordinates": "clickerPullNativePoints()" in ui and "setTouchPointMode('run')" in ui,
    "overlay edit handles stay draggable": "UIPanGestureRecognizer" in points and "self.locations[handle.pointIndex] = [NSValue valueWithCGPoint:point]" in points and "self.mode != 0 && self.mode != 2" in points,
    "overlay uses explicit pass-through state while running": "if (self.passThrough) return nil;" in points and "m.controller.overlayWindow.passThrough = runMode;" in points,
    "overlay remains limited to five points": "if (safe.count >= 5) break;" in points,
    "HID uses stable full-screen SpringBoard point space and UIKit window-point events": "HLXCoordinateBounds(UIWindow *window)" in touch and "if (HLXIsSpringBoard()) return UIScreen.mainScreen.bounds.size;" in touch and "p.x, p.y, 0, 0.0, 0" in touch and "normalizedX" not in touch and "normalizedY" not in touch,
    "HID uses distinct phase masks for down/move/up": "const uint32_t childMask = moving" in touch and "kHLXDigitizerPosition" in touch and "kHLXDigitizerRange | kHLXDigitizerTouch" in touch,
    "HID status warns that availability is not a delivery receipt": "没有系统接收回执" in touch,
    "bridge retains multiTap and native point APIs": all(x in bridge for x in ("multiTap", "setTouchPoints", "getTouchPoints", "setTouchPointMode")),
    "injection filter is SpringBoard-only": "com.apple.springboard" in plist and "com.apple.UIKit" not in plist,
    "speed engine enforces the Stage 5U 100x ceiling": b"newSpeed > 100.0" in speed and b"mult > 100.0" in speed,
}
for label, ok in checks.items(): print(("PASS: " if ok else "FAIL: ") + label)
raise SystemExit(0 if all(checks.values()) else 1)
