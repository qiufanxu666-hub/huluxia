#!/usr/bin/env python3
from pathlib import Path
import hashlib
root = Path(__file__).parent
s = (root / 'Sources/HLXOverlay.m').read_text()
speed = (root / 'Sources/HLXSpeed.m').read_bytes()
checks = {
    'scene-aware window factory exists': '- (UIWindow *)makeWindowForScene:(id)preferredScene' in s,
    'panel reuses floating-ball scene': 'makeWindowForScene:self->_ball.windowScene' in s,
    'fallback selects foreground scene': 'UISceneActivationStateForegroundActive' in s,
    'legacy factory delegates to scene-aware factory': 'return [self makeWindowForScene:nil];' in s,
    'WKWebView remains present': 'WKWebView *wk' in s,
    'HTML UI remains embedded and loaded': 'HLXLoadUI()' in s and 'loadHTMLString:html' in s,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()): raise SystemExit(1)
actual = hashlib.sha256(speed).hexdigest()
expected = '65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911'
print('HLXSpeed.m SHA256:', actual)
if actual != expected: raise SystemExit('FAIL: HLXSpeed.m is not the Stage 1 baseline')
print('PASS: Stage 1 speed baseline preserved exactly')
