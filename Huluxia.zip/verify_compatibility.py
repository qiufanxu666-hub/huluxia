#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys
root = Path(__file__).resolve().parent
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ': ' + name)

mk = (root/'Makefile').read_text()
check('legacy build family uses iOS 8.0 deployment and iOS 11.4 SDK', 'iphone:clang:11.4:8.0' in mk and 'armv7 arm64' in mk)
check('modern rootful deployment begins at iOS 11.0', 'iphone:clang:latest:11.0' in mk)
check('modern rootless deployment begins at iOS 15.0', 'iphone:clang:latest:15.0' in mk)
check('modern rootful retains arm64 support without requiring arm64e slice', 'ARCHS := arm64\n  endif' in mk)
check('legacy rootless build is rejected', 'legacy iOS 8-10 target is rootful' in mk)
for f in ['Sources/Tweak.m','Sources/HLXTouch.m','Sources/HLXOverlay.m','Sources/HLXDrawOverlay.m']:
    s=(root/f).read_text()
    if 'connectedScenes' in s or 'UIWindowScene' in s:
        check(f'{f} guards Scene SDK references at compile time', '#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000' in s)
check('draw overlay no longer depends on iOS 10 os_unfair_lock', 'os_unfair_lock' not in (root/'Sources/HLXDrawOverlay.m').read_text())
check('embedded Mach-O section reader uses generic mach_header', 'getsectiondata((const struct mach_header *)' in (root/'Sources/HLXOverlay.m').read_text())
speed = root/'Sources/HLXSpeed.m'
h = hashlib.sha256(speed.read_bytes()).hexdigest()
check('stage 1 speed source SHA-256 unchanged', h == '65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911')
legacy = (root/'Sources/HLXSpeedLegacy.m').read_text()
check('legacy clock backend does not require clock_gettime', not __import__('re').search(r'\bclock_gettime\s*\(', legacy))
check('legacy backend uses mach_absolute_time and gettimeofday', 'mach_absolute_time' in legacy and 'gettimeofday' in legacy)
check('Makefile selects legacy backend only for legacy builds', 'filter-out Sources/HLXSpeed.m' in mk and 'filter-out Sources/HLXSpeedLegacy.m' in mk)
launcher = (root/'Launcher/Resources/Info.plist').read_text()
check('launcher metadata does not block iOS 8 / armv7 devices', '<string>8.0</string>' in launcher and '<string>arm64</string>' not in launcher)
check('compatibility matrix documentation exists', (root/'COMPATIBILITY_IOS8_26.md').is_file())
sys.exit(0 if all(ok for _,ok in checks) else 1)
