#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys
root = Path(__file__).resolve().parent
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ': ' + name)

mk = (root/'Makefile').read_text()
check('legacy build family uses iOS 8.0 deployment and iOS 11.4 SDK', 'iphone:clang:11.4:8.0' in mk and 'armv7 arm64' in mk)
check('modern rootful deployment begins at iOS 11.0', 'iphone:clang:latest:11.0' in mk)
check('modern rootless deployment begins at iOS 15.0', 'iphone:clang:latest:15.0' in mk)
check('modern rootful retains arm64 support without requiring arm64e slice', 'ARCHS := arm64\n  endif' in mk)
check('legacy rootless build is rejected', 'legacy iOS 8-10 target is rootful' in mk)
for f in ['Sources/Tweak.m','Sources/HLXTouch.m','Sources/HLXOverlay.m','Sources/HLXDrawOverlay.m']:
    s=(root/f).read_text()
    if 'connectedScenes' in s or 'UIWindowScene' in s:
        check(f'{f} guards Scene SDK references at compile time', '#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000' in s)
check('draw overlay no longer depends on iOS 10 os_unfair_lock', 'os_unfair_lock' not in (root/'Sources/HLXDrawOverlay.m').read_text())
check('embedded Mach-O section reader uses generic mach_header', 'getsectiondata((const struct mach_header *)' in (root/'Sources/HLXOverlay.m').read_text())
# --- iOS 11.4 SDK (legacy armv7 build) regression guards -------------------
ov = (root/'Sources/HLXOverlay.m').read_text()
def guarded(snippet, guard):
    i = ov.find(snippet)
    return i != -1 and guard in ov[max(0, i-200):i]
check('WKWebView.inspectable (iOS 16.4 SDK) is compile-time guarded',
      guarded('wk.inspectable = YES', '#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 160400'))
check('UIWindow.windowScene (iOS 13 SDK) is compile-time guarded',
      guarded('self->_ball.windowScene', '#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 130000'))
check('no UIView.coordinateSpace property access (does not exist in any SDK)', '.coordinateSpace convertPoint' not in ov and 'v.coordinateSpace' not in ov)
# 旧 SDK(iOS 11.4) 的 libSystem 没有 __availability_version_check：
# 任何未被 SDK 版本宏包住的 @available 都会让 legacy 构建在链接阶段失败。
import glob as _glob
_bad = []
for _f in _glob.glob(str(root/'Sources/*.m')):
    _stack = []
    for _i, _l in enumerate(open(_f, encoding='utf-8'), 1):
        _t = _l.strip()
        if _t.startswith('#if'): _stack.append(_t)
        elif _t.startswith('#endif') and _stack: _stack.pop()
        if '@available' in _t and not _t.startswith('//'):
            if not any('__IPHONE_OS_VERSION_MAX_ALLOWED' in x for x in _stack):
                _bad.append(f'{_f}:{_i}')
check('every @available is inside an SDK-version #if (legacy SDK cannot link it)', not _bad)
speed = root/'Sources/HLXSpeed.m'
h = hashlib.sha256(speed.read_bytes()).hexdigest()
check('stage 1 speed source SHA-256 unchanged', h == '65a3f5c457024f8aa4badcad95f2398d27ea55752f92c5e34aa9a0415d81b911')
legacy = (root/'Sources/HLXSpeedLegacy.m').read_text()
check('legacy clock backend does not require clock_gettime', not __import__('re').search(r'\bclock_gettime\s*\(', legacy))
check('legacy backend uses mach_absolute_time and gettimeofday', 'mach_absolute_time' in legacy and 'gettimeofday' in legacy)
check('Makefile selects legacy backend only for legacy builds', 'filter-out Sources/HLXSpeed.m' in mk and 'filter-out Sources/HLXSpeedLegacy.m' in mk)
launcher = (root/'Launcher/Resources/Info.plist').read_text()
check('launcher metadata does not block iOS 8 / armv7 devices', '<string>8.0</string>' in launcher and '<string>arm64</string>' not in launcher)
check('compatibility matrix documentation exists', (root/'COMPATIBILITY_IOS8_26.md').is_file())
sys.exit(0 if all(ok for _,ok in checks) else 1)
