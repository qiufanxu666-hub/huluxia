#!/bin/bash
# 构建产物校验（macOS，需 Xcode 命令行工具 + dpkg）。
# 目的：证明 deb 与 dylib 用的是仓库里同一份源码/资源，而不是“能装上但内容不对”。
#   用法: ./verify_build.sh [产物目录，默认 out]
set -euo pipefail
cd "$(dirname "$0")"
OUT="${1:-out}"
fail() { echo "❌ $*" >&2; exit 1; }
ok()   { echo "✅ $*"; }
sha()  { shasum -a 256 "$1" | awk '{print $1}'; }

shopt -s nullglob
debs=("$OUT"/*.deb)
[ "${#debs[@]}" -ge 1 ] || fail "$OUT 里没有 deb"
[ -f "$OUT/Huluxia.dylib" ] || fail "$OUT/Huluxia.dylib 不存在"

WANT_UI=$(sha Resources/ui.html)
WANT_BALL=$(sha Resources/ball.png)
WANT_I2=$(sha Launcher/Resources/Icon@2x.png)
WANT_I3=$(sha Launcher/Resources/Icon@3x.png)
WANT_VER=$(awk -F': ' '/^Version:/{print $2}' control)
WANT_APPVER=$(grep -o "APP_VERSION = '[^']*'" Resources/ui.html | sed "s/.*'\(.*\)'/\1/")
[ "$WANT_VER" = "$WANT_APPVER" ] || fail "control 版本($WANT_VER) 与 ui.html APP_VERSION($WANT_APPVER) 不一致"

# 检查单个 dylib：架构 + 内嵌的 ui.html / ball.png 与仓库完全一致（segedit 只能处理单架构，fat 要先拆）
check_dylib() {
  local d="$1" tmp archs a thin sec want got
  tmp=$(mktemp -d)
  archs=$(lipo -archs "$d")
  echo "   架构: $archs"
  for a in $archs; do
    if [ "$(echo "$archs" | wc -w | tr -d ' ')" = "1" ]; then thin="$d"; else thin="$tmp/$a.dylib"; lipo "$d" -thin "$a" -output "$thin"; fi
    for sec in "hlxui:$WANT_UI" "hlxball:$WANT_BALL"; do
      want="${sec##*:}"; sec="${sec%%:*}"
      segedit "$thin" -extract __DATA "__$sec" "$tmp/$a.$sec" >/dev/null 2>&1 || fail "$d [$a] 缺少 __DATA,__$sec 段"
      got=$(sha "$tmp/$a.$sec")
      [ "$got" = "$want" ] || fail "$d [$a] 内嵌的 $sec 与仓库资源不一致"
    done
  done
  rm -rf "$tmp"
}

echo "── standalone dylib ──"
check_dylib "$OUT/Huluxia.dylib"; ok "Huluxia.dylib 内嵌 ui.html / ball.png 与仓库一致"

for deb in "${debs[@]}"; do
  echo "── $(basename "$deb") ──"
  tmp=$(mktemp -d); dpkg-deb -x "$deb" "$tmp"; dpkg-deb -e "$deb" "$tmp/DEBIAN"
  [ "$(dpkg-deb -f "$deb" Version)" = "$WANT_VER" ] || fail "deb 版本 $(dpkg-deb -f "$deb" Version) != $WANT_VER"
  [ "$(dpkg-deb -f "$deb" Package)" = "com.huluxia.tweak" ] || fail "包名不对"
  dpkg-deb -f "$deb" Depends | grep -q mobilesubstrate || fail "Depends 缺少 mobilesubstrate"

  dylib=$(find "$tmp" -path '*MobileSubstrate/DynamicLibraries/Huluxia.dylib' | head -1); [ -n "$dylib" ] || fail "deb 里没有 Huluxia.dylib"
  filt=$(find "$tmp" -path '*MobileSubstrate/DynamicLibraries/Huluxia.plist' | head -1); [ -n "$filt" ] || fail "deb 里没有 Huluxia.plist"
  plutil -convert xml1 -o - "$filt" | grep -q 'com.apple.springboard' || fail "Huluxia.plist 的 Filter 缺少 com.apple.springboard（悬浮球不会出现）"
  check_dylib "$dylib"

  app=$(find "$tmp" -type d -name 'Huluxia.app' | head -1); [ -n "$app" ] || fail "deb 里没有 Huluxia.app"
  [ -x "$app/Huluxia" ] || fail "Huluxia.app 主程序缺失/不可执行"
  [ "$(sha "$app/Icon@2x.png")" = "$WANT_I2" ] || fail "桌面图标 Icon@2x.png 不是仓库里的新图标"
  [ "$(sha "$app/Icon@3x.png")" = "$WANT_I3" ] || fail "桌面图标 Icon@3x.png 不是仓库里的新图标"
  plutil -p "$app/Info.plist" | grep -q 'CFBundleIconFiles' || fail "Info.plist 没有 CFBundleIconFiles"
  [ "$(plutil -extract CFBundleShortVersionString raw "$app/Info.plist")" = "$WANT_VER" ] || fail "Launcher 版本与 deb 不一致"
  for s in postinst postrm; do [ -x "$tmp/DEBIAN/$s" ] || fail "缺少可执行的 DEBIAN/$s（uicache 刷新桌面图标）"; done
  ok "deb 内容与仓库资源一致（包名/版本/依赖/注入 Filter/图标/postinst）"
  rm -rf "$tmp"
done
echo "全部校验通过"
