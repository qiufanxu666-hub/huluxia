# Lua 绘制与触摸 API（葫芦侠 1.0.0）

## 绘制

绘制接口由原生透明窗口渲染，坐标单位为屏幕逻辑点（point）。每帧先清空命令，再追加图元并提交：

```lua
gg.draw.clear()
gg.draw.rect(100, 120, 80, 180, "#FF3333", 2, false)
gg.draw.text(100, 105, "Target", "#FFFFFF", 14)
local points = {
  {x=140,y=120}, {x=140,y=155}, {x=115,y=190},
  {x=165,y=190}, {x=125,y=250}, {x=155,y=250}
}
local bones = {{1,2},{2,3},{2,4},{3,5},{4,6}}
gg.draw.skeleton(points, bones, "#00FF66", 2)
gg.draw.commit()
```

支持 `clear`、`line`、`rect`、`circle`、`text`、`skeleton`、`commit`。单次提交最多保留 2000 条图元。骨骼点和骨骼连接索引均由脚本提供；本接口不自动识别人物，也不读取游戏内部坐标。

## 触摸

Lua 的 `gg.click`、`gg.tap`、`gg.swipe`、`gg.drag`、`gg.longClick`、`gg.touchDown`、`gg.touchMove`、`gg.touchUp` 现在直接调用原生 `h5` bridge，不再把网页 DOM 事件当成游戏触摸。原生桥接不可用时会返回错误，不会伪报成功。

原生实现依赖 iOS HID 私有派发符号和目标进程环境。即使事件已进入派发队列，也不代表任意游戏一定接收；必须在目标设备、目标系统版本和目标游戏中实测。网页 `TouchEvent` / `PointerEvent` 不能替代跨进程游戏触摸。

## 变速时间域

变速只作用于 `mach_absolute_time` 和 `CLOCK_MONOTONIC`。`CLOCK_MONOTONIC_RAW`、`CLOCK_UPTIME_RAW`、`CLOCK_REALTIME` 和 `gettimeofday` 保持系统原始值，避免把不同起点/语义的时钟共用基准，或改变墙上时钟导致网络、证书、超时逻辑异常。倍率更新会在同一临界区完成取样、基准推进和倍率切换。
