#!/usr/bin/env python3
from pathlib import Path
s = (Path(__file__).parent / 'Sources' / 'HLXOverlay.m').read_text()
checks = {
    'UIWebView delegate no longer uses KVC': 'setValue:self forKey:@"delegate"' not in s,
    'UIWebView scrollView no longer uses KVC': '[wv valueForKey:@"scrollView"]' not in s,
    'UIWebView construction is removed': 'NSClassFromString(@\"UIWebView\")' not in s and 'legacyWebView' not in s,
    'WKWebView init is guarded': 'WKWebView init exception:' in s,
    'native fallback avoids messaging absent web engine': 'if ([self.web respondsToSelector:loadSel])' in s,
    'JavaScript fallback checks selector support': 'if ([self.web respondsToSelector:selector])' in s,
    'window creation is main-thread constrained': 'NSAssert(NSThread.isMainThread' in s,
    'window creation has exception rollback': 'panel window creation exception:' in s and '_window = nil;' in s and '_vc = nil;' in s,
    'panel show checks initialization result': 'show aborted: panel initialization failed' in s,
    'ball tap waits for pan failure': '[tap requireGestureRecognizerToFail:pan]' in s,
    'ball tap defers panel creation': 'dispatch_async(dispatch_get_main_queue(), ^{ [HLXOverlay.shared toggle]; });' in s,
    'panel orientation values are range-checked and ball follows all orientations': 'o < UIInterfaceOrientationPortrait || o > UIInterfaceOrientationLandscapeRight' in s and 'supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }' in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
