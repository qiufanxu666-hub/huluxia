#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <os/lock.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <mach/mach.h>
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock gInstallLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock gRebaseLock = OS_UNFAIR_LOCK_INIT;
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono;                // mach ticks / CLOCK_MONOTONIC ns
// 不缩放 CLOCK_REALTIME/gettimeofday：改变墙上时钟会破坏系统超时、证书和网络逻辑。

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

static inline uint64_t HLXScaleLocked(const HLXBase *b, uint64_t real) {
    // 1.0x 也必须经过基准映射：直接返回 real 会在从其他倍率切回 1x 时
    // 让单调时钟突然跳回真实时间，破坏 dispatch / CADisplayLink / 游戏计时器。
    if (real <= b->realBase) return b->virtBase;
    long double delta = (long double)(real - b->realBase) * (long double)gSpeed;
    long double value = (long double)b->virtBase + delta;
    if (value >= (long double)UINT64_MAX) return UINT64_MAX;
    return (uint64_t)value;
}

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    os_unfair_lock_lock(&gLock);
    uint64_t value = HLXScaleLocked(b, real);
    os_unfair_lock_unlock(&gLock);
    return value;
}

static uint64_t h_mach_absolute_time(void) {
    return scale(&gMach, o_mach_absolute_time());
}

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts || c != CLOCK_MONOTONIC) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    ns = scale(&gMono, ns);
    ts->tv_sec = (time_t)(ns / 1000000000ULL);
    ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    // RAW / UPTIME / REALTIME 各有自己的时钟语义，不混用 MONOTONIC 基准。
    return c == CLOCK_MONOTONIC ? scale(&gMono, ns) : ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    // 墙钟必须保持真实时间，不能随游戏倍率一起快进/倒退。
    return o_gettimeofday(tv, tz);
}

static BOOL rebase(double newSpeed) {
    // 序列化倍率更新，防止两个线程先后取样、反向拿锁而把较旧的基准写回。
    os_unfair_lock_lock(&gRebaseLock);
    if (!o_mach_absolute_time || !o_clock_gettime) {
        os_unfair_lock_unlock(&gRebaseLock);
        return NO;
    }
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts = {0};
    if (o_clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        os_unfair_lock_unlock(&gRebaseLock);
        return NO;
    }
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;

    os_unfair_lock_lock(&gLock);
    uint64_t vm = HLXScaleLocked(&gMach, rm);
    uint64_t vn = HLXScaleLocked(&gMono, rn);
    gMach.realBase = rm;
    gMach.virtBase = vm;
    gMono.realBase = rn;
    gMono.virtBase = vn;
    gSpeed = newSpeed;
    os_unfair_lock_unlock(&gLock);
    os_unfair_lock_unlock(&gRebaseLock);
    return YES;
}

// ───────── 无 Substrate 时的后备方案：改写各镜像的符号指针表（fishhook 原理，免越狱可用）─────────
#if defined(__arm64__) && !__has_feature(ptrauth_calls)
static const char *kNames[4] = { "mach_absolute_time", "clock_gettime", "gettimeofday", "clock_gettime_nsec_np" };
static void *kRepl[4];

static void rebind_image(const struct mach_header *mh, intptr_t slide) {
    const struct mach_header_64 *h = (const struct mach_header_64 *)mh;
    const struct segment_command_64 *linkedit = NULL;
    const struct symtab_command *symtab = NULL;
    const struct dysymtab_command *dysymtab = NULL;
    const uint8_t *cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        const struct load_command *lc = (const struct load_command *)cur;
        if (lc->cmd == LC_SEGMENT_64) { const struct segment_command_64 *sg = (const void *)cur; if (!strcmp(sg->segname, "__LINKEDIT")) linkedit = sg; }
        else if (lc->cmd == LC_SYMTAB) symtab = (const void *)cur;
        else if (lc->cmd == LC_DYSYMTAB) dysymtab = (const void *)cur;
    }
    if (!linkedit || !symtab || !dysymtab) return;
    uintptr_t base = (uintptr_t)slide + linkedit->vmaddr - linkedit->fileoff;
    const struct nlist_64 *syms = (const void *)(base + symtab->symoff);
    const char *strtab = (const char *)(base + symtab->stroff);
    const uint32_t *indirect = (const void *)(base + dysymtab->indirectsymoff);

    cur = (const uint8_t *)(h + 1);
    for (uint32_t i = 0; i < h->ncmds; i++, cur += ((const struct load_command *)cur)->cmdsize) {
        if (((const struct load_command *)cur)->cmd != LC_SEGMENT_64) continue;
        const struct segment_command_64 *sg = (const void *)cur;
        if (strcmp(sg->segname, "__DATA") && strcmp(sg->segname, "__DATA_CONST")) continue;
        const struct section_64 *sec = (const void *)(sg + 1);
        for (uint32_t j = 0; j < sg->nsects; j++, sec++) {
            uint32_t type = sec->flags & SECTION_TYPE;
            if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS) continue;
            const uint32_t *ind = indirect + sec->reserved1;
            void **ptrs = (void **)((uintptr_t)slide + sec->addr);
            for (uint64_t k = 0; k < sec->size / sizeof(void *); k++) {
                uint32_t si = ind[k];
                if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL || si == (INDIRECT_SYMBOL_LOCAL | INDIRECT_SYMBOL_ABS)) continue;
                const char *nm = strtab + syms[si].n_un.n_strx;
                if (nm[0] != '_') continue;
                for (int n = 0; n < 4; n++) {
                    if (kRepl[n] && !strcmp(nm + 1, kNames[n])) {
                        mach_vm_protect(mach_task_self(), (mach_vm_address_t)&ptrs[k], sizeof(void *), FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
                        ptrs[k] = kRepl[n];
                    }
                }
            }
        }
    }
}
static BOOL rebindAll(void) {
    kRepl[0] = (void *)h_mach_absolute_time; kRepl[1] = (void *)h_clock_gettime;
    kRepl[2] = (void *)h_gettimeofday;       kRepl[3] = o_clock_gettime_nsec_np ? (void *)h_clock_gettime_nsec_np : NULL;
    _dyld_register_func_for_add_image(rebind_image);        // 已加载的和以后加载的镜像都会处理
    return YES;
}
#else
static BOOL rebindAll(void) { return NO; }
#endif

static BOOL install(NSString **err) {
    os_unfair_lock_lock(&gInstallLock);
    if (gInstalled) { os_unfair_lock_unlock(&gInstallLock); return YES; }
    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) {
        if (err) *err = @"符号解析失败";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }

    // 基准先用“真实=虚拟”初始化；hook 前先读一次原函数值
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts;
    if (((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts) != 0) {
        if (err) *err = @"CLOCK_MONOTONIC 初始化失败";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
    gMono = (HLXBase){ n, n };

    if (hook) {
        hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
        hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
        hook(sym_gtd, (void *)h_gettimeofday,       (void **)&o_gettimeofday);
        if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
    } else {
        // 没有 Substrate/ElleKit（轻松签/全能签等侧载环境）：原函数直接取真实地址，再改写符号指针表
        o_mach_absolute_time = sym_mat; o_clock_gettime = sym_cg; o_gettimeofday = sym_gtd; o_clock_gettime_nsec_np = sym_cgn;
        if (!rebindAll()) {
            if (err) *err = @"此环境没有可用的 Hook 后端，无法启用变速";
            os_unfair_lock_unlock(&gInstallLock);
            return NO;
        }
    }
    if (!o_mach_absolute_time || !o_clock_gettime || !o_gettimeofday) {
        if (err) *err = @"Hook 原函数入口初始化失败";
        os_unfair_lock_unlock(&gInstallLock);
        return NO;
    }
    gInstalled = YES;
    os_unfair_lock_unlock(&gInstallLock);
    return YES;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.huluxia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current {
    os_unfair_lock_lock(&gLock);
    double value = gSpeed;
    os_unfair_lock_unlock(&gLock);
    return value;
}

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x；0x 暂停会冻结时间源，已禁用"; return NO; }
    // SpringBoard / 葫芦侠启动器只是控制端，不能缩放它们自己的系统时钟。
    // 在桌面进程里这么做会影响整个 SpringBoard 的动画、超时和调度，表现为全局卡死。
    NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
    if ([bid isEqualToString:@"com.apple.springboard"] || [bid isEqualToString:@"com.huluxia.launcher"]) {
        if (err) *err = @"当前是桌面/控制器进程，已阻止修改宿主时钟；请先选择已注入变速代理的目标进程";
        return NO;
    }
    if (!install(err)) return NO;
    if (!rebase(mult)) { if (err) *err = @"切换时钟基准失败，倍率未应用"; return NO; }
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!install(&err)) return;                    // 没有 hook 框架就什么都不做
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (isfinite(m) && m >= 0.1 && m <= 10.0) {
            if (!rebase(m)) NSLog(@"[Huluxia] speed rebase failed for pid %d", me);
        }
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!isfinite(mult) || mult < 0.1 || mult > 10.0) { if (err) *err = @"变速范围为 0.1x～10x；0x 暂停会冻结时间源，已禁用"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Huluxia 代理：把目标 App 的 Bundle ID 加进 Huluxia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
