// 桌面图标 = 遥控器：点一下 → 通知 SpringBoard 里的 Hulixia 呼出/收起悬浮窗，然后立刻退回桌面
#import <UIKit/UIKit.h>
#import <notify.h>
#import <objc/message.h>

@interface HLXLauncherDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation HLXLauncherDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [UIViewController new];
    self.window.rootViewController.view.backgroundColor = UIColor.blackColor;
    [self.window makeKeyAndVisible];
    notify_post("com.hulixia.toggle");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        SEL s = NSSelectorFromString(@"suspend");                      // 私有：回到桌面（和按 Home 键一样）
        if ([app respondsToSelector:s]) ((void (*)(id, SEL))objc_msgSend)(app, s);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ exit(0); });
    });
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(HLXLauncherDelegate.class)); }
}
