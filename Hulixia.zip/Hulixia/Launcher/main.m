// 桌面图标：说明页（悬浮按钮出现在被注入的游戏里）
#import <UIKit/UIKit.h>

@interface HLXLauncherDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation HLXLauncherDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = [UIColor colorWithRed:0.1 green:0.5 blue:0.25 alpha:1];
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectInset(vc.view.bounds, 24, 80)];
    l.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    l.numberOfLines = 0; l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:17];
    l.text = @"葫芦侠\n\n悬浮按钮出现在被注入的游戏里。\n\n1. 用 Filza 打开 Hulixia.plist（在 MobileSubstrate/DynamicLibraries 目录下）\n2. 把游戏的 Bundle ID 加进去\n3. 重新打开游戏，约 2 秒后出现悬浮按钮";
    [vc.view addSubview:l];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(HLXLauncherDelegate.class)); }
}
