#!/bin/bash
# 不用 Theos，直接用 Xcode 命令行工具产出【单文件 Hulixia.dylib】（界面 HTML 已嵌入，免越狱注入 IPA 用）
# 需要 macOS + Xcode。产物在 build/Hulixia.dylib
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
xcrun -sdk iphoneos clang \
  -arch arm64 -miphoneos-version-min=13.0 \
  -dynamiclib -fobjc-arc -O2 -fvisibility=hidden \
  -Wno-deprecated-declarations -Wno-unused-function \
  -framework Foundation -framework UIKit -framework WebKit -framework CoreGraphics \
  -Wl,-sectcreate,__DATA,__hlxui,Resources/ui.html \
  -install_name @rpath/Hulixia.dylib \
  Sources/*.m -o build/Hulixia.dylib
codesign -f -s - build/Hulixia.dylib
echo "OK → build/Hulixia.dylib"
