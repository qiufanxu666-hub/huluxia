// Tweak.m — 入口（参考 H5GG 的结构）
//   SpringBoard            → 宿主：用 UIWebView（进程内渲染，WKWebView 在 SpringBoard 里会被杀）显示悬浮窗，
//                            悬浮按钮常驻所有 App 之上；通过 task_for_pid 改任意 App
//   Hulixia.plist 里列出的 App → 若宿主存在则只当“代理”（变速 hook）；没有宿主（打进 IPA）则自带悬浮按钮
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.hulixia.toggle";
static NSString *const kHostAlive = @"com.hulixia.host.alive";

static BOOL HLXHostIsAlive(void) {
    int t = 0; uint64_t st = 0;
    if (notify_register_check(kHostAlive.UTF8String, &t) != NOTIFY_STATUS_OK) return NO;
    notify_get_state(t, &st); notify_cancel(t);
    return st != 0;
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/hulixia_disable"]) return;   // 紧急开关
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if ([bid isEqualToString:@"com.apple.springboard"]) {
            static int tAlive = 0, tToggle = 0;
            notify_register_check(kHostAlive.UTF8String, &tAlive);
            notify_set_state(tAlive, 1);
            notify_register_dispatch(kToggle.UTF8String, &tToggle, dispatch_get_main_queue(), ^(int t) { [HLXOverlay.shared toggle]; });
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [HLXOverlay.shared showBall]; });
            return;
        }
        if (bid.length == 0) return;

        if (HLXHostIsAlive()) {
            [HLXSpeed startAgent];
        } else {
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                static dispatch_once_t once;
                dispatch_once(&once, ^{
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [HLXOverlay.shared showBall]; });
                });
            }];
        }
    }
}
