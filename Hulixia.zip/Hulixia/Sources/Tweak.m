// Tweak.m — 入口。同一个 dylib 有三种身份：
//   1) SpringBoard           → “宿主”：全局悬浮窗 + 通过 task_for_pid 改任意 App（桌面图标点一下呼出）
//   2) 目标 App（宿主存在）  → “代理”：只负责变速 hook，不弹界面
//   3) 目标 App（无宿主）    → “独立”：把 dylib 打进 IPA 时用，App 内自带悬浮窗，直接改自己
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.hulixia.toggle";
static NSString *const kHostAlive = @"com.hulixia.host.alive";

static BOOL HLXHostIsAlive(void) {
    int t = 0; uint64_t st = 0;
    if (notify_register_check(kHostAlive.UTF8String, &t) != NOTIFY_STATUS_OK) return NO;
    notify_get_state(t, &st); notify_cancel(t);
    return st != 0;
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if ([bid isEqualToString:@"com.apple.springboard"]) {
            static int tAlive = 0, tToggle = 0;
            notify_register_check(kHostAlive.UTF8String, &tAlive);
            notify_set_state(tAlive, 1);
            notify_register_dispatch(kToggle.UTF8String, &tToggle, dispatch_get_main_queue(), ^(int t) { [HLXOverlay.shared toggle]; });
            return;
        }
        if (bid.length == 0) return;                                  // 守护进程/命令行：不处理

        if (HLXHostIsAlive()) {                                       // 代理模式
            [HLXSpeed startAgent];
        } else {                                                      // 独立模式：App 启动完成后 2 秒显示悬浮窗
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                static dispatch_once_t once;
                dispatch_once(&once, ^{
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [HLXOverlay.shared show]; });
                });
            }];
        }
    }
}
