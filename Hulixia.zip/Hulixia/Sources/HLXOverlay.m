#import "HLXOverlay.h"
#import "HLXBridge.h"
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <dlfcn.h>
#import <mach-o/getsect.h>
#import <mach-o/dyld.h>
#import <objc/message.h>

static NSString *const kMark = @"\x01HLX\x01";
static const CGSize kBallWindow = { 66, 72 };     // 悬浮球：48 + right:18 / bottom:24

// ───────── 加载 UI（优先读 dylib 内嵌段，其次读磁盘）─────────
static void HLXAnchor(void) {}
static NSData *HLXSection(const char *name) {
    Dl_info info;
    if (dladdr((void *)&HLXAnchor, &info) && info.dli_fbase) {
        unsigned long sz = 0;
        uint8_t *p = getsectiondata((const struct mach_header_64 *)info.dli_fbase, "__DATA", name, &sz);
        if (p && sz) return [NSData dataWithBytes:p length:sz];
    }
    return nil;
}
static NSString *HLXLoadUI(void) {
    NSData *d = HLXSection("__hlxui");
    NSString *e = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : nil;
    if (e) return e;
    for (NSString *path in @[ @"/var/jb/Library/Application Support/Hulixia/ui.html", @"/Library/Application Support/Hulixia/ui.html" ]) {
        NSString *s = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
        if (s) return s;
    }
    return @"<html><body style='background:#222;color:#fff;font:16px sans-serif;padding:20px'>未找到内嵌界面（__hlxui 段）</body></html>";
}

// ───────── 窗口 / 控制器 ─────────
@interface HLXRootVC : UIViewController <WKUIDelegate, WKScriptMessageHandler, UIGestureRecognizerDelegate>
@property (nonatomic, strong) WKWebView *web;
@property (nonatomic, weak) UIWindow *hostWindow;
@property (nonatomic, assign) CGRect expanded;
@property (nonatomic, assign) CGRect dragRect;
@property (nonatomic, assign) BOOL collapsed;
@property (nonatomic, assign) CGPoint panStart;
@property (nonatomic, assign) CGRect panFrame;
- (void)applyFrame;
- (void)callLayout;
@end

@implementation HLXRootVC

- (void)loadView {
    WKWebViewConfiguration *cfg = [WKWebViewConfiguration new];
    WKUserContentController *ucc = [WKUserContentController new];
    [ucc addScriptMessageHandler:self name:@"hlx"];
    [ucc addUserScript:[[WKUserScript alloc] initWithSource:HLXBridge.bootstrapScript injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO]];
    cfg.userContentController = ucc;
    cfg.allowsInlineMediaPlayback = YES;
    self.web = [[WKWebView alloc] initWithFrame:CGRectZero configuration:cfg];
    self.web.UIDelegate = self;
    self.web.opaque = NO;
    self.web.backgroundColor = UIColor.clearColor;
    self.web.scrollView.backgroundColor = UIColor.clearColor;
    self.web.scrollView.scrollEnabled = NO;
    self.web.scrollView.bounces = NO;
    self.web.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    if (@available(iOS 16.4, *)) self.web.inspectable = YES;
    self.view = self.web;

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    pan.delegate = self; pan.cancelsTouchesInView = NO; pan.maximumNumberOfTouches = 1;
    [self.web addGestureRecognizer:pan];

    self.expanded = CGRectMake(0, 0, 390, 580);
    // 用固定的 https 源，localStorage（收藏/脚本/主题）才能跨次保存
    [self.web loadHTMLString:HLXLoadUI() baseURL:[NSURL URLWithString:@"https://hulixia.local/"]];
}

// 作为 key window 时别去改宿主 App 的方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UIInterfaceOrientation o = UIInterfaceOrientationPortrait;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class]) { o = ((UIWindowScene *)s).interfaceOrientation; break; }
    return (UIInterfaceOrientationMask)(1 << o);
}
- (BOOL)prefersStatusBarHidden { return YES; }

- (void)viewDidLayoutSubviews { [super viewDidLayoutSubviews]; }

#pragma mark 窗口几何

- (CGSize)screenSize { return UIScreen.mainScreen.bounds.size; }

- (CGRect)clamp:(CGRect)r {
    CGSize s = [self screenSize];
    r.size.width = MIN(r.size.width, s.width); r.size.height = MIN(r.size.height, s.height);
    r.origin.x = MAX(0, MIN(r.origin.x, s.width - r.size.width));
    r.origin.y = MAX(0, MIN(r.origin.y, s.height - r.size.height));
    return r;
}

- (void)applyFrame {
    if (!self.hostWindow) return;
    CGRect f = self.collapsed
        ? CGRectMake(CGRectGetMaxX(self.expanded) - kBallWindow.width, CGRectGetMaxY(self.expanded) - kBallWindow.height, kBallWindow.width, kBallWindow.height)
        : self.expanded;
    self.hostWindow.frame = [self clamp:f];
}

- (void)callLayout {
    CGSize s = [self screenSize];
    NSString *js = [NSString stringWithFormat:@"window.__hlxLayout && window.__hlxLayout(%g,%g)", s.width, s.height];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark JS → 原生消息

- (void)userContentController:(WKUserContentController *)c didReceiveScriptMessage:(WKScriptMessage *)msg {
    NSDictionary *d = [msg.body isKindOfClass:NSDictionary.class] ? msg.body : nil;
    NSString *t = d[@"t"];
    NSArray *r = d[@"r"];
    if ([t isEqualToString:@"rect"] && r.count == 4) {
        self.expanded = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
        [self applyFrame];
    } else if ([t isEqualToString:@"drag"] && r.count == 4) {
        self.dragRect = CGRectMake([r[0] doubleValue], [r[1] doubleValue], [r[2] doubleValue], [r[3] doubleValue]);
    } else if ([t isEqualToString:@"visible"]) {
        if (![d[@"v"] boolValue]) [HLXOverlay.shared hide]; else [HLXOverlay.shared show];
    } else if ([t isEqualToString:@"layout"]) {
        [self callLayout];
    } else if ([t isEqualToString:@"collapsed"]) {
        BOOL c2 = [d[@"v"] boolValue];
        if (c2) {   // 页面自带的小球不用，改由原生悬浮球负责：还原页面并收起窗口
            [self.web evaluateJavaScript:@"var a=document.getElementById('app'),f=document.getElementById('float');if(a)a.style.display='flex';if(f)f.style.display='none';" completionHandler:nil];
            [HLXOverlay.shared hide];
            return;
        }
        if (c2 == self.collapsed) return;
        if (!c2) {                                    // 展开：让展开窗口的右下角对齐当前悬浮球
            CGRect ball = self.hostWindow.frame;
            CGRect e = self.expanded;
            e.origin = CGPointMake(CGRectGetMaxX(ball) - e.size.width, CGRectGetMaxY(ball) - e.size.height);
            self.expanded = [self clamp:e];
        }
        self.collapsed = c2;
        [self applyFrame];
    }
}

#pragma mark 拖动

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)g {
    if (![g isKindOfClass:UIPanGestureRecognizer.class]) return YES;
    if (self.collapsed) return YES;                                       // 悬浮球整块可拖
    CGPoint p = [g locationInView:self.web];
    return CGRectContainsPoint(self.dragRect, p);                         // 展开时只有拖拽栏可拖
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)a shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)b { return YES; }

- (void)onPan:(UIPanGestureRecognizer *)g {
    UIView *v = self.web;
    CGPoint p = [v.coordinateSpace convertPoint:[g locationInView:v] toCoordinateSpace:UIScreen.mainScreen.coordinateSpace];
    if (g.state == UIGestureRecognizerStateBegan) { self.panStart = p; self.panFrame = self.hostWindow.frame; }
    else if (g.state == UIGestureRecognizerStateChanged) {
        CGRect f = self.panFrame;
        f.origin.x += p.x - self.panStart.x; f.origin.y += p.y - self.panStart.y;
        f = [self clamp:f];
        self.hostWindow.frame = f;
        if (!self.collapsed) self.expanded = f;
    }
}

#pragma mark 同步桥 + 原生对话框

- (void)webView:(WKWebView *)w runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)def
initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(NSString *))done {
    if ([prompt hasPrefix:kMark]) {
        [HLXBridge handlePayload:[prompt substringFromIndex:kMark.length] completion:done];
        return;
    }
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:prompt preferredStyle:UIAlertControllerStyleAlert];
    [ac addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.text = def; }];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(nil); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(ac.textFields.firstObject.text ?: @""); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptAlertPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(void))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
- (void)webView:(WKWebView *)w runJavaScriptConfirmPanelWithMessage:(NSString *)m initiatedByFrame:(WKFrameInfo *)f completionHandler:(void (^)(BOOL))done {
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:nil message:m preferredStyle:UIAlertControllerStyleAlert];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) { done(NO); }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { done(YES); }]];
    [self presentViewController:ac animated:YES completion:nil];
}
@end


// ───────── 原生悬浮球（像 iGG / H5GG）─────────
@interface HLXBallVC : UIViewController @end
@implementation HLXBallVC
- (BOOL)prefersStatusBarHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    UIInterfaceOrientation o = UIInterfaceOrientationPortrait;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
        if ([s isKindOfClass:UIWindowScene.class]) { o = ((UIWindowScene *)s).interfaceOrientation; break; }
    return (UIInterfaceOrientationMask)(1 << o);
}
@end

@interface HLXBallHandler : NSObject
@property (nonatomic, weak) UIWindow *win;
@end
@implementation HLXBallHandler
- (void)tap { [HLXOverlay.shared toggle]; }
- (void)pan:(UIPanGestureRecognizer *)g {
    UIWindow *w = self.win; if (!w) return;
    CGPoint t = [g translationInView:w.rootViewController.view];
    [g setTranslation:CGPointZero inView:w.rootViewController.view];
    CGSize sc = UIScreen.mainScreen.bounds.size; CGRect f = w.frame;
    f.origin.x = MAX(0, MIN(f.origin.x + t.x, sc.width - f.size.width));
    f.origin.y = MAX(0, MIN(f.origin.y + t.y, sc.height - f.size.height));
    w.frame = f;
    if (g.state == UIGestureRecognizerStateEnded) {      // 松手吸附到左右边缘
        f.origin.x = (CGRectGetMidX(f) < sc.width / 2) ? 4 : sc.width - f.size.width - 4;
        [UIView animateWithDuration:0.2 animations:^{ w.frame = f; }];
    }
}
@end

// ───────── 管理器 ─────────
@implementation HLXOverlay {
    UIWindow *_window; HLXRootVC *_vc; __weak UIWindow *_prevKey; UIWindow *_ball; id _ballHandler;
}

+ (instancetype)shared {
    static HLXOverlay *o; static dispatch_once_t once;
    dispatch_once(&once, ^{ o = [HLXOverlay new]; });
    return o;
}

- (UIWindow *)makeWindow {
    UIWindow *w = nil;
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = nil;
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes)
            if ([s isKindOfClass:UIWindowScene.class]) { scene = (UIWindowScene *)s; if (s.activationState == UISceneActivationStateForegroundActive) break; }
        w = scene ? [[UIWindow alloc] initWithWindowScene:scene] : [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    } else {
        w = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    }
    w.windowLevel = UIWindowLevelAlert + 100000;
    w.backgroundColor = UIColor.clearColor;
    // 私有：让窗口留在“安全层”，盖在锁屏/通知中心之上也能显示
    SEL sec = NSSelectorFromString(@"_setSecure:");
    if ([w respondsToSelector:sec]) ((void (*)(id, SEL, BOOL))objc_msgSend)(w, sec, YES);
    return w;
}

- (void)showBall {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self->_ball) { self->_ball.hidden = NO; return; }
        CGFloat D = 52; CGSize sc = UIScreen.mainScreen.bounds.size;
        UIWindow *w = [self makeWindow];
        w.windowLevel = UIWindowLevelAlert + 100001;
        w.frame = CGRectMake(sc.width - D - 4, sc.height * 0.35, D, D);
        w.rootViewController = [HLXBallVC new];
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, D, D)];
        NSData *d = HLXSection("__hlxball");
        iv.image = d ? [UIImage imageWithData:d] : nil;
        iv.backgroundColor = iv.image ? UIColor.clearColor : [UIColor colorWithRed:0.18 green:0.49 blue:0.2 alpha:1];
        iv.contentMode = UIViewContentModeScaleAspectFill;
        iv.layer.cornerRadius = D / 2; iv.clipsToBounds = YES; iv.alpha = 0.92;
        iv.userInteractionEnabled = YES;
        HLXBallHandler *h = [HLXBallHandler new]; h.win = w; self->_ballHandler = h;
        [iv addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:h action:@selector(tap)]];
        [iv addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:h action:@selector(pan:)]];
        [w.rootViewController.view addSubview:iv];
        w.hidden = NO; self->_ball = w;
    });
}

- (void)ensure {
    if (_window) return;
    _vc = [HLXRootVC new];
    _window = [self makeWindow];
    _window.rootViewController = _vc;
    _vc.hostWindow = _window;
    [_vc applyFrame];
    [[NSNotificationCenter defaultCenter] addObserverForName:UIDeviceOrientationDidChangeNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
        // 旋转后让页面按新尺寸重新布局（页面的 setLayoutAction 会再次调用 setWindowRect）
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self->_vc callLayout]; });
    }];
}

- (void)show {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self ensure];
        self->_prevKey = UIApplication.sharedApplication.keyWindow;
        self->_window.hidden = NO;
        [self->_window makeKeyAndVisible];
        [self->_vc applyFrame];
        [self->_vc callLayout];
    });
}
- (void)hide {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->_window) return;
        self->_window.hidden = YES;
        [self->_prevKey makeKeyWindow];
    });
}
- (void)toggle {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!self->_window || self->_window.hidden) [self show]; else [self hide];
    });
}
@end
