#import "HLXSpeed.h"
#import <dlfcn.h>
#import <notify.h>
#import <os/lock.h>
#import <mach/mach_time.h>
#import <sys/time.h>
#import <time.h>

typedef void (*MSHookFunction_t)(void *symbol, void *replace, void **result);

// 每个时间域一份 “实时基准 / 虚拟基准”，虚拟时间 = virtBase + (real - realBase) * speed
typedef struct { uint64_t realBase, virtBase; } HLXBase;

static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static double   gSpeed = 1.0;
static BOOL     gInstalled = NO;
static HLXBase  gMach, gMono, gWall;        // mach ticks / 单调 ns / 墙钟 ns

static uint64_t (*o_mach_absolute_time)(void);
static int      (*o_clock_gettime)(clockid_t, struct timespec *);
static int      (*o_gettimeofday)(struct timeval *, void *);
static uint64_t (*o_clock_gettime_nsec_np)(clockid_t);

static inline uint64_t scale(HLXBase *b, uint64_t real) {
    os_unfair_lock_lock(&gLock);
    double sp = gSpeed; uint64_t rb = b->realBase, vb = b->virtBase;
    os_unfair_lock_unlock(&gLock);
    if (real < rb) return real;
    return vb + (uint64_t)((double)(real - rb) * sp);
}

static uint64_t h_mach_absolute_time(void) { return scale(&gMach, o_mach_absolute_time()); }

static BOOL isMono(clockid_t c) { return c == CLOCK_MONOTONIC || c == CLOCK_MONOTONIC_RAW || c == CLOCK_UPTIME_RAW; }

static int h_clock_gettime(clockid_t c, struct timespec *ts) {
    int r = o_clock_gettime(c, ts);
    if (r != 0 || !ts) return r;
    uint64_t ns = (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
    if (isMono(c))               ns = scale(&gMono, ns);
    else if (c == CLOCK_REALTIME) ns = scale(&gWall, ns);
    else return r;
    ts->tv_sec = (time_t)(ns / 1000000000ULL); ts->tv_nsec = (long)(ns % 1000000000ULL);
    return r;
}

static uint64_t h_clock_gettime_nsec_np(clockid_t c) {
    uint64_t ns = o_clock_gettime_nsec_np(c);
    if (isMono(c))               return scale(&gMono, ns);
    if (c == CLOCK_REALTIME)     return scale(&gWall, ns);
    return ns;
}

static int h_gettimeofday(struct timeval *tv, void *tz) {
    int r = o_gettimeofday(tv, tz);
    if (r != 0 || !tv) return r;
    uint64_t ns = ((uint64_t)tv->tv_sec * 1000000ULL + (uint64_t)tv->tv_usec) * 1000ULL;
    ns = scale(&gWall, ns);
    tv->tv_sec = (time_t)(ns / 1000000000ULL); tv->tv_usec = (suseconds_t)((ns % 1000000000ULL) / 1000ULL);
    return r;
}

static void rebase(double newSpeed) {
    // 先取各域当前虚拟时间，再把基准推进到“现在”，避免调倍率时时间跳变
    uint64_t rm = o_mach_absolute_time();
    struct timespec ts; o_clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t rn = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
    struct timeval tv; o_gettimeofday(&tv, NULL);
    uint64_t rw = ((uint64_t)tv.tv_sec * 1000000ULL + tv.tv_usec) * 1000ULL;

    os_unfair_lock_lock(&gLock);
    HLXBase *bs[3] = { &gMach, &gMono, &gWall }; uint64_t rs[3] = { rm, rn, rw };
    for (int i = 0; i < 3; i++) {
        uint64_t v = bs[i]->virtBase + (uint64_t)((double)(rs[i] - bs[i]->realBase) * gSpeed);
        bs[i]->realBase = rs[i]; bs[i]->virtBase = v;
    }
    gSpeed = newSpeed;
    os_unfair_lock_unlock(&gLock);
}

static BOOL install(NSString **err) {
    if (gInstalled) return YES;
    MSHookFunction_t hook = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
    if (!hook) {
        if (err) *err = @"未找到 MSHookFunction（需要 Substrate / ElleKit / libhooker；纯 dylib 注入的免越狱环境不支持变速）";
        return NO;
    }
    void *sym_mat = dlsym(RTLD_DEFAULT, "mach_absolute_time");
    void *sym_cg  = dlsym(RTLD_DEFAULT, "clock_gettime");
    void *sym_gtd = dlsym(RTLD_DEFAULT, "gettimeofday");
    void *sym_cgn = dlsym(RTLD_DEFAULT, "clock_gettime_nsec_np");
    if (!sym_mat || !sym_cg || !sym_gtd) { if (err) *err = @"符号解析失败"; return NO; }

    // 基准先用“真实=虚拟”初始化；hook 前先读一次原函数值
    uint64_t m = ((uint64_t (*)(void))sym_mat)();
    struct timespec ts; ((int (*)(clockid_t, struct timespec *))sym_cg)(CLOCK_MONOTONIC, &ts);
    struct timeval tv;  ((int (*)(struct timeval *, void *))sym_gtd)(&tv, NULL);
    gMach = (HLXBase){ m, m };
    uint64_t n = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec; gMono = (HLXBase){ n, n };
    uint64_t w = ((uint64_t)tv.tv_sec * 1000000ULL + tv.tv_usec) * 1000ULL; gWall = (HLXBase){ w, w };

    hook(sym_mat, (void *)h_mach_absolute_time, (void **)&o_mach_absolute_time);
    hook(sym_cg,  (void *)h_clock_gettime,      (void **)&o_clock_gettime);
    hook(sym_gtd, (void *)h_gettimeofday,       (void **)&o_gettimeofday);
    if (sym_cgn) hook(sym_cgn, (void *)h_clock_gettime_nsec_np, (void **)&o_clock_gettime_nsec_np);
    gInstalled = YES;
    return YES;
}

static NSString *speedName(pid_t pid) { return [NSString stringWithFormat:@"com.hulixia.speed.%d", pid]; }
static NSString *agentName(pid_t pid) { return [NSString stringWithFormat:@"com.hulixia.agent.%d", pid]; }

@implementation HLXSpeed

+ (double)current { return gSpeed; }

+ (BOOL)applyLocal:(double)mult error:(NSString **)err {
    if (!(mult >= 0) || mult > 100) { if (err) *err = @"无效的变速倍率"; return NO; }
    if (!install(err)) return NO;
    rebase(mult);
    return YES;
}

// 目标进程里的代理：立刻装 hook，并监听本进程专属的通知；状态里放 double 的位模式
+ (void)startAgent {
    static int tokSpeed = 0, tokAlive = 0;
    pid_t me = getpid();
    NSString *err = nil;
    if (!install(&err)) return;                    // 没有 hook 框架就什么都不做
    notify_register_dispatch(speedName(me).UTF8String, &tokSpeed, dispatch_get_main_queue(), ^(int t) {
        uint64_t bits = 0; notify_get_state(t, &bits);
        double m; memcpy(&m, &bits, 8);
        if (m >= 0 && m <= 100) rebase(m);
    });
    if (notify_register_check(agentName(me).UTF8String, &tokAlive) == NOTIFY_STATUS_OK) notify_set_state(tokAlive, 1);
}

+ (BOOL)sendToPid:(pid_t)pid mult:(double)mult error:(NSString **)err {
    if (!(mult >= 0) || mult > 100) { if (err) *err = @"无效的变速倍率"; return NO; }
    int tok = 0; uint64_t alive = 0;
    if (notify_register_check(agentName(pid).UTF8String, &tok) == NOTIFY_STATUS_OK) { notify_get_state(tok, &alive); notify_cancel(tok); }
    if (!alive) {
        if (err) *err = @"目标进程里没有加载 Hulixia 代理：把目标 App 的 Bundle ID 加进 Hulixia.plist 的 Filter 后重新打开目标 App";
        return NO;
    }
    int t2 = 0;
    if (notify_register_check(speedName(pid).UTF8String, &t2) != NOTIFY_STATUS_OK) { if (err) *err = @"notify 注册失败"; return NO; }
    uint64_t bits; memcpy(&bits, &mult, 8);
    notify_set_state(t2, bits);
    notify_post(speedName(pid).UTF8String);
    notify_cancel(t2);
    return YES;
}
@end
