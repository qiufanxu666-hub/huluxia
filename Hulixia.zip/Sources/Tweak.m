// Tweak.m — 入口（H5GG 风格：悬浮球在 SpringBoard 常驻，所有 App 之上可见）
//   SpringBoard            → 宿主：用 UIWebView（进程内渲染，WKWebView 在 SpringBoard 里会被杀）显示悬浮窗，
//                            悬浮球常驻桌面；通过 task_for_pid 改任意 App
//   Hulixia.plist 里列出的 App → 若宿主存在则只当“代理”（变速 hook）；没有宿主（打进 IPA）则自带悬浮球
//   桌面图标 (Launcher)     → post notify com.hulixia.toggle → SpringBoard 呼出/收起悬浮窗
#import <UIKit/UIKit.h>
#import <notify.h>
#import "HLXOverlay.h"
#import "HLXSpeed.h"

static NSString *const kToggle = @"com.hulixia.toggle";
static NSString *const kHostAlive = @"com.hulixia.host.alive";

static NSUncaughtExceptionHandler *gPrevHandler;
static void HLXCrashHandler(NSException *e) {
    NSString *t = [NSString stringWithFormat:@"%@ CRASH %@: %@\n%@\n\n", [NSDate date], e.name, e.reason, [e.callStackSymbols componentsJoinedByString:@"\n"]];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/hulixia_crash.log"];
    if (!h) { [t writeToFile:@"/var/mobile/hulixia_crash.log" atomically:NO encoding:NSUTF8StringEncoding error:nil]; }
    else { [h seekToEndOfFile]; [h writeData:[t dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile]; }
    if (gPrevHandler) gPrevHandler(e);
}

// 在 SpringBoard 里注册 toggle 通知：Launcher 桌面图标点击后呼出/收起悬浮窗
static void HLXRegisterToggle(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        int token = 0;
        notify_register_dispatch(kToggle.UTF8String, &token, dispatch_get_main_queue(), ^(int t) {
            // 广播：让本进程（SpringBoard）里的悬浮窗切换显示
            [HLXOverlay.shared toggle];
        });
        // 标记宿主存活（App 内代理可以据此知道宿主在线）
        int alive = 0;
        if (notify_register_check(kHostAlive.UTF8String, &alive) == NOTIFY_STATUS_OK) {
            notify_set_state(alive, 1);
            notify_cancel(alive);
        }
    });
}

__attribute__((constructor)) static void HLXEntry(void) {
    @autoreleasepool {
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/hulixia_disable"]) return;   // 紧急开关
        NSString *bid = NSBundle.mainBundle.bundleIdentifier ?: @"";
        if (bid.length == 0) return;

        gPrevHandler = NSGetUncaughtExceptionHandler();
        NSSetUncaughtExceptionHandler(&HLXCrashHandler);

        BOOL isSB = [bid isEqualToString:@"com.apple.springboard"];

        if (isSB) {
            // ── SpringBoard：悬浮球常驻桌面，所有 App 之上可见 ──
            HLXRegisterToggle();
            // SpringBoard 启动后稍等片刻再显示悬浮球（等 UI 稳定）
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                [HLXOverlay.shared showBall];
            });
            return;
        }

        // ── 被 plist Filter 注入的 App：只当变速代理（不显示悬浮窗，由 SpringBoard 的悬浮窗统一操作）──
        {
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                static dispatch_once_t once;
                dispatch_once(&once, ^{
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                        // 如果宿主（SpringBoard）在线，本 App 里不显示悬浮球，统一由宿主操作；
                        // 如果是单文件 dylib 注入 IPA（无 SpringBoard 宿主），才在本 App 里显示悬浮球
                        int token = 0; uint64_t st = 0;
                        BOOL hostAlive = (notify_register_check(kHostAlive.UTF8String, &token) == NOTIFY_STATUS_OK)
                                         && (notify_get_state(token, &st) == NOTIFY_STATUS_OK) && st != 0;
                        notify_cancel(token);
                        if (!hostAlive) [HLXOverlay.shared showBall];
                    });
                });
            }];
        }
    }
}
